# Shared developer setup

`@foss-earth/dev-installer` owns generic workspace-manifest/bootstrap handling,
safe checkout/install/build/check orchestration and read-only diagnostics.
Applications own their compatible manifests. Flight/campus wrappers call the
public API with a pinned data descriptor; no application runtime is imported.

```sh
foss-earth-workspace init --manifest workspace.json --root "workspace path"
foss-earth-workspace init --bootstrap reviewed-bootstrap.json --root "workspace path" --apply
foss-earth-workspace init --manifest workspace.json --root "shared workspace" --mode source --apply
foss-earth-workspace init --manifest workspace.json --root "shared workspace" --mode package --apply
foss-earth-workspace init --manifest workspace.json --root "shared workspace" --mode hybrid --component renderer=source --apply
foss-earth-workspace sync --manifest workspace.json --root "shared workspace" --component renderer=package --apply
foss-earth-workspace init --manifest workspace.json --root "artifact workspace" --mode exact --apply
foss-earth-workspace doctor --manifest workspace.json --root "workspace path"
foss-earth-workspace sync --manifest next-workspace.json --root "workspace path" --apply
foss-earth-workspace check --manifest workspace.json --root "workspace path" --select library
```

Init/sync preview without `--apply`; mutation is explicit. The declared full
default workspace is the default. `--select` accepts a component or named
selection and includes dependency closure. Fetch/install/build actions are
emitted before they run. `doctor` does not fetch, install, create directories,
change the Git index or write journals/logs; remote freshness is unknown offline.
`check` runs declared checks and retains results without cloning/installing.

Exact Git revisions and artifact SHA-256/byte sizes are required. Existing dirty,
diverged, incompatible-source or conflicting destinations stop with repair
advice. Sync only moves a clean source forward to the explicit pin; local commits
and evidence are retained. No reset, clean, stash or deletion. Failed staging,
downloads, commands and incomplete journals remain under workspace/build/.
Success is reused only when the complete input fingerprint and declared output
digests still match; checks always run. Steps without output receipts rerun.

`--mode source` activates every declared link for selected consumers. Providers
clone/build once at independent relative destinations in an explicitly chosen
shared root, then all consumers link to those same actual checkouts through
public package exports. Declare each provider in consumer dependency closure,
with exact package version and required public output files. Existing clean
checkouts can be reused through machine-local `--links` path overrides; no
second copy hides a conflicting provider. Doctor records provider realpaths and
link readiness. Existing package directories/links are retained in build evidence
while owner installs run; links are restored before builds and output receipts.

Application developer wrappers select `runCli({bootstrap, mode:'source'})` as
their full-default setup. Explicit `--mode exact` overrides that default for
independent immutable artifact verification and disables links/path overrides.
Generic CLI/API calls with mode omitted retain prior exact or explicit --links
behavior in a new workspace; saved developer choices take precedence on later
invocations. `--mode package` keeps the selected application/runner composition in
source and consumes its providers as exact packages, without cloning provider
repositories. `--mode hybrid` defaults package providers to exact packages, selects
edited components with --component ID=source, and avoids cloning packaged repos.
Package consumers can import source providers at declared nested package mounts.
Mode, component/path choices and pending/applied switches persist per manifest.
Per-consumer link records survive narrowed selections and nested parent switches.
Saved --select roots also persist; --all returns to the full default workspace.
Source→package keeps inactive dirty checkouts and evidence; dirty source
reactivation stops for explicit repair. Own contracts and effective inputs keep
unaffected builds reusable. See the contract for packageDependsOn runtime inputs.
Source/package/hybrid results do not qualify immutable releases. This increment is
prepared but unverified until its queued check window; retained ff46c57 does not
export these new modes.

No global/system tool installer, server/watch startup or implicit native/WASM
build runs. Known native commands require a named opt-in. Trusted application
manifests must classify their build scripts honestly. Default flight setup uses
its accepted JSBSim artifact; flight wrapper owns the explicit native path.
No Search or shared/flight VR component is allowed in current manifests.

`foss-earth-setup` is the standalone Earth entry, defaults to source development
mode and accepts the same explicit manifest/bootstrap inputs and all four modes.
Its manifest must be owned by `foss-earth`, default to the real `foss-earth/app`
composition and exclude the landing site from that default dependency closure.
An explicit provider-only selection remains supported. The thin
`foss-earth/foss-earth.github.io` landing and compiled `/app/` assembly belong to
Earth's separate release workflow. See [Earth bootstrap requirements](docs/earth-bootstrap.md).
The standalone command accepts an explicit --mode exact
override. Its default descriptor is an Earth-owned pure-data
artifact installed at defaults/earth-bootstrap.json. Until the Earth primary
supplies an accepted descriptor/artifact set, default setup fails with an
actionable missing-input result rather than inventing compatible packages.
Full Earth/campus fixture workspaces contain no flight dependency. Real app
bootstrap receipts remain pending their accepted artifacts.

See [manifest and wrapper contract](docs/contracts.md), [safe operations](docs/operations.md)
and [acceptance](docs/acceptance.md). Version 0.1.0 is private staging; no registry
publication or untested OS support is claimed. Node 22+ and Git are required.

## Project policies

- [Code of conduct](CODE_OF_CONDUCT.md)
- [Contributing](CONTRIBUTING.md)
- [AGPL-3.0 license](LICENSE)
- [Security](SECURITY.md)
