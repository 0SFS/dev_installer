// Copy this script to a fresh consumer root; all runtime imports resolve there.
import assert from 'node:assert/strict';
import { mkdirSync, writeFileSync, readFileSync, existsSync, readdirSync, lstatSync, realpathSync, readlinkSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { resolve, dirname } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const consumer = process.cwd(), [releasePath, artifactPath] = process.argv.slice(2);
const release = JSON.parse(readFileSync(releasePath)), hash = bytes => createHash('sha256').update(bytes).digest('hex');
const installed = resolve(consumer, 'node_modules/@foss-earth/dev-installer');
assert.equal(realpathSync(installed), installed); assert.equal(process.env.NODE_PATH ?? '', '');
assert.equal(dirname(dirname(fileURLToPath(import.meta.resolve('@foss-earth/dev-installer')))), installed);
assert.equal(hash(readFileSync(artifactPath)), release.artifactSha256); assert.equal(lstatSync(artifactPath).size, release.sizeBytes);
const identity = JSON.parse(readFileSync(resolve(installed, 'package.json')));
for (const [key, value] of Object.entries(release.packageIdentity)) assert.deepEqual(identity[key], value);
for (const [path, digest] of Object.entries(release.files)) { const target = resolve(installed, path); assert.ok(lstatSync(target).isFile()); assert.equal(realpathSync(target), target); assert.equal(hash(readFileSync(target)), digest); }
for (const path of ['LICENSE', 'PROVENANCE.json']) assert.equal(hash(readFileSync(resolve(installed, path))), release.archive.files[path]);
for (const entry of release.publicEntries) assert.equal(release.files[entry.path], entry.sha256);
// Validate every executable byte and package resolution before executing imports.
const { runCli } = await import('@foss-earth/dev-installer');
const { validateManifest, selectComponents } = await import('@foss-earth/dev-installer/manifest');
const { workspace } = await import('@foss-earth/dev-installer/workspace');
const { bootstrapManifest, validateBootstrapDescriptor } = await import('@foss-earth/dev-installer/bootstrap');
const { validateArchive, installArchive, verifyTree, treeDigest } = await import('@foss-earth/dev-installer/archive');
const { verifyPackageIdentity } = await import('@foss-earth/dev-installer/packages');
const { default: schema } = await import('@foss-earth/dev-installer/schema', { with: { type: 'json' } });
assert.ok(schema.$schema); assert.equal(typeof workspace, 'function');
const packageResult = await verifyPackageIdentity({ repo: consumer, identity: { name: release.package, version: release.version, artifact: 'installer', files: release.files } }); assert.equal(packageResult.valid, true);

const scratch = resolve(consumer, 'build/fixtures'); mkdirSync(scratch, { recursive: true });
function git(args, cwd) {
  const environment = Object.fromEntries(Object.entries(process.env).filter(([key]) => !key.startsWith('GIT_')));
  const run = spawnSync('git', ['--no-optional-locks', '-c', 'core.hooksPath=/dev/null', ...args], { cwd, encoding: 'utf8', env: { ...environment, GIT_NO_REPLACE_OBJECTS: '1' } });
  assert.equal(run.status, 0, 'Synthetic fixture Git operation failed'); return run.stdout.trim();
}
const source = resolve(scratch, 'source'); mkdirSync(source);
git(['init', '--quiet', '--initial-branch=main'], source);
writeFileSync(resolve(source, '.gitignore'), '/build/\n/dist/\n');
writeFileSync(resolve(source, 'build.mjs'), 'import {mkdirSync,writeFileSync,readFileSync,existsSync} from "node:fs"; mkdirSync("build",{recursive:true}); mkdirSync("dist",{recursive:true}); const count=existsSync("build/count")?Number(readFileSync("build/count")):0; writeFileSync("build/count",String(count+1)); writeFileSync("dist/receipt.json",JSON.stringify({synthetic:true}));\n');
git(['add', '.gitignore', 'build.mjs'], source); git(['-c', 'user.name=Fixture Human', '-c', 'user.email=fixture@example.invalid', 'commit', '--quiet', '-m', 'Synthetic installed setup fixture'], source);
const revision = git(['rev-parse', 'HEAD'], source), bytes = Buffer.from('Synthetic content only'), content = resolve(scratch, 'content.bin'); writeFileSync(content, bytes);
const ownerReceipts = [];
const quiet = () => {};
function snapshot(root) {
  if (!existsSync(root)) return [];
  const entries = [];
  for (const entry of readdirSync(root, { withFileTypes: true })) { const path = resolve(root, entry.name), stat = lstatSync(path); if (stat.isSymbolicLink()) entries.push([path, stat.mtimeMs, 'link', readlinkSync(path)]); else if (entry.isDirectory()) entries.push(...snapshot(path)); else entries.push([path, stat.mtimeMs, hash(readFileSync(path))]); }
  return entries;
}
for (const owner of ['foss-earth', 'UMN-VR', '0sfs']) {
  const name = owner === 'foss-earth' ? 'earth' : owner === 'UMN-VR' ? 'campus' : 'flight';
  const root = resolve(consumer, `build/workspace ${name}`);
  const manifest = { schemaVersion: 1, id: `synthetic-${name}`, version: '1.0.0', owner,
    repositories: [
      { id: 'library', repository: 'fixture/library', source: pathToFileURL(source).href, revision, destination: 'library', dependsOn: [], steps: [] },
      { id: 'app', repository: owner === 'foss-earth' ? 'foss-earth/app' : 'fixture/app', source: pathToFileURL(source).href, revision, destination: 'app', dependsOn: ['library', 'content'], steps: [{ id: 'build', kind: 'build', argv: ['node', 'build.mjs'], outputs: ['dist/receipt.json'] }, { id: 'check', kind: 'check', argv: ['node', '-e', 'if(!require("node:fs").existsSync("dist/receipt.json"))process.exit(3)'], outputs: [] }] }
    ], artifacts: [{ id: 'content', location: pathToFileURL(content).href, sha256: hash(bytes), sizeBytes: bytes.length, destination: 'artifacts/content.bin' }], defaultComponents: ['app'], selections: { library: ['library'] }, prerequisites: [{ id: 'node', argv: ['node', '--version'], minimumVersion: '22.0.0' }] };
  assert.deepEqual(selectComponents(validateManifest(manifest, root), ['library']).map(item => item.id), ['library']);
  if (owner !== '0sfs') assert.ok(!manifest.repositories.some(item => item.repository.startsWith('0sfs/')));
  const manifestBytes = Buffer.from(JSON.stringify(manifest)), manifestPath = resolve(scratch, `${name}-manifest.json`); writeFileSync(manifestPath, manifestBytes);
  const bootstrap = { schemaVersion: 1, manifest: { location: pathToFileURL(manifestPath).href, sha256: hash(manifestBytes), sizeBytes: manifestBytes.length, revision, owner } }; validateBootstrapDescriptor(bootstrap);
  const bootstrapPath = resolve(scratch, `${name}-bootstrap.json`); writeFileSync(bootstrapPath, JSON.stringify(bootstrap));
  const absentDoctor = await runCli({ args: ['doctor', '--root', root], bootstrap, write: quiet }); assert.equal(absentDoctor.exitCode, 2); assert.equal(existsSync(root), false);
  let bootstrapPlanBeforeWrites = false;
  const first = await runCli({ args: ['init', '--root', root, '--apply'], bootstrap, write: text => { const event = JSON.parse(text); if (event.event === 'plan' && event.plan[0]?.kind === 'bootstrap-manifest') { assert.equal(existsSync(root), false); bootstrapPlanBeforeWrites = true; } } }); assert.equal(first.exitCode, 0); assert.equal(bootstrapPlanBeforeWrites, true); assert.deepEqual(first.selection, ['library', 'content', 'app']);
  const cached = await bootstrapManifest({ descriptor: bootstrap, root, readOnly: true }); assert.equal(cached.digest, hash(manifestBytes));
  const repeat = await runCli({ args: ['init', '--root', root, '--apply'], bootstrap, write: quiet }); assert.equal(repeat.exitCode, 0); assert.ok(repeat.steps.some(step => step.reused)); assert.equal(readFileSync(resolve(root, 'app/build/count'), 'utf8'), '1');
  const before = snapshot(root), doctor = await runCli({ args: ['doctor', '--root', root], bootstrap, write: quiet }); assert.equal(doctor.exitCode, 0); assert.deepEqual(snapshot(root), before);
  assert.equal((await runCli({ args: ['sync', '--root', root, '--apply'], bootstrap, write: quiet })).exitCode, 0);
  assert.equal((await runCli({ args: ['check', '--root', root], bootstrap, write: quiet })).exitCode, 0);
  const selectedRoot = `${root} selected`, selected = await runCli({ args: ['init', '--root', selectedRoot, '--select', 'library', '--apply'], bootstrap, write: quiet }); assert.equal(selected.exitCode, 0); assert.deepEqual(selected.selection, ['library']); assert.equal(existsSync(resolve(selectedRoot, 'app')), false);
  const bin = owner === 'foss-earth' ? 'bin/earth.mjs' : 'bin/workspace.mjs';
  const cli = spawnSync(process.execPath, [resolve(installed, bin), 'doctor', '--bootstrap', bootstrapPath, '--root', root], { cwd: consumer, encoding: 'utf8', env: { ...process.env, NODE_PATH: '' } }); assert.equal(cli.status, 0); assert.equal(JSON.parse(cli.stdout).clean, true);
  writeFileSync(resolve(scratch, `${name}-standalone-doctor.json`), cli.stdout);
  ownerReceipts.push({ owner, syntheticOnly: true, realApplicationQualified: false, noFlightDependency: owner !== '0sfs', bootstrapPlanBeforeWrites, fullDefault: first.selection, selected: selected.selection, first: first.exitCode, repeat: repeat.exitCode, doctor: doctor.exitCode, sync: 0, check: 0, standaloneBin: bin, standaloneDoctor: cli.status, manifestSha256: hash(manifestBytes), revision });
}
const missingDefault = spawnSync(process.execPath, [resolve(installed, 'bin/earth.mjs'), 'init', '--root', resolve(consumer, 'build/missing-default')], { cwd: consumer, encoding: 'utf8', env: { ...process.env, NODE_PATH: '' } }); assert.equal(missingDefault.status, 2); assert.equal(JSON.parse(missingDefault.stdout).issues[0].rule, 'bootstrap.unavailable'); assert.equal(existsSync(resolve(consumer, 'build/missing-default')), false);

// Exercise the new mode through installed exports and the real standalone bin.
const sourcePackage = '@fixture/shared', sourcePackageVersion = '1.0.0', sourceRepos = [];
const sourceArtifactFiles = { 'package.json': JSON.stringify({ name: sourcePackage, version: sourcePackageVersion, type: 'module', exports: { '.': './dist/index.mjs' } }), 'dist/index.mjs': 'export const identity = "installed-immutable-package";\n' };
const sourceArtifactBytes = Buffer.from(JSON.stringify(sourceArtifactFiles)), sourceArtifactPath = resolve(scratch, 'linked-package.json'); writeFileSync(sourceArtifactPath, sourceArtifactBytes);
const sourceInstalledIdentity = { name: sourcePackage, version: sourcePackageVersion, artifact: 'linked-package', files: Object.fromEntries(Object.entries(sourceArtifactFiles).map(([path, bytes]) => [path, hash(bytes)])) };
for (const id of ['shared', 'earth', 'campus']) {
  const path = resolve(scratch, `linked-source-${id}`); mkdirSync(path); git(['init', '--quiet', '--initial-branch=main'], path);
  writeFileSync(resolve(path, '.gitignore'), '/dist/\n/build/\n/node_modules/\n');
  if (id === 'shared') {
    writeFileSync(resolve(path, 'package.json'), JSON.stringify({ name: sourcePackage, version: sourcePackageVersion, type: 'module', exports: { '.': './dist/index.mjs' } }));
    writeFileSync(resolve(path, 'build.mjs'), 'import{mkdirSync,writeFileSync,readFileSync,existsSync}from"node:fs";mkdirSync("build",{recursive:true});mkdirSync("dist",{recursive:true});const count=existsSync("build/count")?Number(readFileSync("build/count")):0;writeFileSync("build/count",String(count+1));writeFileSync("dist/index.mjs",`export const identity = "installed-source-provider";\\n`);');
  } else {
    writeFileSync(resolve(path, 'build.mjs'), 'import{identity}from"@fixture/shared";import{mkdirSync,writeFileSync,realpathSync}from"node:fs";mkdirSync("dist",{recursive:true});writeFileSync("dist/receipt.json",JSON.stringify({identity,providerRealpath:realpathSync("node_modules/@fixture/shared")}));');
    writeFileSync(resolve(path, 'install.mjs'), 'import{mkdirSync,writeFileSync,readFileSync,existsSync,lstatSync}from"node:fs";import{resolve,dirname}from"node:path";const root="node_modules/@fixture/shared";if(existsSync(root)&&lstatSync(root).isSymbolicLink())throw Error("install reached source");for(const[file,bytes]of Object.entries(JSON.parse(readFileSync(process.argv[2])))){mkdirSync(dirname(resolve(root,file)),{recursive:true});writeFileSync(resolve(root,file),bytes);}');
  }
  git(['add', '.'], path); git(['-c', 'user.name=Fixture Human', '-c', 'user.email=fixture@example.invalid', 'commit', '--quiet', '-m', 'Synthetic installed source-workspace fixture'], path);
  sourceRepos.push({ id, repository: `fixture/${id}`, source: pathToFileURL(path).href, revision: git(['rev-parse', 'HEAD'], path), destination: id === 'shared' ? 'providers/shared' : `applications/${id}`, dependsOn: id === 'shared' ? [] : ['shared', 'linked-package'], installedPackages: id === 'shared' ? [] : [sourceInstalledIdentity], steps: [...id === 'shared' ? [] : [{ id: 'install', kind: 'install', argv: ['node', 'install.mjs', '{artifact:linked-package}'], outputs: Object.keys(sourceArtifactFiles).map(path => `node_modules/${sourcePackage}/${path}`) }], { id: 'build', kind: 'build', argv: ['node', 'build.mjs'], outputs: [id === 'shared' ? 'dist/index.mjs' : 'dist/receipt.json'] }] });
}
sourceRepos.find(repo => repo.id === 'earth').repository = 'foss-earth/app';
const sourceManifest = { schemaVersion: 1, id: 'installed-source-workspace', version: '1', owner: 'foss-earth', repositories: sourceRepos, artifacts: [{ id: 'linked-package', location: pathToFileURL(sourceArtifactPath).href, destination: 'artifacts/linked-package.json', sha256: hash(sourceArtifactBytes), sizeBytes: sourceArtifactBytes.length }], defaultComponents: ['earth', 'campus'], links: ['earth', 'campus'].map(id => ({ consumer: id, provider: 'shared', package: sourcePackage, version: sourcePackageVersion, outputs: ['dist/index.mjs'] })) };
const sourceManifestPath = resolve(scratch, 'source-workspace.json'); writeFileSync(sourceManifestPath, JSON.stringify(sourceManifest));
const sourceRoot = resolve(consumer, 'build/source workspace'), sourceFirst = standalone(['init', '--manifest', sourceManifestPath, '--root', sourceRoot, '--apply'], 'source-standalone-init.log'); assert.equal(sourceFirst.exitCode, 0); assert.equal(sourceFirst.mode, 'source');
const sourceProvider = realpathSync(resolve(sourceRoot, 'providers/shared')); assert.equal(sourceFirst.sourceLinks.length, 2); assert.ok(sourceFirst.sourceLinks.every(link => link.ready && link.resolved && link.providerRealpath === sourceProvider));
for (const id of ['earth', 'campus']) { const receipt = JSON.parse(readFileSync(resolve(sourceRoot, `applications/${id}/dist/receipt.json`))); assert.equal(receipt.identity, 'installed-source-provider'); assert.equal(receipt.providerRealpath, sourceProvider); }
const sourceRepeat = await runCli({ args: ['init', '--manifest', sourceManifestPath, '--root', sourceRoot, '--apply'], mode: 'source', write: quiet }); assert.equal(sourceRepeat.exitCode, 0); assert.ok(sourceRepeat.steps.filter(step => step.fingerprint).every(step => step.reused)); assert.equal(readFileSync(resolve(sourceProvider, 'build/count'), 'utf8'), '1');
const sourceBeforeDoctor = snapshot(sourceRoot), sourceDoctor = spawnSync(process.execPath, [resolve(installed, 'bin/earth.mjs'), 'doctor', '--manifest', sourceManifestPath, '--root', sourceRoot], { cwd: consumer, encoding: 'utf8', env: { ...process.env, NODE_PATH: '' } }); assert.equal(sourceDoctor.status, 0); assert.equal(JSON.parse(sourceDoctor.stdout).mode, 'source'); assert.deepEqual(snapshot(sourceRoot), sourceBeforeDoctor);
writeFileSync(resolve(scratch, 'source-standalone-doctor.json'), sourceDoctor.stdout);

function standalone(args, log) {
  const run = spawnSync(process.execPath, [resolve(installed, 'bin/earth.mjs'), ...args], { cwd: consumer, encoding: 'utf8', env: { ...process.env, NODE_PATH: '' } });
  writeFileSync(resolve(scratch, log), run.stdout + run.stderr);
  assert.equal(run.status, 0); return JSON.parse(run.stdout.slice(run.stdout.lastIndexOf('\n{\n') + 1));
}
const exactRoot = resolve(consumer, 'build/installed exact workspace'), installedExact = standalone(['init', '--manifest', sourceManifestPath, '--root', exactRoot, '--mode', 'exact', '--apply'], 'exact-standalone-init.log'); assert.equal(installedExact.mode, 'exact'); assert.equal(installedExact.sourceLinks.length, 0); assert.ok(installedExact.installedPackages.every(row => row.valid));
for (const id of ['earth', 'campus']) { const path = resolve(exactRoot, `applications/${id}/node_modules/${sourcePackage}`); assert.equal(lstatSync(path).isSymbolicLink(), false); for (const [file, bytes] of Object.entries(sourceArtifactFiles)) assert.equal(readFileSync(resolve(path, file), 'utf8'), bytes); }
const exactBefore = snapshot(exactRoot); assert.equal(standalone(['doctor', '--manifest', sourceManifestPath, '--root', exactRoot, '--mode', 'exact'], 'exact-standalone-doctor.log').mode, 'exact'); assert.deepEqual(snapshot(exactRoot), exactBefore);
const hybridRoot = resolve(consumer, 'build/installed hybrid workspace');
const hybridFirst = standalone(['init', '--manifest', sourceManifestPath, '--root', hybridRoot, '--mode', 'hybrid', '--component', 'shared=package', '--apply'], 'hybrid-standalone-init.log'); assert.equal(hybridFirst.exitCode, 0); assert.equal(existsSync(resolve(hybridRoot, 'providers/shared')), false); assert.equal(hybridFirst.repositories.some(repo => repo.id === 'shared'), false);
const hybridRepeat = await runCli({ args: ['init', '--manifest', sourceManifestPath, '--root', hybridRoot, '--apply'], mode: 'source', write: quiet }); assert.equal(hybridRepeat.exitCode, 0); assert.equal(hybridRepeat.mode, 'hybrid'); assert.ok(hybridRepeat.steps.filter(step => step.fingerprint).every(step => step.reused));
const hybridSource = standalone(['init', '--manifest', sourceManifestPath, '--root', hybridRoot, '--component', 'shared=source', '--apply'], 'hybrid-standalone-source-switch.log'); assert.equal(hybridSource.exitCode, 0); const hybridProvider = realpathSync(resolve(hybridRoot, 'providers/shared')); assert.ok(hybridSource.sourceLinks.every(link => link.resolved && link.providerRealpath === hybridProvider));
const retainedSource = snapshot(hybridProvider), hybridPackage = standalone(['sync', '--manifest', sourceManifestPath, '--root', hybridRoot, '--component', 'shared=package', '--apply'], 'hybrid-standalone-package-switch.log'); assert.equal(hybridPackage.exitCode, 0); assert.deepEqual(snapshot(hybridProvider), retainedSource); assert.ok(hybridPackage.installedPackages.every(row => row.valid));
const hybridBeforeDoctor = snapshot(hybridRoot), hybridDoctor = standalone(['doctor', '--manifest', sourceManifestPath, '--root', hybridRoot], 'hybrid-standalone-doctor.log'); assert.equal(hybridDoctor.mode, 'hybrid'); assert.equal(hybridDoctor.choices.components.shared, 'package'); assert.deepEqual(snapshot(hybridRoot), hybridBeforeDoctor);

const packageRoot = resolve(consumer, 'build/installed package workspace');
const packageFirst = standalone(['init', '--manifest', sourceManifestPath, '--root', packageRoot, '--mode', 'package', '--apply'], 'package-standalone-init.log'); assert.equal(packageFirst.mode, 'package'); assert.equal(existsSync(resolve(packageRoot, 'providers/shared')), false); assert.ok(packageFirst.installedPackages.every(row => row.valid));
const packageRepeat = standalone(['init', '--manifest', sourceManifestPath, '--root', packageRoot, '--apply'], 'package-standalone-repeat.log'); assert.equal(packageRepeat.mode, 'package'); assert.ok(packageRepeat.steps.filter(step => step.fingerprint).every(step => step.reused));
const packageBeforeDoctor = snapshot(packageRoot); assert.equal(standalone(['doctor', '--manifest', sourceManifestPath, '--root', packageRoot], 'package-standalone-doctor.log').mode, 'package'); assert.deepEqual(snapshot(packageRoot), packageBeforeDoctor);

// Narrowing one consumer cannot discard another consumer's managed-link witness.
writeFileSync(resolve(sourceProvider, 'build.mjs'), readFileSync(resolve(sourceProvider, 'build.mjs'), 'utf8') + '\n// retained synthetic dirty provider\n');
const dirtyProvider = snapshot(sourceProvider), untouchedCampus = snapshot(resolve(sourceRoot, 'applications/campus'));
const narrowed = standalone(['sync', '--manifest', sourceManifestPath, '--root', sourceRoot, '--mode', 'hybrid', '--select', 'earth', '--component', 'shared=package', '--apply'], 'narrowed-package-switch.log'); assert.deepEqual(narrowed.choices.selections, ['earth']); assert.deepEqual(snapshot(resolve(sourceRoot, 'applications/campus')), untouchedCampus); assert.deepEqual(snapshot(sourceProvider), dirtyProvider);
assert.deepEqual(standalone(['init', '--manifest', sourceManifestPath, '--root', sourceRoot, '--apply'], 'narrowed-repeat.log').choices.selections, ['earth']);
const expanded = standalone(['sync', '--manifest', sourceManifestPath, '--root', sourceRoot, '--all', '--apply'], 'expanded-package-switch.log'); assert.deepEqual(expanded.choices.selections, []); assert.ok(expanded.installedPackages.every(row => row.valid)); assert.deepEqual(snapshot(sourceProvider), dirtyProvider);
const beforeDirtyActivation = snapshot(sourceRoot);
const dirtyActivation = spawnSync(process.execPath, [resolve(installed, 'bin/earth.mjs'), 'sync', '--manifest', sourceManifestPath, '--root', sourceRoot, '--component', 'shared=source', '--apply'], { cwd: consumer, encoding: 'utf8', env: { ...process.env, NODE_PATH: '' } }); writeFileSync(resolve(scratch, 'dirty-source-reactivation.log'), dirtyActivation.stdout + dirtyActivation.stderr); assert.equal(dirtyActivation.status, 1); assert.deepEqual(snapshot(sourceRoot), beforeDirtyActivation);

const boundaryReceipts = [];
for (const kind of ['site-only', 'unused-app', 'landing-prerequisite', 'artifact-landing-prerequisite', 'foreign-owner']) {
  const invalid = structuredClone(sourceManifest), earth = invalid.repositories.find(repo => repo.id === 'earth'), campus = invalid.repositories.find(repo => repo.id === 'campus');
  if (kind === 'site-only') earth.repository = 'foss-earth/foss-earth.github.io';
  else if (kind === 'unused-app') { campus.repository = 'foss-earth/foss-earth.github.io'; invalid.defaultComponents = ['campus']; }
  else if (kind === 'landing-prerequisite') { campus.repository = 'foss-earth/foss-earth.github.io'; earth.dependsOn.push('campus'); }
  else if (kind === 'artifact-landing-prerequisite') { campus.repository = 'FOSS-EARTH/foss-earth.github.io'; invalid.artifacts[0].dependsOn = ['campus']; }
  else invalid.owner = 'UMN-VR';
  const path = resolve(scratch, `invalid-earth-${kind}.json`), bytes = Buffer.from(JSON.stringify(invalid)); writeFileSync(path, bytes);
  const descriptorPath = resolve(scratch, `invalid-earth-${kind}-bootstrap.json`); writeFileSync(descriptorPath, JSON.stringify({ schemaVersion: 1, manifest: { location: pathToFileURL(path).href, sha256: hash(bytes), sizeBytes: bytes.length, revision: sourceRepos[0].revision, owner: invalid.owner } }));
  for (const input of ['manifest', 'bootstrap']) {
    const root = resolve(consumer, `build/invalid-earth-${kind}-${input}`), args = ['init', `--${input}`, input === 'manifest' ? path : descriptorPath, '--root', root, '--mode', 'package', '--apply'];
    const run = spawnSync(process.execPath, [resolve(installed, 'bin/earth.mjs'), ...args], { cwd: consumer, encoding: 'utf8', env: { ...process.env, NODE_PATH: '' } }); writeFileSync(resolve(scratch, `${kind}-${input}.log`), run.stdout + run.stderr);
    assert.equal(run.status, 2); const result = JSON.parse(run.stdout.slice(run.stdout.lastIndexOf('\n{\n') + 1)); assert.equal(result.issues[0].rule, 'bootstrap.application'); assert.equal(existsSync(resolve(root, 'applications')), false); assert.equal(existsSync(resolve(root, 'providers')), false); boundaryReceipts.push({ kind, input, rejectedBeforeWorkspaceActions: true });
  }
}
const guardedBytes = Buffer.from(JSON.stringify(sourceManifest)), guardedBootstrapPath = resolve(scratch, 'guarded-earth-bootstrap.json'); writeFileSync(guardedBootstrapPath, JSON.stringify({ schemaVersion: 1, manifest: { location: pathToFileURL(sourceManifestPath).href, sha256: hash(guardedBytes), sizeBytes: guardedBytes.length, revision: sourceRepos[0].revision, owner: 'foss-earth' } }));
const guardedBootstrap = standalone(['init', '--bootstrap', guardedBootstrapPath, '--root', resolve(consumer, 'build/guarded bootstrap'), '--mode', 'package', '--select', 'earth', '--apply'], 'guarded-bootstrap-init.log'); assert.equal(guardedBootstrap.mode, 'package'); assert.equal(guardedBootstrap.selection.includes('campus'), false);
const providerOnlyRoot = resolve(consumer, 'build/provider only bootstrap'), providerOnly = standalone(['init', '--bootstrap', guardedBootstrapPath, '--root', providerOnlyRoot, '--mode', 'source', '--select', 'shared', '--apply'], 'provider-only-bootstrap-init.log'); assert.deepEqual(providerOnly.selection, ['shared']); assert.equal(existsSync(resolve(providerOnlyRoot, 'applications')), false);

const archive = { format: 'tar.gz', destination: 'build/prepared-installer', stripComponents: 1, files: release.archive.files, treeSha256: release.archive.treeSha256, ...release.archive.verificationBounds };
validateArchive(archive, consumer); assert.equal(treeDigest(archive.files), archive.treeSha256);
const firstArchive = await installArchive({ root: consumer, artifactPath, archive }); assert.equal(firstArchive.valid, true); assert.equal(firstArchive.reused, false);
const repeatArchive = await installArchive({ root: consumer, artifactPath, archive, readOnly: true }); assert.equal(repeatArchive.reused, true);
assert.equal((await verifyTree({ root: consumer, archive })).valid, true);
const extra = resolve(consumer, archive.destination, 'unreviewed-directory'); mkdirSync(extra);
assert.equal((await verifyTree({ root: consumer, archive })).valid, false);
await assert.rejects(installArchive({ root: consumer, artifactPath, archive }), error => error.rule === 'archive.conflict'); assert.equal(existsSync(extra), true);
const receipt = { schemaVersion: 1, sourceRevision: release.revision, artifactSha256: release.artifactSha256, sizeBytes: release.sizeBytes, installedRootRegular: true, siblingResolutionDisabled: true, publicExports: Object.keys(identity.exports), publicBins: Object.keys(identity.bin), sealedRuntimeFiles: Object.keys(release.files).length, packageResult, owners: ownerReceipts, sourceWorkspace: { syntheticOnly: true, first: sourceFirst.exitCode, repeat: sourceRepeat.exitCode, standaloneDoctor: sourceDoctor.status, oneProviderRealpath: sourceProvider, sourceLinks: sourceFirst.sourceLinks, providerBuiltOnce: true, immutableReleaseQualified: false }, installedExactOverride: { mode: installedExact.mode, standalone: true, regularImmutableFilesVerified: true, doctorReadOnly: true }, hybridWorkspace: { syntheticOnly: true, first: hybridFirst.exitCode, repeat: hybridRepeat.exitCode, sourceSwitch: hybridSource.exitCode, packageSwitch: hybridPackage.exitCode, persistedMode: hybridDoctor.mode, noPackagedProviderClone: true, sourceLinks: hybridSource.sourceLinks, sameProviderRealpath: hybridProvider, retainedSourcePreserved: true, doctorReadOnly: true, immutableReleaseQualified: false }, archive: { first: firstArchive, repeat: repeatArchive, exactTreeVerified: true, unknownDirectoryRefusedAndPreserved: true }, missingEarthDefaultFailsWithoutWrites: true, platform: { os: process.platform, arch: process.arch, node: process.version }, realApplicationBootstrapQualified: false };
Object.assign(receipt, { packageWorkspace: { syntheticOnly: true, standaloneInit: packageFirst.exitCode, repeat: packageRepeat.exitCode, persistedMode: packageRepeat.mode, noProviderClone: true, doctorReadOnly: true }, narrowedSwitch: { untouchedConsumerPreserved: true, inactiveDirtyProviderPreserved: true, savedSelectionReused: true, expandedManagedLinksSwitched: expanded.exitCode === 0, dirtyReactivationRefusedWithoutWrites: dirtyActivation.status === 1 }, earthApplicationBoundary: { realApplicationQualified: false, guardedBootstrap: guardedBootstrap.exitCode, selectedAppClosureQualified: !guardedBootstrap.selection.includes('campus'), providerOnlySelectionQualified: providerOnly.exitCode === 0 && !existsSync(resolve(providerOnlyRoot, 'applications')), negativeCases: boundaryReceipts } });
writeFileSync(resolve(consumer, 'installed-receipt.json'), JSON.stringify(receipt, null, 2) + '\n', { flag: 'wx' });
process.stdout.write(JSON.stringify(receipt, null, 2) + '\n');
