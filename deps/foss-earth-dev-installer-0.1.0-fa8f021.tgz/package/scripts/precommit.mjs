import { spawnSync } from 'node:child_process';
import { mkdirSync, mkdtempSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
function git(args, cwd = process.cwd(), input) {
  const run = spawnSync('git', ['--no-optional-locks', '-c', 'core.hooksPath=/dev/null', ...args], { cwd, input, encoding: 'utf8' });
  if (run.status !== 0) throw new Error('Commit metadata preflight Git operation failed');
  return run.stdout.trim();
}
const author = git(['var', 'GIT_AUTHOR_IDENT']), committer = git(['var', 'GIT_COMMITTER_IDENT']);
const parent = resolve('build/fixtures/precommit'); git(['check-ignore', '--', parent]); mkdirSync(parent, { recursive: true });
const fixture = mkdtempSync(resolve(parent, 'run-')); git(['init', '--quiet', '--initial-branch=main'], fixture);
const tree = git(['hash-object', '-w', '-t', 'tree', '--stdin'], fixture, ''), message = process.argv[2] ?? 'Shared installer source preflight';
const head = git(['hash-object', '-w', '-t', 'commit', '--stdin', '--literally'], fixture, `tree ${tree}\nauthor ${author}\ncommitter ${committer}\n\n${message}\n`); git(['update-ref', 'refs/heads/main', head], fixture);
const scope = resolve(fixture, 'publication.json'); writeFileSync(scope, JSON.stringify({ schemaVersion: 1, source: { id: 'configured-installer-metadata-fixture', location: fixture }, refs: [{ name: 'refs/heads/main', oid: head }] }));
const run = spawnSync(process.execPath, [resolve('node_modules/@foss-earth/ci/bin/attribution.mjs'), '--repo', fixture, '--refs-file', scope], { encoding: 'utf8' });
const result = JSON.parse(run.stdout); if (run.status !== 0 || !result.complete || !result.clean) throw new Error('Actual installed common entry point rejected configured final commit metadata; no personal data printed');
process.stdout.write(JSON.stringify({ complete: true, clean: true, policy: result.policy, fixtureCommit: head, qualification: 'Configured metadata and exact message only; actual installer publication history is audited after commit' }, null, 2) + '\n');
