import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { safePath, assertDistinct } from './paths.mjs';
import { SetupError } from './process.mjs';
import { validateArchive } from './archive.mjs';
import { validatePackageIdentity } from './packages.mjs';
export const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');
export function exactOid(value) { if (typeof value !== 'string' || !/^(?:[a-f0-9]{40}|[a-f0-9]{64})$/.test(value)) throw new SetupError('manifest.pin', 'Repository revision must be an exact full Git object ID'); return value; }
const identifier = /^[A-Za-z0-9][A-Za-z0-9._-]*$/;
export function validateLocation(value) {
  if (typeof value !== 'string' || !value || /[\0\r\n]/.test(value) || value.startsWith('-')) throw new SetupError('manifest.location', 'Invalid source location');
  if (/^[a-z][a-z0-9+.-]*:/i.test(value)) {
    if (!/^(https|ssh|file):\/\//.test(value)) throw new SetupError('manifest.protocol', 'Only HTTPS, SSH and local file sources are allowed');
    const url = new URL(value);
    if (url.password || (url.protocol === 'https:' && url.username) || url.search) throw new SetupError('manifest.credentials', 'Manifest locations cannot contain credentials or query tokens');
  }
  return value;
}
export function validateArtifactLocation(value) {
  validateLocation(value);
  if (/^[a-z][a-z0-9+.-]*:/i.test(value) && !/^(https|file):\/\//.test(value)) throw new SetupError('artifact.protocol', 'Artifact/manifest acquisition uses HTTPS or local files, not Git/SSH transport');
  return value;
}
export function validateManifest(manifest, root) {
  if (!manifest || manifest.schemaVersion !== 1 || !identifier.test(manifest.id) || typeof manifest.version !== 'string' || !manifest.version || typeof manifest.owner !== 'string' || !manifest.owner || !Array.isArray(manifest.repositories) || !manifest.repositories.length || !Array.isArray(manifest.defaultComponents) || !manifest.defaultComponents.length) throw new SetupError('manifest.schema', 'Manifest needs schemaVersion 1, id/version/owner, repositories and full defaultComponents');
  const items = new Map(), paths = [];
  for (const repo of manifest.repositories) {
    if (!identifier.test(repo.id) || items.has(repo.id) || typeof repo.repository !== 'string' || !/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(repo.repository) || /^(foss-earth\/(search|vr)|0sfs\/vr)$/i.test(repo.repository)) throw new SetupError('manifest.repository', 'Invalid, duplicate or deferred repository');
    exactOid(repo.revision); validateLocation(repo.source); paths.push(repo.destination); safePath(root, repo.destination);
    if (/^(foss-earth|UMN-VR)$/i.test(manifest.owner) && /^0sfs\//i.test(repo.repository)) throw new SetupError('manifest.flight-dependency', 'Earth/campus workspaces must not require or provision flight repositories');
    if (repo.destination.startsWith('build/') || repo.destination === 'build') throw new SetupError('path.reserved', 'Workspace build/ is reserved for installer state/evidence');
    if (!Array.isArray(repo.dependsOn ?? []) || !Array.isArray(repo.steps ?? [])) throw new SetupError('manifest.steps', 'Dependencies and steps must be arrays');
    if (repo.packageDependsOn !== undefined && (!Array.isArray(repo.packageDependsOn) || new Set(repo.packageDependsOn).size !== repo.packageDependsOn.length || repo.packageDependsOn.some(id => !(repo.dependsOn ?? []).includes(id)))) throw new SetupError('manifest.package-dependency', 'packageDependsOn must be distinct IDs from this repository dependsOn; it explicitly declares packaged runtime prerequisites');
    const stepIds = new Set();
    for (const step of repo.steps ?? []) {
      if (!identifier.test(step.id) || stepIds.has(step.id) || !['install', 'build', 'check'].includes(step.kind) || !Array.isArray(step.argv) || !step.argv.length || step.argv.some(arg => typeof arg !== 'string' || /[\0\r\n]/.test(arg)) || ['sudo', 'sh', 'bash', 'zsh', 'cmd', 'powershell', 'rm'].includes(step.argv[0]) || !Array.isArray(step.outputs) || step.outputs.some(p => { safePath(safePath(root, `build/dev-installer/contract-paths/${repo.id}`), p); return false; })) throw new SetupError('manifest.command', 'Steps need distinct IDs, install/build/check kinds, safe argv arrays and declared output paths');
      if (step.optIn !== undefined && typeof step.optIn !== 'string') throw new SetupError('manifest.opt-in', 'Step optIn is a named explicit choice');
      if (step.argv.some(arg => ['--global', '-g'].includes(arg)) || ['corepack', 'brew', 'apt', 'apt-get'].includes(step.argv[0])) throw new SetupError('manifest.global-install', 'System/global tool installation is outside init/sync/check');
      if (step.argv[0] === 'npm' && step.argv[1] === 'run' && ['dev', 'preview', 'watch', 'serve', 'start'].includes(step.argv[2])) throw new SetupError('manifest.server', 'Server/watch startup must be a separate explicit user action');
      if (['cmake', 'make', 'emcc', 'em++'].includes(step.argv[0]) && !step.optIn) throw new SetupError('manifest.native-opt-in', 'Native/WASM work requires an explicit named opt-in');
      stepIds.add(step.id);
    }
    items.set(repo.id, repo);
  }
  for (const artifact of manifest.artifacts ?? []) {
    if (!identifier.test(artifact.id) || items.has(artifact.id) || !/^[a-f0-9]{64}$/.test(artifact.sha256) || !Number.isSafeInteger(artifact.sizeBytes) || artifact.sizeBytes < 0) throw new SetupError('manifest.artifact', 'Artifacts need unique IDs, exact SHA-256 and sizeBytes');
    validateArtifactLocation(artifact.location); safePath(root, artifact.destination); paths.push(artifact.destination);
    if (artifact.destination === 'build' || artifact.destination.startsWith('build/')) throw new SetupError('path.reserved', 'Artifact destination cannot use installer build state');
    if (artifact.archive) {
      validateArchive(artifact.archive, root);
      if (artifact.archive.destination === 'build' || artifact.archive.destination.startsWith('build/')) throw new SetupError('path.reserved', 'Prepared-tree destination cannot use installer build state');
      paths.push(artifact.archive.destination);
    }
    items.set(artifact.id, { ...artifact, artifact: true });
  }
  assertDistinct(paths);
  for (const repo of items.values()) for (const dependency of repo.dependsOn ?? []) if (!items.has(dependency)) throw new SetupError('manifest.dependency', `Missing dependency for ${repo.id}`);
  for (const repo of manifest.repositories) {
    if (!Array.isArray(repo.installedPackages ?? [])) throw new SetupError('package.contract', 'installedPackages must be an array');
    const names = new Set();
    for (const identity of repo.installedPackages ?? []) {
      // Path syntax is validated against an empty evidence namespace so existing
      // package corruption is a diagnosis, not an input-schema side effect.
      validatePackageIdentity(identity, safePath(root, 'build/dev-installer/package-contracts'));
      if (names.has(identity.name) || !items.get(identity.artifact)?.artifact) throw new SetupError('package.contract', 'Package names must be distinct and reference a declared pinned artifact');
      names.add(identity.name);
    }
  }
  for (const prerequisite of manifest.prerequisites ?? []) if (!identifier.test(prerequisite.id) || !Array.isArray(prerequisite.argv) || prerequisite.argv.length !== 2 || prerequisite.argv[1] !== '--version' || !['node', 'npm', 'git', 'python3', 'cmake', 'clang', 'cc'].includes(prerequisite.argv[0])) throw new SetupError('manifest.prerequisite', 'Prerequisites use read-only known-tool --version probes; tool installation is explicit');
  const selections = manifest.selections ?? {};
  for (const group of [manifest.defaultComponents, ...Object.values(selections)]) if (!Array.isArray(group) || !group.length || group.some(id => !items.has(id))) throw new SetupError('manifest.selection', 'Selections must name declared components');
  const visiting = new Set(), visited = new Set();
  function visit(id) { if (visiting.has(id)) throw new SetupError('manifest.cycle', 'Component dependency cycle'); if (visited.has(id)) return; visiting.add(id); for (const dep of items.get(id).dependsOn ?? []) visit(dep); visiting.delete(id); visited.add(id); }
  for (const id of items.keys()) visit(id);
  for (const repo of manifest.repositories) {
    const dependencies = new Set();
    function includeDependency(id) { if (dependencies.has(id)) return; dependencies.add(id); for (const dep of items.get(id).dependsOn ?? []) includeDependency(dep); }
    (repo.dependsOn ?? []).forEach(includeDependency);
    if ((repo.installedPackages ?? []).some(identity => !dependencies.has(identity.artifact))) throw new SetupError('package.dependency', 'Installed package artifact must precede its consumer through dependency closure');
  }
  const defaults = new Set();
  function include(id) { if (defaults.has(id)) return; defaults.add(id); for (const dep of items.get(id).dependsOn ?? []) include(dep); }
  manifest.defaultComponents.forEach(include);
  for (const item of items.values()) if (item.optional !== true && !defaults.has(item.id)) throw new SetupError('manifest.incomplete-default', 'Full default must include every nonoptional component and dependency');
  if (!Array.isArray(manifest.links ?? [])) throw new SetupError('manifest.link', 'Links must be an array of declared package edges');
  for (const link of manifest.links ?? []) {
    if (!items.has(link.consumer) || !items.has(link.provider) || items.get(link.consumer).artifact || items.get(link.provider).artifact || typeof link.package !== 'string' || !/^(?:@[a-z0-9._-]+\/)?[a-z0-9._-]+$/.test(link.package)) throw new SetupError('manifest.link', 'Links require declared repository consumer/provider and a valid package name');
    if (link.version !== undefined && (typeof link.version !== 'string' || !/^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?$/.test(link.version))) throw new SetupError('manifest.link-version', 'Source link version must be an exact package version, never a dependency range');
    if (link.outputs !== undefined && (!Array.isArray(link.outputs) || !link.outputs.length || new Set(link.outputs).size !== link.outputs.length)) throw new SetupError('manifest.link-outputs', 'Source link outputs must name distinct required public files');
    for (const output of link.outputs ?? []) safePath(safePath(root, 'build/dev-installer/link-contracts'), output);
  }
  if (new Set((manifest.links ?? []).map(link => `${link.consumer}\0${link.package}`)).size !== (manifest.links ?? []).length) throw new SetupError('manifest.link', 'Every consumer/package link must have one unique provider');
  if (manifest.verification?.maxFileBytes !== undefined && (!Number.isSafeInteger(manifest.verification.maxFileBytes) || manifest.verification.maxFileBytes < 1)) throw new SetupError('manifest.verification', 'verification.maxFileBytes must be a positive byte limit');
  if (manifest.transport && (typeof manifest.transport !== 'object' || Array.isArray(manifest.transport) || Object.keys(manifest.transport).some(key => !['maxRedirects', 'requestTimeoutSeconds'].includes(key)) || !Number.isSafeInteger(manifest.transport.maxRedirects) || manifest.transport.maxRedirects < 0 || !Number.isSafeInteger(manifest.transport.requestTimeoutSeconds) || manifest.transport.requestTimeoutSeconds < 1)) throw new SetupError('manifest.transport', 'Transport accepts only nonnegative maxRedirects and positive requestTimeoutSeconds');
  return { manifest, items };
}
export function selectComponents(validated, selections = []) {
  const { manifest, items } = validated, ordered = [], selected = new Set();
  const roots = selections.length ? selections.flatMap(id => Object.hasOwn(manifest.selections ?? {}, id) ? manifest.selections[id] : [id]) : manifest.defaultComponents;
  function visit(id) { if (!items.has(id)) throw new SetupError('manifest.selection', `Unknown selection ${id}`); if (selected.has(id)) return; for (const dep of items.get(id).dependsOn ?? []) visit(dep); selected.add(id); ordered.push(items.get(id)); }
  roots.forEach(visit); return ordered;
}
export function readManifest(path, expectedDigest) {
  const bytes = readFileSync(path), digest = sha256(bytes);
  if (expectedDigest && digest !== expectedDigest) throw new SetupError('manifest.digest', 'Manifest artifact digest mismatch');
  return { manifest: JSON.parse(bytes), digest };
}
