import { readFileSync, mkdirSync, existsSync, createReadStream, createWriteStream, statSync, renameSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { Readable, Transform } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { createHash, randomUUID } from 'node:crypto';
import { dirname } from 'node:path';
import { safePath } from './paths.mjs';
import { sha256, validateArtifactLocation, exactOid } from './manifest.mjs';
import { SetupError } from './process.mjs';

export async function hashFile(path) {
  const hash = createHash('sha256');
  for await (const bytes of createReadStream(path)) hash.update(bytes);
  return hash.digest('hex');
}
export async function acquire({ location, sha256: expected, sizeBytes, root, destination, readOnly = false, maxRedirects = 5, requestTimeoutSeconds = 30, fetchImpl = fetch }) {
  validateArtifactLocation(location);
  const target = safePath(root, destination);
  if (existsSync(target)) {
    if (statSync(target).size !== sizeBytes || await hashFile(target) !== expected) throw new SetupError('artifact.corrupt', 'Existing artifact differs from exact size/digest; preserve it and resolve the conflict explicitly');
    return { path: target, sha256: expected, reused: true, sizeBytes };
  }
  if (readOnly) throw new SetupError('artifact.missing', 'Exact artifact is missing; run explicit init to acquire it');
  const staging = safePath(root, `build/dev-installer/downloads/${expected}-${randomUUID()}.partial`);
  mkdirSync(dirname(staging), { recursive: true });
  let input;
  if (/^https:\/\//.test(location)) {
    if (!Number.isSafeInteger(maxRedirects) || maxRedirects < 0 || !Number.isSafeInteger(requestTimeoutSeconds) || requestTimeoutSeconds <= 0) throw new SetupError('artifact.transport-bounds', 'Redirect count and request timeout must have valid integer bounds');
    let current = location, response;
    for (let redirects = 0; ; redirects++) {
      response = await fetchImpl(current, { headers: { 'user-agent': 'foss-earth-setup/1.0' }, redirect: 'manual', signal: AbortSignal.timeout(requestTimeoutSeconds * 1000) });
      if (![301, 302, 303, 307, 308].includes(response.status)) break;
      const next = response.headers.get('location');
      if (!next || redirects >= maxRedirects) throw new SetupError('artifact.redirect-limit', 'Artifact redirect chain exceeds the declared maximum');
      const url = new URL(next, current);
      if (url.protocol !== 'https:' || url.username || url.password) throw new SetupError('artifact.redirect-protocol', 'Only credential-free HTTPS redirect targets are allowed');
      await response.body?.cancel();
      // Host-issued signed query URLs may be followed; no user credentials/authorization are forwarded.
      current = url.href;
    }
    if (!response.ok || !response.body) throw new SetupError('artifact.unavailable', 'Artifact source unavailable; retained workspace is repairable');
    const length = response.headers.get('content-length');
    if (length && Number(length) !== sizeBytes) throw new SetupError('artifact.size', 'Artifact source declared a different size');
    input = Readable.fromWeb(response.body);
  } else if (/^file:\/\//.test(location) || !/^[a-z][a-z0-9+.-]*:/i.test(location)) {
    input = createReadStream(location.startsWith('file:') ? fileURLToPath(location) : location);
  } else throw new SetupError('artifact.protocol', 'Artifact downloads use HTTPS or local files, not Git transport');
  let received = 0; const hash = createHash('sha256');
  const verify = new Transform({ transform(bytes, _encoding, callback) { received += bytes.length; if (received > sizeBytes) callback(new SetupError('artifact.size', 'Artifact exceeds declared byte limit')); else { hash.update(bytes); callback(null, bytes); } } });
  await pipeline(input, verify, createWriteStream(staging, { flags: 'wx' }));
  if (received !== sizeBytes || hash.digest('hex') !== expected) throw new SetupError('artifact.digest', 'Downloaded artifact failed exact size/digest; staged bytes retained for diagnosis');
  mkdirSync(dirname(target), { recursive: true });
  if (existsSync(target)) throw new SetupError('artifact.conflict', 'Artifact destination appeared during acquisition; no overwrite performed');
  safePath(root, destination); renameSync(staging, target);
  return { path: target, sha256: expected, reused: false, sizeBytes };
}
export function validateBootstrapDescriptor(descriptor) {
  if (descriptor?.schemaVersion !== 1 || !descriptor.manifest || !/^[a-f0-9]{64}$/.test(descriptor.manifest.sha256) || !Number.isSafeInteger(descriptor.manifest.sizeBytes) || descriptor.manifest.sizeBytes < 1 || typeof descriptor.manifest.owner !== 'string' || !descriptor.manifest.owner) throw new SetupError('bootstrap.schema', 'Pinned bootstrap requires manifest owner/revision/location/SHA-256/sizeBytes');
  exactOid(descriptor.manifest.revision);
  validateArtifactLocation(descriptor.manifest.location);
  if (descriptor.manifest.maxRedirects !== undefined && (!Number.isSafeInteger(descriptor.manifest.maxRedirects) || descriptor.manifest.maxRedirects < 0) || descriptor.manifest.requestTimeoutSeconds !== undefined && (!Number.isSafeInteger(descriptor.manifest.requestTimeoutSeconds) || descriptor.manifest.requestTimeoutSeconds < 1)) throw new SetupError('bootstrap.transport', 'Bootstrap transport bounds must be valid integers');
  return descriptor;
}
export async function bootstrapManifest({ descriptor, root, readOnly = false }) {
  validateBootstrapDescriptor(descriptor);
  const record = await acquire({ ...descriptor.manifest, root, destination: `build/dev-installer/bootstrap/${descriptor.manifest.sha256}.json`, readOnly });
  const manifest = JSON.parse(readFileSync(record.path));
  if (manifest.owner !== descriptor.manifest.owner) throw new SetupError('bootstrap.owner', 'Manifest owner differs from the pinned wrapper descriptor');
  return { manifest, digest: descriptor.manifest.sha256, record };
}
