import { lstatSync } from 'node:fs';
import { resolve, relative, isAbsolute, dirname } from 'node:path';
import { SetupError } from './process.mjs';
export function relativePath(root, destination) {
  if (typeof destination !== 'string' || !destination || isAbsolute(destination) || destination.includes('\\') || destination.split('/').some(part => !part || part === '.' || part === '..' || /[. ]$/.test(part)) || /[\0\r\n]/.test(destination)) throw new SetupError('path.escape', 'Destinations must be normalized relative paths inside the workspace, without trailing-dot/space aliases');
  const base = resolve(root), path = resolve(base, destination), rel = relative(base, path);
  if (rel.startsWith('..') || isAbsolute(rel) || !rel) throw new SetupError('path.escape', 'Path escapes the workspace');
  return path;
}
export function safePath(root, destination, { allowLeafSymlink = false } = {}) {
  const path = relativePath(root, destination);
  for (let current = path; current !== dirname(current); current = dirname(current)) {
    let stat;
    try { stat = lstatSync(current); } catch (error) { if (error.code === 'ENOENT') continue; throw error; }
    if (stat.isSymbolicLink() && !(current === path && allowLeafSymlink)) throw new SetupError('path.symlink', 'Workspace paths must not traverse a symbolic link, including dangling links');
  }
  return path;
}
export function assertDistinct(paths) {
  const aliases = paths.map(path => path.normalize('NFKC').toLowerCase());
  for (let i = 0; i < paths.length; i++) for (let j = i + 1; j < paths.length; j++) if (aliases[i] === aliases[j] || aliases[i].startsWith(`${aliases[j]}/`) || aliases[j].startsWith(`${aliases[i]}/`)) throw new SetupError('path.collision', 'Manifest destinations overlap through a portable filesystem alias');
}
