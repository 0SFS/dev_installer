import { existsSync, mkdirSync, readFileSync, writeFileSync, appendFileSync, renameSync, statSync, readdirSync, symlinkSync, lstatSync, realpathSync } from 'node:fs';
import { resolve, dirname, relative } from 'node:path';
import { randomUUID } from 'node:crypto';
import { command, git, SetupError } from './process.mjs';
import { safePath, relativePath, assertDistinct } from './paths.mjs';
import { validateManifest, selectComponents, sha256 } from './manifest.mjs';
import { acquire, hashFile } from './bootstrap.mjs';
import { verifyTree, installArchive } from './archive.mjs';
import { verifyPackageIdentity } from './packages.mjs';
import { workspaceChoices, selectHybrid } from './choices.mjs';

function stateOf(path, item) {
  if (!existsSync(path)) return { exists: false, missing: true };
  const top = git(path, ['rev-parse', '--show-toplevel'], true);
  if (top.status !== 0 || resolve(top.stdout.trim()) !== resolve(path)) return { exists: true, conflict: 'Destination is not the intended standalone repository' };
  if (git(path, ['rev-parse', '--absolute-git-dir']).stdout.trim() !== resolve(path, '.git')) return { exists: true, conflict: 'Linked worktree or external Git directory is outside the safe standalone checkout contract' };
  const revision = git(path, ['rev-parse', 'HEAD']).stdout.trim();
  const dirty = git(path, ['status', '--porcelain', '--untracked-files=normal']).stdout.trim().length > 0;
  const origin = git(path, ['remote', 'get-url', 'origin'], true);
  const sourceMatches = origin.status === 0 && origin.stdout.trim() === item.source;
  const targetAvailable = git(path, ['cat-file', '-e', `${item.revision}^{commit}`], true).status === 0;
  const divergence = targetAvailable ? git(path, ['merge-base', '--is-ancestor', revision, item.revision], true).status !== 0 : null;
  return { exists: true, revision, dirty, sourceMatches, compatible: revision === item.revision, diverged: divergence, targetAvailable, remoteFreshness: 'unknown; offline doctor does not fetch' };
}
function outputsDigest(path, outputs, limit = 64 * 1024 * 1024, linkedOutputs = new Map()) {
  const values = [];
  function resolveOutput(base, output, followed = new Set()) {
    const target = relativePath(base, output);
    // Resolve the outermost declared link first; each next hop is authenticated
    // in its actual provider context. Undeclared symlinks still fail safePath.
    const mounts = [...linkedOutputs].filter(([mount]) => target.startsWith(`${mount}/`)).sort(([a], [b]) => a.length - b.length);
    if (!mounts.length) return safePath(base, output);
    const [mount, provider] = mounts[0];
    const installed = safePath(base, relative(base, mount), { allowLeafSymlink: true });
    if (!existsSync(installed) || !lstatSync(installed).isSymbolicLink()) return null;
    if (!existsSync(provider) || realpathSync(installed) !== realpathSync(provider)) throw new SetupError('links.conflict', 'Output link does not resolve to the declared provider');
    if (followed.has(mount)) throw new SetupError('links.cycle', 'Declared output source-link chain creates a cycle');
    return resolveOutput(provider, target.slice(mount.length + 1), new Set([...followed, mount]));
  }
  for (const output of outputs) {
    const target = resolveOutput(path, output);
    if (!target || !existsSync(target)) return null;
    const stat = statSync(target);
    if (!stat.isFile() || stat.size > limit) throw new SetupError('output.verification', 'Declared output must be a regular file within verification.maxFileBytes; declare exact artifact receipts for directories');
    values.push([output, sha256(readFileSync(target))]);
  }
  return sha256(JSON.stringify(values));
}
export async function workspace({ action, root, manifest, digest, selections, apply = false, links, mode, defaultMode, components, optIns = [], onPlan = () => {} }) {
  if (!['init', 'doctor', 'sync', 'check'].includes(action)) throw new SetupError('workspace.action', 'Unsupported operation');
  if (!/^[a-f0-9]{64}$/.test(digest)) throw new SetupError('manifest.digest', 'Operations require the verified manifest artifact SHA-256');
  const validated = validateManifest(manifest, root);
  const explicitLinks = links !== undefined;
  const choices = workspaceChoices({ root, validated, mode, defaultMode, components, links, selections });
  mode = choices.mode; links = choices.links; selections = choices.selections;
  const sourceMode = ['source', 'hybrid', 'package'].includes(mode), hybrid = mode === 'hybrid' || mode === 'package' ? selectHybrid(validated, selections, choices.components, mode === 'package') : null;
  let selected = hybrid?.selected ?? selectComponents(validated, selections);
  const result = { schemaVersion: 1, action, manifest: { id: manifest.id, version: manifest.version, sha256: digest }, mode: sourceMode ? mode : Object.keys(links).length ? 'local-link' : 'exact', qualification: sourceMode || Object.keys(links).length ? 'source-development; immutable release verification required separately' : 'exact-inputs; publication/admission required separately', choices: { ...choices.preferences, persisted: choices.persisted, changed: choices.changed, status: choices.previous?.status ?? 'absent', applied: choices.previous?.applied ?? null }, selection: selected.map(i => i.id), plan: [], prerequisites: [], repositories: [], artifacts: [], installedPackages: [], sourceLinks: [], steps: [], issues: [], complete: false, clean: false };
  const locations = new Map(selected.filter(i => !i.artifact).map(i => [i.id, safePath(root, links[i.id] ?? i.destination)]));
  assertDistinct([...locations.values(), ...selected.filter(i => i.artifact).flatMap(i => [safePath(root, i.destination), ...i.archive ? [safePath(root, i.archive.destination)] : []])]);
  if (Object.keys(links).some(id => !validated.items.has(id) || validated.items.get(id).artifact || (!locations.has(id) && explicitLinks && !(hybrid && hybrid.choice(id) === 'package')))) throw new SetupError('links.selection', 'Explicit overrides must refer to selected source or retained packaged repositories; saved inactive repository paths are retained without activation');
  for (const path of Object.values(links)) safePath(root, path);
  const packageMounts = [], allEdges = [];
  if (hybrid) {
    function project(consumer, path, owner, parents = [], ancestors = []) {
      if (ancestors.includes(consumer)) throw new SetupError('links.cycle', 'Hybrid installed public package graph creates a cycle');
      for (const edge of (manifest.links ?? []).filter(edge => edge.consumer === consumer && (!parents.length || validated.items.get(consumer).packageDependsOn === undefined || validated.items.get(consumer).packageDependsOn.includes(edge.provider)))) {
        if (!(validated.items.get(consumer).dependsOn ?? []).includes(edge.provider)) throw new SetupError('links.selection', 'Hybrid public package edges require direct dependency declarations; no provider is selected implicitly');
        const link = { ...edge, owner, consumerRoot: path, parents, mountId: `${relative(resolve(root), path)}/${edge.package}` };
        allEdges.push(link);
        if (hybrid.choice(edge.provider) !== 'package') continue;
        const identity = validated.items.get(consumer).installedPackages?.find(identity => identity.name === edge.package);
        if (!identity) throw new SetupError('choices.package', 'Packaged public dependency needs its consumer installedPackages identity');
        const mount = { component: edge.provider, path: resolve(path, `node_modules/${edge.package}`), owner, identity, link };
        packageMounts.push(mount); project(edge.provider, mount.path, owner, [...parents, mount], [...ancestors, consumer]);
      }
    }
    for (const [id, path] of locations) project(id, path, id);
  } else allEdges.push(...(manifest.links ?? []).filter(link => locations.has(link.consumer)));
  const activeLinks = allEdges.filter(link => hybrid ? hybrid.choice(link.provider) === 'source' : sourceMode || links[link.provider]);
  const packageTransitions = [];
  const managedLinks = new Map((choices.previous?.managedLinks ?? []).map(witness => [`${witness.consumerRoot}/${witness.package}`, witness]));
  const ownerOf = link => link.owner ?? link.consumer;
  const consumerPath = link => link.consumerRoot ?? locations.get(link.consumer);
  const linkDestination = link => safePath(consumerPath(link), `node_modules/${link.package}`, { allowLeafSymlink: true });
  const stillLinked = link => { if (blockedMount(link)) return false; try { return lstatSync(linkDestination(link)).isSymbolicLink(); } catch (error) { if (error.code === 'ENOENT') return false; throw error; } };
  const sameLink = (row, link) => row.consumer === link.consumer && row.package === link.package && row.consumerRoot === relative(resolve(root), consumerPath(link));
  const blockedMount = link => link.parents?.some(parent => { try { return lstatSync(safePath(root, relative(resolve(root), parent.path), { allowLeafSymlink: true })).isSymbolicLink(); } catch (error) { if (error.code === 'ENOENT') return false; if (error.rule === 'path.symlink') return true; throw error; } });
  if (sourceMode) {
    const repositories = new Set();
    for (const item of selected.filter(item => !item.artifact)) {
      const canonical = item.repository.toLowerCase();
      if (repositories.has(canonical)) throw new SetupError('links.duplicate-source', 'Source mode requires one selected checkout per canonical repository; reconcile duplicate mappings/pins instead of cloning another copy');
      repositories.add(canonical);
      for (let parent = dirname(locations.get(item.id)); ; parent = dirname(parent)) {
        if (existsSync(resolve(parent, '.git'))) throw new SetupError('links.layout', 'Choose a shared non-repository workspace root with independent checkout destinations; a provider or consumer cannot be nested in another repository');
        if (parent === resolve(root)) break;
      }
    }
  }
  const requirements = new Map(activeLinks.map(link => {
    const identity = validated.items.get(link.consumer).installedPackages?.find(identity => identity.name === link.package);
    const version = link.version ?? identity?.version, outputs = [...new Set(['package.json', ...(link.outputs ?? []), ...Object.keys(identity?.files ?? {})])];
    if (link.package === '@foss-earth/ci' && !identity) throw new SetupError('links.attribution-contract', 'The attribution entry point always requires its independently pinned complete executable-file identity, including during development');
    if (sourceMode && (!version || !link.outputs && !identity)) throw new SetupError('links.contract', 'Source links require an exact package version and declared public output files, or a paired installedPackages identity');
    if (link.version && identity && link.version !== identity.version) throw new SetupError('links.contract', 'Source link version must agree with the paired immutable package identity');
    return [link, { version, outputs, enforce: sourceMode || Boolean(version), immutableFiles: link.package === '@foss-earth/ci' ? identity.files : null }];
  }));
  const ordered = [], visiting = new Set(), visited = new Set(), selectedItems = new Map(selected.map(item => [item.id, item]));
  function order(id) {
    if (visiting.has(id)) throw new SetupError('links.cycle', 'Local source linking creates a dependency cycle'); if (visited.has(id)) return;
    if (!selectedItems.has(id)) throw new SetupError('links.selection', 'Selected local-link consumer requires its provider selection before any operation');
    visiting.add(id); for (const dep of [...selectedItems.get(id).dependsOn ?? [], ...activeLinks.filter(link => ownerOf(link) === id).map(link => link.provider)]) order(dep);
    visiting.delete(id); visited.add(id); ordered.push(selectedItems.get(id));
  }
  selected.forEach(item => order(item.id)); selected = ordered; result.selection = selected.map(item => item.id);
  function providerClosure(id, found = new Set()) {
    for (const link of activeLinks.filter(link => ownerOf(link) === id)) { if (found.has(link.provider)) continue; found.add(link.provider); providerClosure(link.provider, found); }
    return [...found].map(provider => validated.items.get(provider));
  }
  async function sourceLinkState(link, requireOutputs = true) {
    const provider = locations.get(link.provider), requirement = requirements.get(link);
    let identityValid = !requirement.enforce, ready = identityValid, conflictRule = null; const files = [];
    if (requirement.enforce) {
      try {
        const metadataPath = safePath(provider, 'package.json'), metadataStat = lstatSync(metadataPath);
        if (!metadataStat.isFile() || metadataStat.size > (manifest.verification?.maxFileBytes ?? 64 * 1024 * 1024)) throw new SetupError('links.metadata', 'Provider package metadata must be a bounded regular file');
        const metadata = JSON.parse(readFileSync(metadataPath, 'utf8'));
        identityValid = metadata.name === link.package && metadata.version === requirement.version; ready = identityValid;
      } catch (error) { ready = false; if (error.code !== 'ENOENT') conflictRule = error.rule ?? 'links.metadata'; }
      if (requireOutputs) for (const output of requirement.outputs) {
        try {
          const path = safePath(provider, output), stat = lstatSync(path);
          if (!stat.isFile() || stat.size > (manifest.verification?.maxFileBytes ?? 64 * 1024 * 1024)) throw new SetupError('links.output', 'Required provider exports must be bounded regular files; preserve conflicting paths before building');
          const digest = await hashFile(path); files.push([output, digest]);
          if (requirement.immutableFiles && Object.hasOwn(requirement.immutableFiles, output) && requirement.immutableFiles[output] !== digest) { ready = false; conflictRule = 'package.attribution-integrity'; }
        } catch (error) { ready = false; if (error.code !== 'ENOENT') conflictRule = error.rule ?? 'links.output'; }
      }
    }
    const destination = blockedMount(link) ? null : linkDestination(link);
    let stat; try { if (destination) stat = lstatSync(destination); } catch (error) { if (error.code !== 'ENOENT') throw error; }
    const resolved = Boolean(provider && existsSync(provider) && stat?.isSymbolicLink() && existsSync(destination) && realpathSync(destination) === realpathSync(provider));
    return { consumer: link.consumer, owner: ownerOf(link), mountId: link.mountId, consumerRoot: relative(resolve(root), consumerPath(link)), provider: link.provider, package: link.package, expectedVersion: requirement.version, identityValid, ready, conflictRule, resolved, providerRoot: relative(resolve(root), provider), providerRealpath: existsSync(provider) ? realpathSync(provider) : null, publicFilesSha256: ready && requirement.enforce ? sha256(JSON.stringify(files)) : null };
  }
  const readonly = action === 'doctor' || (!apply && action !== 'check');
  if (sourceMode) result.plan.push({ kind: 'workspace-choices', desired: choices.preferences, previousStatus: choices.previous?.status ?? 'absent', changed: choices.changed, writes: !readonly && ['init', 'sync'].includes(action), completion: 'pending until the full operation succeeds; last applied choices retained' });
  for (const item of selected) result.plan.push(item.artifact ? { kind: 'artifact', id: item.id, sizeBytes: item.sizeBytes, sha256: item.sha256, destination: item.destination } : { kind: links[item.id] ? 'verify-local-source' : 'checkout', id: item.id, revision: item.revision, destination: relative(resolve(root), locations.get(item.id)), steps: (item.steps ?? []).filter(step => (action === 'check' ? step.kind === 'check' : step.kind !== 'check') && (!step.optIn || optIns.includes(step.optIn))).map(step => ({ id: step.id, kind: step.kind, argv: step.argv })) });
  for (const item of selected.filter(i => i.artifact && i.archive)) result.plan.push({ kind: 'prepared-tree', id: item.id, destination: item.archive.destination, treeSha256: item.archive.treeSha256, maxEntries: item.archive.maxEntries, maxExpandedBytes: item.archive.maxExpandedBytes, maxTarBytes: item.archive.maxTarBytes });
  for (const prerequisite of manifest.prerequisites ?? []) {
    if (prerequisite.forComponents && !prerequisite.forComponents.some(id => result.selection.includes(id))) continue;
    const run = command(prerequisite.argv, { allowFailure: true });
    const match = /\d+\.\d+(?:\.\d+)?/.exec(run.stdout + run.stderr);
    const actual = match?.[0] ?? null;
    let pass = run.status === 0 && actual !== null;
    if (pass && prerequisite.minimumVersion) { const a = actual.split('.').map(Number), b = prerequisite.minimumVersion.split('.').map(Number); pass = [0, 1, 2].some(i => (a[i] ?? 0) > (b[i] ?? 0) && a.slice(0, i).every((v, j) => v === b[j])) || [0, 1, 2].every(i => (a[i] ?? 0) === (b[i] ?? 0)); }
    result.prerequisites.push({ id: prerequisite.id, version: actual, pass });
    if (!pass) result.issues.push({ rule: 'prerequisite.failed', component: prerequisite.id, repair: 'Install/update this tool explicitly outside the installer, then rerun' });
  }
  // Inspect every selected destination before any fetch/build mutation.
  for (const item of selected.filter(i => !i.artifact)) {
    const state = stateOf(locations.get(item.id), item); result.repositories.push({ id: item.id, ...state, localLink: Boolean(links[item.id]) });
    if (state.conflict || state.dirty || state.diverged || (state.exists && !state.sourceMatches) || (links[item.id] && !state.compatible)) result.issues.push({ rule: state.dirty ? 'repository.dirty' : state.diverged ? 'repository.diverged' : 'repository.conflict', component: item.id, repair: 'Preserve local work/evidence. Commit or resolve it yourself; reconcile source/pin or choose an empty destination. No reset, clean, stash or deletion is performed' });
    else if ((['doctor', 'check'].includes(action) && !state.exists) || state.exists && !state.compatible && action !== 'sync') result.issues.push({ rule: !state.exists ? 'repository.missing' : 'repository.pin', component: item.id, repair: 'Run explicit init/sync after reviewing the plan' });
  }
  for (const item of selected.filter(i => i.artifact)) {
    const path = safePath(root, item.destination);
    const valid = existsSync(path) && statSync(path).isFile() && statSync(path).size === item.sizeBytes && await hashFile(path) === item.sha256;
    result.artifacts.push({ id: item.id, valid, missing: !existsSync(path), sha256: item.sha256 });
    if (existsSync(path) && !valid || ['doctor', 'check'].includes(action) && !valid) result.issues.push({ rule: existsSync(path) ? 'artifact.corrupt' : 'artifact.missing', component: item.id, repair: 'Preserve conflicting bytes; provide the exact pinned artifact or rerun explicit init' });
    if (item.archive) {
      const tree = await verifyTree({ root, archive: item.archive });
      result.artifacts.at(-1).preparedTree = tree;
      if (!tree.valid && (!tree.missing || ['doctor', 'check'].includes(action))) result.issues.push({ rule: tree.missing ? 'archive.missing' : 'archive.conflict', component: item.id, repair: 'Preserve conflicting prepared tree; provide exact reviewed files or run explicit init for missing content' });
    }
  }
  for (const link of allEdges) {
    const blocked = blockedMount(link), destination = blocked ? null : linkDestination(link);
    let stat; try { if (destination) stat = lstatSync(destination); } catch (error) { if (error.code !== 'ENOENT') throw error; }
    const provider = locations.get(link.provider);
    const linked = Boolean(provider && stat?.isSymbolicLink() && existsSync(destination) && existsSync(provider) && realpathSync(destination) === realpathSync(provider));
    const enabled = activeLinks.includes(link);
    let transition = false;
    if (hybrid && !enabled && stat?.isSymbolicLink() && choices.previous && ['init', 'sync'].includes(action)) {
      const managed = managedLinks.get(`${relative(resolve(root), consumerPath(link))}/${link.package}`);
      const witnesses = [];
      if (managed && managed.consumer === link.consumer && managed.owner === ownerOf(link) && managed.provider === link.provider) witnesses.push({ path: managed.providerRoot, pin: managed });
      for (const witness of [choices.previous.applied, choices.previous].filter(Boolean)) {
        if (witness.mode !== 'source' && !(Object.hasOwn(witness.components ?? {}, link.provider) && witness.components[link.provider] === 'source')) continue;
        witnesses.push({ path: Object.hasOwn(witness.links ?? {}, link.provider) ? witness.links[link.provider] : validated.items.get(link.provider).destination, pin: Object.hasOwn(witness.sourcePins ?? {}, link.provider) ? witness.sourcePins[link.provider] : null });
      }
      for (const witness of witnesses) {
        const previousPath = safePath(root, witness.path);
        if (existsSync(previousPath) && existsSync(destination) && realpathSync(destination) === realpathSync(previousPath)) {
          const pin = witness.pin;
          if (!pin) continue;
          const source = stateOf(previousPath, { ...validated.items.get(link.provider), revision: pin.revision });
          const origin = git(previousPath, ['remote', 'get-url', 'origin'], true);
          const retainsPin = source.compatible || source.targetAvailable && git(previousPath, ['merge-base', '--is-ancestor', pin.revision, source.revision], true).status === 0;
          transition = !source.conflict && origin.status === 0 && sha256(origin.stdout.trim()) === pin.sourceSha256 && retainsPin;
          if (transition) { packageTransitions.push({ ...link, previousPath }); break; }
        }
      }
    }
    result.plan.push({ kind: 'package-link', package: link.package, consumer: link.consumer, owner: ownerOf(link), consumerRoot: relative(resolve(root), consumerPath(link)), provider: link.provider, enabled, resolved: linked, blockedByParentSwitch: Boolean(blocked), toPackage: transition, replacement: 'Existing package directories and known switched links move into retained workspace/build evidence during explicit development operations' });
    if ((enabled && stat?.isSymbolicLink() && !linked) || (['doctor', 'check'].includes(action) && enabled && !linked) || (!enabled && stat?.isSymbolicLink() && !transition)) result.issues.push({ rule: 'links.identity', component: link.consumer, repair: 'Preserve the conflicting/missing development link. Resolve it to the declared selected provider or explicitly resume its recorded hybrid package switch; no fallback source copy or replacement is performed' });
    if (enabled) {
      const state = await sourceLinkState(link); result.sourceLinks.push(state);
      const providerState = result.repositories.find(row => row.id === link.provider);
      const pendingUpgrade = action === 'sync' && !links[link.provider] && providerState.exists && !providerState.compatible && providerState.sourceMatches && !providerState.dirty && !providerState.diverged && !providerState.conflict;
      if (state.conflictRule) result.issues.push({ rule: state.conflictRule, component: link.provider, package: link.package, repair: 'Preserve the unsafe/nonregular required export or metadata path and resolve it explicitly before any provider build' });
      if ((!pendingUpgrade && existsSync(provider) && !(await sourceLinkState(link, false)).identityValid) || (['doctor', 'check'].includes(action) && !state.ready)) result.issues.push({ rule: 'links.package', component: link.provider, package: link.package, repair: 'Reconcile the exact provider package name/version and build its declared public outputs from the pinned clean source; preserve current source/evidence' });
    }
  }
  async function packageState(item, diagnose) {
    const rows = [];
    const contexts = [{ id: item.id, path: locations.get(item.id), identities: item.installedPackages ?? [], parents: [] }, ...packageMounts.filter(mount => mount.owner === item.id).map(mount => ({ id: mount.component, path: mount.path, parents: [...mount.link.parents, mount], identities: (validated.items.get(mount.component).installedPackages ?? []).filter(identity => allEdges.some(edge => edge.consumerRoot === mount.path && edge.package === identity.name)) }))];
    for (const context of contexts) for (const identity of context.identities) {
      const link = activeLinks.find(link => link.consumer === context.id && consumerPath(link) === context.path && link.package === identity.name);
      const transition = packageTransitions.find(link => consumerPath(link) === context.path && link.package === identity.name && stillLinked(link));
      let row;
      if (blockedMount(context) || transition) row = { name: identity.name, valid: false, artifact: identity.artifact, mode: 'pending-package-switch' };
      else if (link) {
        const destination = linkDestination(link), provider = locations.get(link.provider);
        let metadata; try { const path = safePath(provider, 'package.json'), stat = lstatSync(path); if (!stat.isFile() || stat.size > (manifest.verification?.maxFileBytes ?? 64 * 1024 * 1024)) throw new SetupError('package.metadata', 'Linked package metadata exceeds the regular-file verification bound'); metadata = JSON.parse(readFileSync(path, 'utf8')); } catch { metadata = null; }
        const state = provider ? stateOf(provider, validated.items.get(link.provider)) : {};
        const valid = Boolean(provider && existsSync(destination) && lstatSync(destination).isSymbolicLink() && existsSync(provider) && realpathSync(destination) === realpathSync(provider) && state.compatible && state.sourceMatches && !state.dirty && !state.conflict && !state.diverged && metadata?.name === identity.name && metadata?.version === identity.version && (await sourceLinkState(link)).ready);
        row = { name: identity.name, valid, artifact: identity.artifact, mode: 'local-link', provider: link.provider, revision: validated.items.get(link.provider)?.revision };
      } else { try { row = await verifyPackageIdentity({ repo: context.path, identity, maxFileBytes: manifest.verification?.maxFileBytes }); } catch (error) { row = { name: identity.name, valid: false, artifact: identity.artifact, rule: error.rule ?? 'package.identity' }; if (error.rule === 'path.symlink') result.issues.push({ rule: 'package.source-link', component: item.id, package: identity.name, repair: 'Preserve the undeclared package symlink and resolve it explicitly; owner installation cannot follow neighboring source links' }); } }
      rows.push({ consumer: item.id, packageConsumer: context.id, consumerRoot: relative(resolve(root), context.path), ...row });
      if (diagnose && !row.valid) result.issues.push({ rule: 'package.identity', component: item.id, package: identity.name, repair: 'Install the exact manifest artifact/version/file set through the owner install step, or resolve the explicit clean source link; preserve conflicting work' });
    }
    return rows;
  }
  for (const item of selected.filter(i => !i.artifact)) result.installedPackages.push(...await packageState(item, ['doctor', 'check'].includes(action)));
  onPlan(result.plan);
  if (readonly || result.issues.length) { result.complete = true; result.clean = result.issues.length === 0; result.exitCode = result.clean ? 0 : 1; return result; }
  const stateRoot = safePath(root, 'build/dev-installer'); mkdirSync(stateRoot, { recursive: true });
  const journal = resolve(stateRoot, 'steps.jsonl'), history = existsSync(journal) ? readFileSync(journal, 'utf8').trim().split('\n').filter(Boolean).flatMap(line => { try { return [JSON.parse(line)]; } catch { return []; } }) : [];
  const records = new Map(history.filter(r => r.fingerprint).map(r => [r.fingerprint, r]));
  const dependencies = new Map();
  let truncated = existsSync(journal) && !readFileSync(journal, 'utf8').endsWith('\n');
  const record = value => { result.steps.push(value); if (truncated) { appendFileSync(journal, '\n'); truncated = false; } appendFileSync(journal, `${JSON.stringify({ ...value, time: new Date().toISOString() })}\n`); };
  function saveChoices(status) {
    if (!sourceMode || !['init', 'sync'].includes(action)) return;
    const applied = status === 'applied' ? choices.preferences : choices.previous?.status === 'applied' ? Object.fromEntries(Object.keys(choices.preferences).map(key => [key, choices.previous[key]])) : choices.previous?.applied ?? null;
    const value = { ...choices.preferences, status, applied, managedLinks: [...managedLinks.values()] };
    const serialized = JSON.stringify(value, null, 2);
    if (Buffer.byteLength(serialized) > 262144 || managedLinks.size > 1024) throw new SetupError('choices.state', 'Workspace choices exceed bounded storage; preserve state and narrow the manifest');
    mkdirSync(dirname(choices.path), { recursive: true });
    appendFileSync(resolve(stateRoot, 'choices.jsonl'), `${JSON.stringify({ ...value, time: new Date().toISOString() })}\n`);
    const staged = `${choices.path}.${randomUUID()}.json`; writeFileSync(staged, serialized, { flag: 'wx' }); renameSync(staged, choices.path);
    Object.assign(result.choices, { status, applied });
  }
  try {
    saveChoices('pending');
    async function verifyPackageMounts(owner) {
      for (const mount of packageMounts.filter(mount => mount.owner === owner)) {
        const verified = await verifyPackageIdentity({ repo: consumerPath(mount.link), identity: mount.identity, maxFileBytes: manifest.verification?.maxFileBytes });
        if (!verified.valid) throw new SetupError('package.identity', 'Install and verify the exact packaged consumer name/version/public bytes before source links or consumer code can use it; retained package bytes require explicit repair');
      }
    }
    async function establishLinks(consumer) {
      if (!activeLinks.length || !['init', 'sync'].includes(action)) return;
      for (const link of activeLinks) {
        if (ownerOf(link) !== consumer || !locations.has(link.provider)) continue;
        if (blockedMount(link)) throw new SetupError('links.switch-install', 'Install the pinned package consumer before activating links inside it; no build may follow its previous source checkout');
        const destination = linkDestination(link), provider = locations.get(link.provider);
        const state = await sourceLinkState(link);
        if (!state.identityValid || !state.ready) throw new SetupError(state.conflictRule ?? 'links.package', 'Selected provider must have the exact package identity and declared public exports ready before linking; repair its source/build without substituting another checkout');
        const witness = { consumer: link.consumer, owner: ownerOf(link), provider: link.provider, package: link.package, consumerRoot: relative(resolve(root), consumerPath(link)), providerRoot: relative(resolve(root), provider), repository: validated.items.get(link.provider).repository, revision: validated.items.get(link.provider).revision, sourceSha256: sha256(validated.items.get(link.provider).source) };
        const mount = `${witness.consumerRoot}/${witness.package}`;
        if (JSON.stringify(managedLinks.get(mount)) !== JSON.stringify(witness)) { managedLinks.set(mount, witness); saveChoices('pending'); }
        mkdirSync(dirname(destination), { recursive: true });
        if (existsSync(destination)) {
          if (lstatSync(destination).isSymbolicLink()) { if (realpathSync(destination) !== realpathSync(provider)) throw new SetupError('links.conflict', 'Existing development link points elsewhere; resolve explicitly'); else { result.sourceLinks = [...result.sourceLinks.filter(row => !sameLink(row, link)), state]; continue; } }
          const backup = safePath(root, `build/dev-installer/link-backups/${randomUUID()}`); mkdirSync(dirname(backup), { recursive: true }); renameSync(destination, backup);
        }
        symlinkSync(provider, destination, 'dir');
        result.sourceLinks = [...result.sourceLinks.filter(row => !sameLink(row, link)), await sourceLinkState(link)];
      }
    }
    function suspendLinks(consumer) {
      const suspended = new Set();
      for (const link of [...packageTransitions, ...(hybrid ? allEdges : activeLinks)].filter(link => ownerOf(link) === consumer)) {
        if (blockedMount(link)) continue;
        const destination = linkDestination(link);
        if (suspended.has(destination)) continue; suspended.add(destination);
        let stat; try { stat = lstatSync(destination); } catch (error) { if (error.code === 'ENOENT') continue; throw error; }
        if (stat.isSymbolicLink() && (!existsSync(destination) || realpathSync(destination) !== realpathSync(link.previousPath ?? locations.get(link.provider)))) throw new SetupError('links.conflict', 'Existing output link points elsewhere; no owner install may follow it');
        const backup = safePath(root, `build/dev-installer/link-backups/${randomUUID()}`); mkdirSync(dirname(backup), { recursive: true }); renameSync(destination, backup);
      }
    }
    for (const item of selected) {
      if (item.artifact) {
        if (action === 'check') { if (!result.artifacts.find(a => a.id === item.id).valid) throw new SetupError('artifact.missing', `Required artifact ${item.id} is unavailable`); }
        else { await acquire({ ...item, maxRedirects: manifest.transport?.maxRedirects, requestTimeoutSeconds: manifest.transport?.requestTimeoutSeconds, root }); Object.assign(result.artifacts.find(a => a.id === item.id), { valid: true, missing: false }); }
        if (item.archive) {
          const tree = action === 'check' ? await verifyTree({ root, archive: item.archive }) : await installArchive({ root, artifactPath: safePath(root, item.destination), archive: item.archive });
          if (!tree.valid) throw new SetupError('archive.missing', 'Exact prepared content tree is unavailable');
          result.artifacts.find(a => a.id === item.id).preparedTree = tree;
          record({ id: `tree:${item.id}`, status: 'passed', ...tree });
        }
        dependencies.set(item.id, sha256(JSON.stringify({ sha256: item.sha256, treeSha256: item.archive?.treeSha256 }))); record({ id: `artifact:${item.id}`, status: 'passed', sha256: item.sha256 }); continue;
      }
      const path = locations.get(item.id), old = result.repositories.find(r => r.id === item.id);
      safePath(root, relative(resolve(root), path));
      if (links[item.id]) { if (!old.compatible) throw new SetupError('links.identity', 'Explicit local link must resolve to the exact declared source revision'); }
      else if (!old.exists) {
        if (action === 'check') throw new SetupError('repository.missing', `Required repository ${item.id} is unavailable`);
        const staging = safePath(root, `build/dev-installer/checkouts/${item.id}-${randomUUID()}`); mkdirSync(dirname(staging), { recursive: true });
        git(root, ['clone', '--no-checkout', '--no-hardlinks', '--', item.source, staging]);
        if (git(staging, ['cat-file', '-e', `${item.revision}^{commit}`], true).status !== 0) git(staging, ['fetch', '--no-tags', 'origin', item.revision]);
        git(staging, ['checkout', '--no-overwrite-ignore', '--detach', item.revision]);
        mkdirSync(dirname(path), { recursive: true }); safePath(root, item.destination);
        if (existsSync(path)) throw new SetupError('repository.conflict', 'Destination appeared during clone; retained staging and destination');
        renameSync(staging, path);
      } else if (!old.compatible) {
        if (action !== 'sync') throw new SetupError('repository.pin', 'Existing checkout has a different pin; use explicit sync after reviewing the upgrade');
        git(path, ['fetch', '--no-tags', 'origin', item.revision]);
        const current = stateOf(path, item);
        if (current.dirty || current.diverged || !current.targetAvailable) throw new SetupError('repository.diverged', 'Target cannot fast-forward the local commit; reconcile manually; no local commits discarded');
        git(path, ['checkout', '--no-overwrite-ignore', '--detach', item.revision]);
      }
      if (git(path, ['rev-parse', 'HEAD']).stdout.trim() !== item.revision) throw new SetupError('repository.identity', 'Resolved checkout differs from exact source pin');
      Object.assign(old, stateOf(path, item), { localLink: Boolean(links[item.id]) });
      const evidence = [];
      const linkedOutputs = new Map(activeLinks.map(link => [resolve(consumerPath(link), `node_modules/${link.package}`), locations.get(link.provider)]));
      for (const step of item.steps ?? []) {
        if ((step.kind === 'check') !== (action === 'check') || step.optIn && !optIns.includes(step.optIn)) continue;
        if (step.kind !== 'install') {
          if (packageTransitions.some(link => ownerOf(link) === item.id && stillLinked(link))) throw new SetupError('links.switch-install', 'Hybrid package switch requires an owner install step before build/check; retained source links cannot qualify package inputs');
          await verifyPackageMounts(item.id);
          await establishLinks(item.id);
        }
        const argv = step.argv.map(arg => arg.replace(/\{workspace\}/g, resolve(root)).replace(/\{repo:([^}]+)\}/g, (_token, id) => { if (!locations.has(id)) throw new SetupError('command.dependency', 'Argument references an unselected repository'); return locations.get(id); }).replace(/\{artifact:([^}]+)\}/g, (_token, id) => { const artifact = validated.items.get(id); if (!artifact?.artifact || !dependencies.has(id)) throw new SetupError('command.dependency', 'Argument references an unprepared artifact'); return safePath(root, artifact.destination); }).replace(/\{artifactTree:([^}]+)\}/g, (_token, id) => { const artifact = validated.items.get(id); if (!artifact?.archive || !dependencies.has(id)) throw new SetupError('command.dependency', 'Argument references an unprepared content tree'); return safePath(root, artifact.archive.destination); }));
        const providerIds = new Set(providerClosure(item.id).map(provider => provider.id));
        const providerEdges = activeLinks.filter(link => ownerOf(link) === item.id || providerIds.has(ownerOf(link)));
        const publicInput = ({ consumer, consumerRoot, provider, package: packageName, expectedVersion, providerRealpath, publicFilesSha256 }) => ({ consumer, consumerRoot, provider, package: packageName, expectedVersion, providerRealpath, publicFilesSha256 });
        const linkInputs = (await Promise.all(providerEdges.map(link => sourceLinkState(link)))).map(publicInput);
        const fingerprint = sha256(JSON.stringify({ digest: sourceMode ? undefined : digest, contract: sourceMode ? { repository: item.repository, source: item.source, installedPackages: item.installedPackages } : undefined, selection: sourceMode ? undefined : result.selection, mode: sourceMode ? 'developer-source' : result.mode, locations: sourceMode ? [item.id, ...providerIds].map(id => [id, locations.get(id)]) : [...locations], linkInputs, revision: item.revision, stepId: step.id, stepKind: step.kind, stepOptIn: step.optIn, outputs: step.outputs, argv, optIns, dependencies: sourceMode ? (item.dependsOn ?? []).map(id => [id, dependencies.get(id)]) : [...dependencies], prerequisites: result.prerequisites.filter(prerequisite => !manifest.prerequisites?.find(item => item.id === prerequisite.id)?.forComponents || manifest.prerequisites.find(item => item.id === prerequisite.id).forComponents.includes(item.id)) }));
        const pendingPackageSwitch = packageTransitions.some(link => ownerOf(link) === item.id && stillLinked(link));
        const output = step.kind === 'install' && pendingPackageSwitch ? null : outputsDigest(path, step.outputs, manifest.verification?.maxFileBytes, linkedOutputs);
        const previous = records.get(fingerprint);
        const packageRepair = step.kind === 'install' && result.installedPackages.some(row => row.consumer === item.id && !row.valid);
        if (!packageRepair && previous?.status === 'passed' && step.outputs.length && previous.output === output && action !== 'check') { record({ id: `${item.id}:${step.id}`, fingerprint, status: 'passed', output, reused: true }); evidence.push(output); continue; }
        const runId = `${fingerprint}-${randomUUID()}`, logs = safePath(root, `build/dev-installer/commands/${runId}.log`); mkdirSync(dirname(logs), { recursive: true });
        if (step.kind === 'install') suspendLinks(item.id);
        const cache = safePath(root, 'build/dev-installer/npm-cache'), temp = safePath(root, 'build/dev-installer/tmp'); mkdirSync(cache, { recursive: true }); mkdirSync(temp, { recursive: true });
        const run = command(argv, { cwd: path, allowFailure: true, environment: { npm_config_cache: cache, TMPDIR: temp } }); writeFileSync(logs, run.stdout + run.stderr);
        if (run.status !== 0) { record({ id: `${item.id}:${step.id}`, fingerprint, status: 'failed', exitCode: run.status, log: relative(root, logs) }); throw new SetupError('step.failed', `Step ${item.id}:${step.id} failed; fix the cause and rerun to resume`); }
        const checkedSources = [item, ...providerClosure(item.id)];
        let sourceChanged = false;
        for (const sourceItem of checkedSources) {
          const sourceAfterStep = stateOf(locations.get(sourceItem.id), sourceItem);
          Object.assign(result.repositories.find(row => row.id === sourceItem.id), sourceAfterStep);
          sourceChanged ||= !sourceAfterStep.compatible || !sourceAfterStep.sourceMatches || sourceAfterStep.dirty || Boolean(sourceAfterStep.conflict);
        }
        if (sourceChanged) {
          record({ id: `${item.id}:${step.id}`, fingerprint, status: 'failed', rule: 'repository.modified', log: relative(root, logs) });
          throw new SetupError('repository.modified', 'Owner step changed its pinned source or an active linked provider; preserve source/working tree/origin and reconcile before resuming');
        }
        const afterProviderInputs = (await Promise.all(providerEdges.map(link => sourceLinkState(link)))).map(publicInput);
        if (JSON.stringify(afterProviderInputs) !== JSON.stringify(linkInputs)) {
          record({ id: `${item.id}:${step.id}`, fingerprint, status: 'failed', rule: 'links.outputs-modified', log: relative(root, logs) });
          throw new SetupError('links.outputs-modified', 'Owner step changed a linked provider public-file input; preserve evidence and repair/rebuild the provider before resuming');
        }
        if (step.kind === 'install') {
          try { await verifyPackageMounts(item.id); await establishLinks(item.id); }
          catch (error) { record({ id: `${item.id}:${step.id}`, fingerprint, status: 'failed', rule: error.rule ?? 'package.identity', log: relative(root, logs) }); throw error; }
        }
        const nextOutput = outputsDigest(path, step.outputs, manifest.verification?.maxFileBytes, linkedOutputs);
        if (step.outputs.length && nextOutput === null) throw new SetupError('step.output', `Step ${item.id}:${step.id} did not produce its declared output`);
        record({ id: `${item.id}:${step.id}`, fingerprint, status: 'passed', output: nextOutput, reused: false, log: relative(root, logs) }); evidence.push(nextOutput);
      }
      await verifyPackageMounts(item.id); await establishLinks(item.id);
      const after = stateOf(path, item); Object.assign(old, after);
      if (!after.compatible || !after.sourceMatches || after.dirty || after.conflict) throw new SetupError('repository.modified', 'Owner steps changed the pinned source/working tree/origin; preserve it and reconcile before resuming');
      const installed = await packageState(item, true);
      result.installedPackages = [...result.installedPackages.filter(row => row.consumer !== item.id), ...installed];
      if (installed.some(row => !row.valid)) throw new SetupError('package.identity', 'Resolved installed package does not match the exact artifact identity');
      for (const link of activeLinks.filter(link => link.provider === item.id)) {
        const provider = await sourceLinkState(link);
        result.sourceLinks = [...result.sourceLinks.filter(row => !sameLink(row, link)), provider];
        if (!provider.identityValid || !provider.ready) throw new SetupError(provider.conflictRule ?? 'links.package', 'Provider package identity/public outputs are not ready; repair its build before any consumer is prepared');
      }
      dependencies.set(item.id, sha256(JSON.stringify({ revision: item.revision, evidence, installed })));
    }
    saveChoices('applied'); result.complete = true; result.clean = true; result.exitCode = 0;
  } catch (error) { result.issues.push({ rule: error.rule ?? 'workspace.failure', detail: error instanceof SetupError ? error.message : 'Operation failed; retained workspace and evidence; resolve input/tool/source and resume' }); result.exitCode = 2; }
  writeFileSync(resolve(stateRoot, `result-${randomUUID()}.json`), JSON.stringify(result, null, 2));
  return result;
}
