import { existsSync, lstatSync, readFileSync } from 'node:fs';
import { safePath } from './paths.mjs';
import { hashFile } from './bootstrap.mjs';
import { SetupError } from './process.mjs';
export const packageName = /^(?:@[a-z0-9._-]+\/)?[a-z0-9._-]+$/;
export function validatePackageIdentity(identity, root) {
  if (!identity || !packageName.test(identity.name) || typeof identity.version !== 'string' || !identity.version || typeof identity.artifact !== 'string' || !identity.files || typeof identity.files !== 'object' || Array.isArray(identity.files) || !/^[a-f0-9]{64}$/.test(identity.files['package.json'] ?? '')) throw new SetupError('package.contract', 'Installed package needs name/version/pinned artifact and exact file digests including package.json');
  const installed = safePath(root, `node_modules/${identity.name}`);
  for (const [file, digest] of Object.entries(identity.files)) { safePath(installed, file); if (!/^[a-f0-9]{64}$/.test(digest)) throw new SetupError('package.contract', 'Invalid installed package file digest'); }
}
export async function verifyPackageIdentity({ repo, identity, maxFileBytes = 64 * 1024 * 1024 }) {
  validatePackageIdentity(identity, repo);
  const installed = safePath(repo, `node_modules/${identity.name}`);
  if (!existsSync(installed)) return { name: identity.name, version: identity.version, valid: false, missing: true, artifact: identity.artifact };
  if (!lstatSync(installed).isDirectory()) return { name: identity.name, valid: false, missing: false, artifact: identity.artifact };
  for (const [file, digest] of Object.entries(identity.files)) {
    const target = safePath(installed, file);
    if (!existsSync(target) || !lstatSync(target).isFile() || lstatSync(target).size > maxFileBytes || await hashFile(target) !== digest) return { name: identity.name, valid: false, missing: false, artifact: identity.artifact };
  }
  const metadata = JSON.parse(readFileSync(safePath(installed, 'package.json'), 'utf8'));
  return { name: identity.name, version: metadata.version, valid: metadata.name === identity.name && metadata.version === identity.version, missing: false, artifact: identity.artifact, verifiedFiles: Object.keys(identity.files).length };
}
