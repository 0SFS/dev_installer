import { readFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { readManifest } from './manifest.mjs';
import { workspace } from './workspace.mjs';
import { bootstrapManifest, validateBootstrapDescriptor } from './bootstrap.mjs';
import { SetupError } from './process.mjs';

export function parseArguments(args) {
  const [action, ...rest] = args;
  if (!['init', 'doctor', 'sync', 'check'].includes(action)) throw new SetupError('cli.action', 'Use init, doctor, sync or check');
  const options = { action, apply: false, optIns: [] }; let all = false;
  for (let i = 0; i < rest.length; i++) {
    const arg = rest[i];
    if (arg === '--apply') { options.apply = true; continue; }
    if (arg === '--all') { if (all || options.selections) throw new SetupError('cli.selection', 'Choose --all or explicit --select entries'); all = true; options.selections = []; continue; }
    if (!['--manifest', '--manifest-sha256', '--bootstrap', '--root', '--select', '--links', '--mode', '--component', '--opt-in'].includes(arg) || !rest[i + 1]) throw new SetupError('cli.arguments', 'Unknown option or missing value');
    const value = rest[++i];
    if (arg === '--select') { if (all) throw new SetupError('cli.selection', 'Choose --all or explicit --select entries'); options.selections ??= []; options.selections.push(...value.split(',')); }
    else if (arg === '--opt-in') options.optIns.push(value);
    else if (arg === '--component') {
      const match = /^([A-Za-z0-9][A-Za-z0-9._-]*)=(source|package)$/.exec(value);
      if (!match) throw new SetupError('cli.component', 'Use --component ID=source or --component ID=package with hybrid mode');
      options.components ??= {};
      if (Object.hasOwn(options.components, match[1])) throw new SetupError('cli.duplicate', 'Duplicate component choice');
      options.components[match[1]] = match[2];
    }
    else { const key = arg.slice(2); if (options[key]) throw new SetupError('cli.duplicate', 'Duplicate option'); options[key] = value; }
  }
  if (action === 'doctor' && options.apply) throw new SetupError('cli.readonly', 'Doctor is read-only and does not accept --apply');
  if (options.manifest && options.bootstrap) throw new SetupError('cli.source', 'Select one explicit manifest or bootstrap descriptor');
  if (options.mode !== undefined && !['source', 'package', 'exact', 'hybrid'].includes(options.mode)) throw new SetupError('cli.mode', 'Use --mode source, package, hybrid or exact');
  if (options.components && options.mode && options.mode !== 'hybrid') throw new SetupError('cli.mode', 'Per-component choices require hybrid mode');
  if (options.mode === 'exact' && options.links) throw new SetupError('cli.mode', 'Exact mode disables source links/path overrides; use --mode source with --links for development');
  if (!options.root) throw new SetupError('cli.root', 'Choose an explicit workspace root with --root');
  return options;
}
export async function runCli({ args = process.argv.slice(2), bootstrap, mode, application, write = text => process.stdout.write(text) } = {}) {
  let result;
  try {
    const options = parseArguments(args), root = resolve(options.root);
    options.defaultMode = mode;
    if (mode !== undefined && !['source', 'package', 'exact', 'hybrid'].includes(mode)) throw new SetupError('cli.mode', 'Wrapper default must be source, package, hybrid or exact; explicit mode and persisted choices override it');
    if (application !== undefined && (!application || typeof application.owner !== 'string' || !application.owner || typeof application.repository !== 'string' || !/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(application.repository))) throw new SetupError('bootstrap.application', 'Wrapper application boundary requires canonical owner and repository identities');
    if (options.mode === 'exact' && options.links) throw new SetupError('cli.mode', 'Exact mode disables source links/path overrides; choose source development mode');
    let input;
    if (options.manifest) input = readManifest(options.manifest, options['manifest-sha256']);
    else {
      const descriptor = options.bootstrap ? JSON.parse(readFileSync(options.bootstrap, 'utf8')) : bootstrap;
      if (!descriptor) throw new SetupError('bootstrap.unavailable', 'Application owner has not supplied the accepted default bootstrap descriptor; pass --manifest or --bootstrap with exact reviewed pins');
      validateBootstrapDescriptor(descriptor);
      if (application && descriptor.manifest.owner !== application.owner) throw new SetupError('bootstrap.application', 'Earth bootstrap must be owned by foss-earth and describe its independent app');
      const bootstrapPlan = [{ kind: 'bootstrap-manifest', owner: descriptor.manifest.owner, revision: descriptor.manifest.revision, sha256: descriptor.manifest.sha256, sizeBytes: descriptor.manifest.sizeBytes, mode: options.mode ?? mode ?? (options.links ? 'local-link' : 'exact'), persistedChoices: 'Resolved after the verified manifest is read; explicit CLI choices take precedence' }];
      if (!options.apply && options.action !== 'doctor' && options.action !== 'check') {
        result = { schemaVersion: 1, action: options.action, complete: true, clean: true, applied: false, exitCode: 0, plan: bootstrapPlan, next: 'Use --apply to verify/acquire this pinned manifest and display/perform its workspace plan' };
        write(`${JSON.stringify(result, null, 2)}\n`); return result;
      }
      if (options.apply) write(`${JSON.stringify({ schemaVersion: 1, event: 'plan', plan: bootstrapPlan })}\n`);
      input = await bootstrapManifest({ descriptor, root, readOnly: options.action === 'doctor' || options.action === 'check' });
    }
    if (application) {
      const app = input.manifest.repositories?.find(repo => repo.repository === application.repository);
      const byId = new Map([...(input.manifest.repositories ?? []), ...(input.manifest.artifacts ?? [])].map(item => [item.id, item]));
      const defaultClosure = new Set();
      function visit(id) { if (defaultClosure.has(id)) return; defaultClosure.add(id); for (const dependency of byId.get(id)?.dependsOn ?? []) visit(dependency); }
      (input.manifest.defaultComponents ?? []).forEach(visit);
      if (input.manifest.owner !== application.owner || !app || !input.manifest.defaultComponents?.includes(app.id) || [...defaultClosure].some(id => byId.get(id)?.repository?.toLowerCase() === 'foss-earth/foss-earth.github.io')) throw new SetupError('bootstrap.application', 'Standalone Earth setup requires a foss-earth-owned default foss-earth/app composition; the landing site cannot be its runtime or setup prerequisite');
    }
    const linksInput = options.links ? JSON.parse(readFileSync(options.links, 'utf8')) : null;
    if (linksInput && (linksInput.schemaVersion !== 1 || !linksInput.repositories || typeof linksInput.repositories !== 'object')) throw new SetupError('links.schema', 'Local link file requires schemaVersion 1 and repository path map');
    result = await workspace({ ...options, root, manifest: input.manifest, digest: input.digest, links: linksInput?.repositories, onPlan: plan => { if (options.apply || options.action === 'check') write(`${JSON.stringify({ schemaVersion: 1, event: 'plan', plan })}\n`); } });
  } catch (error) { result = { schemaVersion: 1, complete: false, clean: false, exitCode: 2, issues: [{ rule: error.rule ?? 'input.failure', detail: error instanceof SetupError ? error.message : 'Cannot read/validate input or source; retained work is unchanged or repairable' }] }; }
  write(`${JSON.stringify(result, null, 2)}\n`); return result;
}
