import { spawnSync } from 'node:child_process';
import { resolve } from 'node:path';
export class SetupError extends Error {
  constructor(rule, detail) { super(detail); this.rule = rule; }
}
export function command(argv, { cwd, input, allowFailure = false, environment = {} } = {}) {
  if (!Array.isArray(argv) || !argv.length || argv.some(arg => typeof arg !== 'string' || arg.includes('\0'))) throw new SetupError('command.arguments', 'Commands require argument arrays');
  const env = Object.fromEntries(Object.entries(process.env).filter(([key]) => !key.startsWith('GIT_')));
  Object.assign(env, { GIT_OPTIONAL_LOCKS: '0', GIT_NO_REPLACE_OBJECTS: '1', GIT_NO_LAZY_FETCH: '1', GIT_TERMINAL_PROMPT: '0' });
  Object.assign(env, environment);
  const run = spawnSync(argv[0], argv.slice(1), { cwd, env, input, encoding: 'utf8', maxBuffer: 32 * 1024 * 1024 });
  if ((run.error || run.status !== 0) && !allowFailure) throw new SetupError('command.failed', `Command ${argv[0]} failed; resolve the prerequisite or step and rerun`);
  return { status: run.status ?? 2, stdout: run.stdout ?? '', stderr: run.stderr ?? '' };
}
export function git(repo, args, allowFailure = false) {
  return command(['git', '--no-optional-locks', '-C', resolve(repo), '-c', 'core.hooksPath=/dev/null', '-c', 'core.fsmonitor=false', '-c', 'core.untrackedCache=false', ...args], { allowFailure });
}
