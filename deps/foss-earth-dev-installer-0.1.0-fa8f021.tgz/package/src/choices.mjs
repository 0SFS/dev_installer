import { existsSync, lstatSync, readFileSync } from 'node:fs';
import { safePath, relativePath } from './paths.mjs';
import { SetupError } from './process.mjs';
import { sha256 } from './manifest.mjs';

// Machine-local preferences are data, never executable manifest replacements.
export function workspaceChoices({ root, validated, mode, defaultMode, components, links, selections }) {
  const path = safePath(root, `build/dev-installer/workspaces/${validated.manifest.id}.json`);
  let stored;
  if (existsSync(path)) {
    const stat = lstatSync(path);
    if (!stat.isFile() || stat.size > 262144) throw new SetupError('choices.state', 'Preserve the conflicting workspace choices file; expected bounded regular JSON');
    try { stored = JSON.parse(readFileSync(path, 'utf8')); } catch { throw new SetupError('choices.state', 'Preserve and explicitly repair malformed workspace choices'); }
    if (stored.schemaVersion !== 1 || stored.manifestId !== validated.manifest.id || stored.owner !== validated.manifest.owner || !['source', 'hybrid', 'package'].includes(stored.mode) || !['pending', 'applied'].includes(stored.status)) throw new SetupError('choices.state', 'Stored choices do not match this manifest identity/source-workspace contract');
    for (const [id, canonical] of Object.entries(stored.repositories ?? {})) if (validated.items.get(id)?.repository !== canonical) throw new SetupError('choices.identity', 'Stored checkout choices have different canonical repository identities; preserve state and reconcile the manifest/map explicitly');
    for (const witness of [stored, stored.applied].filter(Boolean)) {
      if (!witness.sourcePins || typeof witness.sourcePins !== 'object' || Array.isArray(witness.sourcePins)) throw new SetupError('choices.state', 'Recorded source choices need their original pins/origin digests; preserve and reconcile incomplete state');
      for (const [id, pin] of Object.entries(witness.sourcePins)) if (!validated.items.has(id) || validated.items.get(id).artifact || !pin || !/^(?:[a-f0-9]{40}|[a-f0-9]{64})$/.test(pin.revision) || !/^[a-f0-9]{64}$/.test(pin.sourceSha256)) throw new SetupError('choices.state', 'Recorded source pin/origin identity is malformed');
    }
    if (stored.managedLinks !== undefined && (!Array.isArray(stored.managedLinks) || stored.managedLinks.length > 1024)) throw new SetupError('choices.state', 'Managed source-link witnesses must be a bounded array');
    const mounts = new Set();
    for (const witness of stored.managedLinks ?? []) {
      if (!witness || typeof witness !== 'object' || Array.isArray(witness)) throw new SetupError('choices.state', 'Managed source-link witness must be a data record');
      const edge = (validated.manifest.links ?? []).find(edge => edge.consumer === witness.consumer && edge.provider === witness.provider && edge.package === witness.package);
      if (!edge || !validated.items.has(witness.owner) || validated.items.get(witness.owner).artifact || validated.items.get(witness.provider).repository !== witness.repository || !/^(?:[a-f0-9]{40}|[a-f0-9]{64})$/.test(witness.revision ?? '') || !/^[a-f0-9]{64}$/.test(witness.sourceSha256 ?? '')) throw new SetupError('choices.state', 'Managed source-link witness no longer matches canonical identities; preserve and reconcile state');
      // Historical nested mounts may now be shadowed by a valid source-parent
      // link. Check their lexical containment here; active mounts still receive
      // safePath/realpath/origin/pin validation before any operation follows them.
      relativePath(root, witness.consumerRoot); relativePath(root, witness.providerRoot);
      const mount = `${witness.consumerRoot}/${witness.package}`;
      if (mounts.has(mount)) throw new SetupError('choices.state', 'Duplicate managed source-link witness');
      mounts.add(mount);
    }
  }
  const effectiveMode = mode ?? stored?.mode ?? defaultMode;
  if (effectiveMode !== undefined && !['source', 'package', 'exact', 'hybrid'].includes(effectiveMode)) throw new SetupError('workspace.mode', 'Choose source, package, hybrid or exact mode');
  if (components !== undefined && (!components || typeof components !== 'object' || Array.isArray(components))) throw new SetupError('choices.schema', 'Component choices must be a source/package map');
  const rawMap = effectiveMode === 'hybrid' ? { ...stored?.components, ...components } : components ?? {};
  const rawPaths = links ?? (effectiveMode === 'exact' ? {} : stored?.links ?? {});
  const roots = selections ?? (effectiveMode === 'exact' ? [] : stored?.selections ?? []);
  if (!Array.isArray(roots) || roots.some(id => typeof id !== 'string') || new Set(roots).size !== roots.length) throw new SetupError('choices.selection', 'Saved/explicit selections must be distinct component or group IDs; use an empty array for the full default');
  if (!rawMap || typeof rawMap !== 'object' || Array.isArray(rawMap) || !rawPaths || typeof rawPaths !== 'object' || Array.isArray(rawPaths)) throw new SetupError('choices.schema', 'Component choices and checkout paths must be maps');
  const map = Object.assign(Object.create(null), rawMap), paths = Object.assign(Object.create(null), rawPaths);
  for (const [id, choice] of Object.entries(map)) if (!validated.items.has(id) || validated.items.get(id).artifact || !['source', 'package'].includes(choice)) throw new SetupError('choices.component', 'Choices name declared repository IDs and source/package values');
  if (effectiveMode !== 'hybrid' && Object.keys(map).length) throw new SetupError('choices.mode', 'Per-component choices require hybrid mode');
  if (effectiveMode === 'exact' && Object.keys(paths).length) throw new SetupError('links.exact-mode', 'Exact mode disables source links and path overrides; use a separate artifact workspace');
  const preferences = { schemaVersion: 1, manifestId: validated.manifest.id, owner: validated.manifest.owner, repositories: Object.fromEntries(validated.manifest.repositories.map(repo => [repo.id, repo.repository])), sourcePins: Object.fromEntries(validated.manifest.repositories.map(repo => [repo.id, { revision: repo.revision, sourceSha256: sha256(repo.source) }])), mode: effectiveMode, selections: roots, components: map, links: paths };
  const comparable = stored && Object.fromEntries(Object.keys(preferences).map(key => [key, stored[key]]));
  return { mode: effectiveMode, components: map, links: paths, selections: roots, path, preferences, previous: stored, persisted: Boolean(stored), changed: JSON.stringify(comparable) !== JSON.stringify(preferences) };
}

export function selectHybrid(validated, selections, components, packageMode = false) {
  const { manifest, items } = validated, ordered = [], visited = new Set(), visiting = new Set();
  const roots = selections.length ? selections.flatMap(id => Object.hasOwn(manifest.selections ?? {}, id) ? manifest.selections[id] : [id]) : manifest.defaultComponents;
  const providers = new Set((manifest.links ?? []).map(link => link.provider));
  const choice = id => components[id] ?? (roots.includes(id) || !providers.has(id) ? 'source' : 'package');
  if (packageMode && Object.keys(components).length) throw new SetupError('choices.mode', 'Package mode consumes immutable providers; choose hybrid to edit individual providers');
  for (const id of roots) if (items.has(id) && !items.get(id).artifact && choice(id) === 'package') throw new SetupError('choices.root', 'Selected roots need a source checkout; select their consumer to use a packaged dependency');
  function visit(id) {
    if (!items.has(id)) throw new SetupError('manifest.selection', `Unknown selection ${id}`);
    if (visiting.has(id)) throw new SetupError('links.cycle', 'Hybrid dependency choices create a cycle');
    if (visited.has(id)) return;
    const item = items.get(id), dependencies = [];
    visiting.add(id);
    function packageDependencies(provider, incoming) {
      const identity = items.get(incoming.consumer).installedPackages?.find(identity => identity.name === incoming.package);
      if (!identity) throw new SetupError('choices.package', 'Packaged dependency has no exact installedPackages artifact/file identity');
      dependencies.push(identity.artifact);
      if (visiting.has(provider)) throw new SetupError('links.cycle', 'Packaged public dependency graph creates a cycle');
      visiting.add(provider);
      const packaged = items.get(provider);
      for (const dependency of packaged.packageDependsOn ?? packaged.dependsOn ?? []) {
        if (items.get(dependency).artifact) { dependencies.push(dependency); continue; }
        const edges = (manifest.links ?? []).filter(edge => edge.consumer === provider && edge.provider === dependency);
        if (!edges.length) throw new SetupError('choices.package-prerequisite', 'Packaged runtime dependencies need artifact/public package contracts; declare packageDependsOn explicitly to exclude source-only build prerequisites');
        for (const edge of edges) {
          const backing = packaged.installedPackages?.find(identity => identity.name === edge.package);
          if (!backing) throw new SetupError('choices.package', 'Packaged consumer public dependencies need exact installedPackages backing for owner installation before source activation');
          dependencies.push(backing.artifact);
          if (choice(edge.provider) === 'source') dependencies.push(edge.provider);
          else packageDependencies(edge.provider, edge);
        }
      }
      visiting.delete(provider);
    }
    for (const dependency of item.dependsOn ?? []) {
      if (!items.get(dependency).artifact && choice(dependency) === 'package') {
        const edges = (manifest.links ?? []).filter(link => link.consumer === id && link.provider === dependency);
        if (!edges.length) throw new SetupError('choices.package', 'Packaged components require a declared direct public package edge and immutable installedPackages identity; retain non-package prerequisites as source');
        for (const edge of edges) packageDependencies(dependency, edge);
      } else dependencies.push(dependency);
    }
    // Edges without dependsOn remain an explicit missing-selection failure.
    const effective = { ...item, dependsOn: [...new Set(dependencies)] };
    for (const dependency of effective.dependsOn) visit(dependency);
    visiting.delete(id); visited.add(id); ordered.push(effective);
  }
  roots.forEach(visit);
  return { selected: ordered, choice };
}
