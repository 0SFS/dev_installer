# Manifest, bootstrap and wrapper v1

Application-owned workspace schemaVersion 1:

```json
{
  "schemaVersion": 1,
  "id": "earth-workspace",
  "version": "REVIEWED_RELEASE_VERSION",
  "owner": "foss-earth",
  "repositories": [{
    "id": "engine", "repository": "foss-earth/engine",
    "source": "https://github.com/foss-earth/engine.git",
    "revision": "EXACT_FULL_COMMIT_OID", "destination": "engine",
    "dependsOn": [],
    "steps": [{ "id": "build", "kind": "build", "argv": ["npm", "run", "build"], "outputs": ["dist/release-receipt.json"] }]
  }],
  "artifacts": [], "defaultComponents": ["engine"],
  "selections": { "engine": ["engine"] },
  "prerequisites": [{ "id": "node", "argv": ["node", "--version"], "minimumVersion": "22.0.0" }],
  "verification": { "maxFileBytes": 67108864 }
}
```

This example describes the contract, not a required manifest or released fleet.
Actual manifests need exact accepted pins. `defaultComponents` plus dependency
closure includes every nonoptional repo/artifact; optional content/native work
is explicitly selected. IDs are distinct across repository/artifact types and
the dependency graph must be acyclic. An artifact records id/location/sha256/
sizeBytes/destination, optional and optional dependency IDs. For campus, declare
the versioned prepared content needed for ordinary onboarding, never private
YouVisit backup. Earth/campus owners exclude flight tools/content/repositories.
No runtime import or reverse installer/application dependency is introduced.

Destinations and output paths are normalized relative paths within their chosen
root, with no parent escape, absolute path, backslash, symlink ancestry, collision
or parent/child destination overlap, including case/Unicode aliases and trailing
dot/space aliases. Workspace build/ is installer state/evidence.
No credentials or machine-specific paths go into published manifests. Local file
sources exist for isolated tests; published manifests use canonical URLs and
artifacts. SHA-256 and declared byte counts are validated before adoption.
HTTPS downloads stream with exact declared size/digest; cache conflicts fail
without overwriting. Redirecting GitHub release assets are supported through a
bounded manual HTTPS-only redirect chain. Defaults are maxRedirects 5 and
requestTimeoutSeconds 30; manifest.transport may name both bounds. Original
manifest URLs contain no credentials/query tokens; server-issued signed HTTPS
redirect targets may contain queries. No authorization or personal headers are
forwarded. File fixtures exercise transport locally; actual immutable release
hosting and credentials remain coordinator decisions.

An artifact may declare archive {format, destination, stripComponents, files,
treeSha256, maxEntries, maxExpandedBytes, maxTarBytes, maxMetadataBytes}. Format is
tar or tar.gz; files maps every exact installed relative file to SHA-256;
treeSha256 hashes JSON.stringify of file/digest pairs sorted by JavaScript string
order. maxEntries bounds archive entries and installed files/directories;
maxExpandedBytes bounds declared payload bytes, maxTarBytes bounds ALL decoded
tar bytes including padding, and maxMetadataBytes defaults to 65536 for global
comment/timestamp metadata. All other bounds are explicitly owner-supplied.
Links/devices/sparse/extended path metadata, escapes, duplicate portable aliases,
unknown/missing/corrupt files and truncated streams fail. Prepared trees use
independent destinations outside source checkouts/artifact files/build state.
Extraction is staged, verified and atomically adopted only into an absent path;
conflicts/failed partial trees are preserved. Doctor/check verify the complete
installed tree without extraction. No media encoding/upload is performed.

Step kind is install/build/check. `argv` is an argument array, never shell text;
tokens `{workspace}`, `{repo:ID}`, `{artifact:ID}`, `{artifactTree:ID}` expand within each single
argument without word splitting. Outputs are exact regular-file receipts/artifacts,
not directory mtimes. `verification.maxFileBytes` is a positive byte bound,
default 64 MiB per output, to keep synchronous receipt validation bounded. Use
small digest/provenance receipts for large trees. Artifacts are hashed by stream.
`optIn` is a named explicit choice required for known native/WASM commands;
caller passes `--opt-in NAME` deliberately. There is no native default or WASM
hash-normalization build. Prerequisites use known tool `--version` probes with
optional minimumVersion and forComponents IDs. System tool installation remains
a separate user action. Check commands are not install/build commands.

Bootstrap descriptor schemaVersion 1 contains manifest {location, sha256,
sizeBytes, owner, revision}. Revision is its exact owning source commit, while
sha256 authenticates exact JSON artifact bytes; owner must match parsed manifest.
The descriptor is shipped with the wrapper's reviewed release and shared-tool
artifact pin. Before source exists, the shared CLI verifies/acquires manifest
data to workspace/build/dev-installer/bootstrap/<digest>.json and then applies
the same schema, selection and operation machinery. Doctor reads only an existing
verified cached manifest and reports missing bootstrap otherwise. Wrappers need
neither source checkout nor runtime/private backup to run.

Thin wrapper example (owned by Flight or UMN):

```js
import { runCli } from '@foss-earth/dev-installer';
import { readFileSync } from 'node:fs';
const bootstrap = JSON.parse(readFileSync(new URL('./workspace-bootstrap.json', import.meta.url)));
const result = await runCli({ bootstrap, mode: 'source' });
process.exitCode = result.exitCode;
```

Explicit `--manifest` or `--bootstrap` overrides wrapper default data, never a
second hardcoded fleet. Earth entry uses the same API and a `foss-earth`-owned
descriptor, with `application:{owner:'foss-earth',repository:'foss-earth/app'}`.
Its declared defaults must include the app itself and have no landing-site
prerequisite; explicit provider-only selection is still allowed. See
[Earth bootstrap requirements](earth-bootstrap.md).
`workspace({...,mode:'source'})` and `--mode source` activate all declared package
edges whose consumer is selected, including fresh default provider destinations.
Application developer wrappers set `runCli({bootstrap,mode:'source'})`; an explicit
CLI --mode exact overrides that default. Source and consumer destinations are
independent relative paths in one explicitly chosen non-repository root. Earth,
Flight and campus manifests must use the same compatible canonical provider
destination/machine-local map to share it; the tool never chooses/relocates an
active checkout or hides a conflict with another clone. Duplicate selected
canonical repository IDs and repository-nested layouts within the chosen root
fail. The owner/coordinator must review the final root/map for any enclosing
application repository above that root. Ignored migration fixtures do not prove
the final independent layout.

`--links` JSON remains {schemaVersion:1,repositories:{ID:"relative/existing/path"}}.
These are machine-local overrides inside the chosen shared root, not public
dependency paths. Override checkouts must already exist with exact clean
origin/revision; ordinary missing default destinations can clone once. Generic
calls without mode preserve prior exact or explicit-override local-link behavior.
Explicit --mode exact disables all source links and rejects overrides. Use a
separate root to qualify immutable artifacts; developer links cannot be reused
as exact release proof. No global npm-link state changes.

Manifest links use [{consumer,provider,package,version,outputs}]. Source mode
requires an exact version and nonempty required public regular-file output list,
or the consumer's matching installedPackages identity supplies its version/file
names. If both are present their versions must agree. Example:
`{consumer:'tour',provider:'renderer',package:'@foss-earth/renderer',version:'0.1.0',outputs:['dist/index.js','dist/index.d.ts','dist/assets.json']}`.
Owner builds must prepare those public exports before consumers are cloned or
run. Source outputs are checked for readiness and hashed for local dependency
receipts; immutable artifact hashes remain separately enforced in exact mode.

Providers must be in selected dependency closure. The tool orders all active
provider edges before consumers and rejects missing selections/cycles before
mutation; it never selects a hidden provider implicitly. Public link receipts
record expected version, identity/readiness/resolution, relative provider root,
actual machine-local provider realpath and public-file digest. Wrong/dangling
existing links, wrong provider name/version/origin/revision and dirty/diverged
source stop with retained evidence. Doctor verifies existing links/outputs offline.
Missing outputs can be prepared by init/sync; symlink/nonregular/unsafe output
conflicts fail in preflight before a receipt-only owner build could follow them.
Clean ordinary sync may reach a new exact provider commit/version before the
new metadata/output identity is checked. Path overrides remain existing exact
pins and require explicit manual reconciliation instead of automatic upgrades.
The attribution package @foss-earth/ci additionally keeps its independently
pinned executable-file digests even when source-linked. It cannot substitute
mutable bytes for the installed attribution entry point or omit that identity.

Before a non-reused owner install, existing links are moved into retained evidence
so installation cannot write through into source. After successful source checks,
links are restored before output hashing/passed journaling and consumer builds.
Each successful owner step verifies its own source and the transitive active
provider closure before a reusable success receipt, including unchanged direct
and transitive public-file input digests even when those files are Git-ignored.
Mapping/mode/provider-output
changes invalidate reuse. Checks never establish missing links. SDK/WASM and
prepared-media artifacts retain their exact pins and explicit build opt-ins.

## Hybrid development choices

`--mode package` (API `mode:'package'`) consumes immutable providers while keeping
selected application/runner roots and non-package prerequisites in source. It
uses the same exact installedPackages contracts and dependency projection as
hybrid mode, accepts no component overrides and persists across later commands.
`--mode source` activates all selected public source links; `--mode hybrid`
chooses providers individually. `--mode exact` disables links and local choice
reuse for independent release verification, retaining the declared repository
closure. Package mode is a developer setup, not qualification of a deployed app
artifact. A compiled app consumer/runner needs its own owner-supplied contract.

Use `workspace({...,mode:'hybrid',components:{c172:'source',engine:'package'}})`
or `--mode hybrid --component c172=source --component engine=package`.
These are machine-local choices, not published dependency paths or manifest
substitutions. Selected runnable roots and non-package prerequisites default to
source; declared public package providers default to exact packages. A root
chosen as package fails without a consumer installation contract: select its
source composition/runner, whose accepted installedPackages identity can consume
that package. Application owners supply that runner and all accepted pins.

Hybrid substitutes a direct dependsOn/provider edge only through its matching
manifest.links and consumer installedPackages identity. The package artifact is
verified and installed by the source consumer's owner steps. Packaged repositories
are not cloned or built. Their artifact prerequisites and declared public package
edges are retained, including backing artifacts needed for installation before
a source link replaces a package. Optional `packageDependsOn` explicitly names
the packaged runtime subset of dependsOn, allowing owners to omit source-only
native/media/build prerequisites. Without that subset an uncontracted non-package
repository prerequisite fails; the tool never silently discards runtime content.

An installed packaged consumer gets its source dependency under
`node_modules/PACKAGE/node_modules/DEPENDENCY`, pointing to the same independent
provider checkout used by other consumers. This supports a packaged Simulator
importing source C172 without downloading Simulator source. Nested exact package
dependencies need paired identities and owner install steps preparing those
declared locations. Imports continue through package exports.

Mode, selected roots, component choices and relative checkout overrides persist per manifest ID
in `build/dev-installer/workspaces/ID.json`, bound to owner and canonical repository
identities plus original source pins/origin digests. Source URLs are not emitted
in choice receipts. Explicit CLI/API choices override stored choices; stored choices
override a wrapper's `runCli({mode:'source'})` default. CLI --component changes
merge into existing hybrid choices. API `mode` is an explicit choice; API
`defaultMode` supplies a fallback. Preview, doctor and check read state without
writing. Init/sync --apply emits the full choice/switch plan, writes pending desired
choices, retains the last fully applied choices and marks applied only after
success. Failure resumes the pending target while authenticating retained source
links against recorded applied/pending source maps. This also permits cancelling
a partially activated source choice. Append-only journals retain earlier decisions
and failed attempts.
Each activated consumer/package mount also records its provider origin digest,
original pin and relative source/consumer paths before activation. Narrowed
operations retain untouched consumers' records, so a later full-default switch
can safely deactivate their source links. Historical nested mounts are checked
lexically when reading preferences; only current active mounts are traversed and
authenticated. Switching their packaged parent to source cannot make read-only
diagnosis follow an obsolete mount through a new parent symlink. These records
are bounded to 1,024 mounts and a 256 KiB choices file; conflicts fail with evidence.
Omitted selections reuse saved roots, so repeat setup does not expand a selected
component into the whole fleet. CLI --all or API selections:[] restores the full
default; --select entries explicitly replace the saved root selection.

Switch source→package suspends matching managed links and installs/verifies exact
regular package bytes. It leaves the inactive provider checkout, dirty edits,
local refs and ignored evidence untouched. Switch package→source reuses a retained
compatible clean checkout or clones once when absent. Dirty/diverged/incompatible
source stops with an explicit manual repair result before activation. Non-reused
installs retain existing declared package directories, suspended links and partial
failed install bytes before new writes. Wrong/dangling/unmanaged links still fail.
An inactive source need not equal a new packaged-release revision: its recorded
original origin/pin (or locally committed descendant) authenticates the retained
link while the new immutable package is verified separately. Packaged consumer
name/version/public bytes are checked before nested source links or owner builds
can load that consumer; failed installation never records a reusable success.

Development fingerprints bind each item's own canonical source/step/package
contract, actual root, effective dependencies and transitive public-file inputs.
Independent manifests reuse one compatible provider build; changing a component
choice invalidates its affected consumer closure while independent siblings keep
their receipts. Missing direct edges/package identities, source-selection cycles
and invalid choices fail before provisioning. SDK/WASM/prepared-media inputs and
opt-ins are unchanged. Hybrid receipts remain development evidence; deployed
pages and releases require separate exact artifact qualification with source
links disabled.

Each repository may declare installedPackages [{name,version,artifact,files}].
artifact names its exact downloaded dependency artifact and must precede the
consumer through dependsOn closure; files maps installed relative files to
reviewed SHA-256 and includes package.json. Shared verification checks the
actual node_modules package name/version/regular file digests; doctor/check
fail on missing or stale packages. Exact mode rejects package source symlinks.
Explicit development links verify provider commit/source plus package identity.
Invalid package receipts prevent reuse of install steps; the owner still owns
installation argv and complete exported-file inventories. Include every public
runtime/type/data file required by that release, not only a version marker.

Result schemaVersion 1: action, manifest id/version/digest, mode, exact selected
closure, plan, prerequisites/tool versions, repository states, artifact integrity,
sourceLinks/development qualification, desired/applied choices, resumable step records, issues,
complete/clean and exitCode. CLI emits a plan
JSON event before mutations and a final JSON result; public runCli also returns
that result for wrappers. Exit 0 succeeds/clean plan, 1 diagnosis/conflict requiring
manual resolution, 2 failed/incomplete operation or invalid input. Journal records
attempts/fingerprints/output hashes/log names under workspace/build/. No source
URLs, credentials or environment values are emitted in normal result records.

## Public archive API and executable release seal

Import `validateArchive`, `verifyTree`, `installArchive` and `treeDigest` from
`@foss-earth/dev-installer/archive`. `validateArchive(archive, root)` returns
undefined on a valid contract and throws a rule-bearing error otherwise.
`treeDigest(files)` returns the SHA-256 of the sorted exact file/digest pairs.
`await verifyTree({root, archive})` returns {valid, missing, treeSha256, files,
sizeBytes}; absent trees return {valid:false, missing:true}, conflicts return
valid:false, and unsafe paths/links throw. It performs no extraction or writes.
`await installArchive({root, artifactPath, archive, readOnly:false})` verifies
an existing tree or stages bounded extraction and atomically installs a new
tree. It returns {valid:true, reused, treeSha256, files, sizeBytes, destination}.
Read-only mode accepts an existing verified tree and fails on a missing tree.
Conflicts, unsafe inputs and incomplete extraction throw rule-bearing errors;
failed staging is retained. Compressed artifact SHA-256/size verification is
the caller's responsibility before invoking the standalone extraction API;
workspace acquisition already performs that verification.

The clean-source package script creates a deterministic Git archive and an
external release.json. The descriptor records package/version, revision,
sourceTree, artifactSha256 and sizeBytes; packageIdentity binds name/version,
type/license/engines/bin/exports. `files` seals package.json and every runtime
bin/src/schema/default file, including transitive imports. `publicEntries`
binds each declared bin/export target to its exact regular file digest.
`source.files` inventories every committed file with mode/object/SHA-256/bytes;
`source.inventorySha256` binds that complete map. `archive` includes its complete
file map, uncompressed tar SHA-256/size, tree digest, verified round trip and
explicit entry/payload/stream/metadata bounds. LICENSE, provenance, schemas,
fixtures and original dependency notices are retained in the source archive.

Primary writers, including Flight's AUDIO_ARCHIVE_VERIFIER_PIN owner, must use
an independently reviewed descriptor: verify the descriptor pin, archive digest
and size, install with scripts disabled, compare package identity and every
descriptor.files byte before importing a public entry. Pin source, archive,
size and complete executable map together; hashing archive.mjs alone leaves
its imports unverified. Flight then binds the public archive export itself;
no generic parser is copied. The installed-consumer verification script exercises
these exact installed exports in an isolated workspace. Earth/Flight/UMN
wrappers continue to own their accepted manifest/bootstrap pins.
