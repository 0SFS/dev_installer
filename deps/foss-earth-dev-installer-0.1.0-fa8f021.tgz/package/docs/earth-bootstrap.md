# Earth application bootstrap contract

Earth owns the manifest, descriptor, app build policy and landing assembly. The
shared installer owns data verification and workspace operations. The real app
is `foss-earth/app`, normally at a chosen workspace's `foss-earth/app`. Private
machine paths must not appear in public manifests or release descriptors. The chosen workspace may
be fresh and requires no existing app, Flight or Campus checkout.

`foss-earth/foss-earth.github.io` owns the thin landing and exact compiled app
release mounted under `/app/`. It is not the application runtime or an app
checkout/setup prerequisite. The standalone `foss-earth-setup` guard requires
manifest owner `foss-earth`, `foss-earth/app` among defaultComponents and no
landing-site repository in the default dependency closure. An unused app
declaration cannot admit a site-only default. Explicit provider-only `--select`
still works with that same valid app manifest.

Earth must supply these reviewed release inputs before real bootstrap:

1. A bounded schemaVersion 1 manifest JSON artifact: stable ID/version, owner
   `foss-earth`, exact full repository revisions, relative independent
   destinations, real canonical clone URLs and a full default app dependency
   closure. Every nonoptional component/artifact must be reachable. Search,
   shared/Flight VR and Flight runtime/build/setup inputs remain excluded.
2. Each public provider's declared direct dependsOn/link edge, exact package
   version, public runtime/type/data output paths and a matching installedPackages
   identity bound to an exact artifact ID and complete public file SHA-256 map.
   Include required transitive runtime artifacts; packageDependsOn may explicitly
   omit source-only build inputs. No copied component source or private backups.
3. Digest/byte-bound immutable package/artifact locations that really exist.
   App-owned argv install/build/check steps must install those exact inputs and
   produce bounded regular output receipts. No server/watch/benchmark or implicit
   native/WASM/media build; native paths require named opt-ins. App artifacts
   must carry owner-reviewed `/app/` asset/worker base and scoped-worker policy;
   the installer does not guess browser host paths.
4. A pure-data bootstrap descriptor with manifest location/SHA-256/sizeBytes,
   exact owning source revision and owner `foss-earth`. It is independently pinned
   with the checked installer source/archive/size/executable map. Explicit
   `--bootstrap` works before a default exists; Earth supplies the accepted data
   for a later installer `defaults/earth-bootstrap.json` release if desired.
   No default URL or compatible pin is fabricated while these inputs are absent.

One provider checkout is shared by all selected consumers through public exports.
Use identical canonical provider IDs/pins/destinations across app manifests in a
shared non-Git workspace root. Machine-local `--links` JSON may map an existing
clean compatible provider to another relative path; it stays out of release data.

```sh
foss-earth-setup init --bootstrap earth-bootstrap.json --root "Earth workspace" --mode source --apply
foss-earth-setup sync --bootstrap earth-bootstrap.json --root "Earth workspace" --mode package --apply
foss-earth-setup sync --bootstrap earth-bootstrap.json --root "Earth workspace" --mode hybrid --component renderer=source --apply
foss-earth-setup doctor --bootstrap earth-bootstrap.json --root "Earth workspace"
foss-earth-setup check --bootstrap earth-bootstrap.json --root "Earth workspace"
foss-earth-setup sync --bootstrap earth-bootstrap.json --root "Earth workspace" --select renderer --apply
foss-earth-setup sync --bootstrap earth-bootstrap.json --root "Earth workspace" --all --apply
```

These are command templates; `renderer` is the owner's declared component ID.
Source mode builds and links selected providers once. Package mode retains the
selected app/runner source and consumes exact provider packages without cloning
their repositories. Hybrid selects providers individually; packaging the app
itself requires an owner-declared consumer/runner and exact app artifact contract.
Saved mode, selections and relative path/component choices take precedence over
the wrapper's source default on later commands. Narrowing a selection preserves
untouched consumers' link records. Source-to-package switching retains inactive
dirty providers and evidence; source reactivation refuses dirty/diverged inputs
before mutation. Doctor stays read-only; failed/pending operations resume safely.

Earth's separately granted real acceptance must record a fresh full-default
bootstrap, selected provider closure without unrelated clones, repeat/reuse,
read-only doctor, check, source/package/hybrid switches and preserved dirty-work
refusal. Record the actual manifest/descriptor/tool/artifact pins, output digests,
provider realpaths and closed logs. Browser startup and compiled `/app/` landing
integration remain Earth-owned checks. Synthetic installer fixtures qualify only
the tool; they do not qualify the real application. Campus and Flight use the same
contracts with their own later accepted manifests and wrappers.
