# Safe and resumable operations

Source setup uses --mode source; packaged providers use --mode package; hybrid
setup uses --mode hybrid and repeated --component ID=source/package.
Only source choices get checkouts; package choices use declared exact artifacts.
Choices and relative provider maps persist per manifest, including pending versus
fully applied switches. Preview changes before --apply. Unspecified mode follows
saved choices before the wrapper's source default. Source→package preserves dirty
inactive checkouts; returning them to source requires explicit clean-pin repair.
Matching installed package links and partial bytes are retained before installs.
Packaged consumers can use source providers at their declared nested package
mounts without acquiring the consumer's source. Artifact/runtime prerequisites
remain exact; packageDependsOn explicitly excludes source-only build inputs.
Independent provider builds and unaffected consumer receipts are reused. Exact
release qualification uses its own root and explicit --mode exact.
Saved selections persist until --select replaces them or --all restores defaults.
Link records are kept per consumer mount, including untouched consumers outside
a narrowed operation and historical nested mounts shadowed by a parent switch.
Only the current planned mounts are traversed; activation/deactivation verifies
their actual target, canonical origin and original source pin. Inactive provider
edits and all earlier backups remain intact.

Init: validate manifest/paths/closure, probe selected prerequisites, inspect every
existing destination before mutation, display plan, stream/verify artifacts,
clone into retained staging, detach at exact pins, atomically adopt into absent
destinations, and run dependency-ordered installs/builds. No global tool changes.
Source mode prepares each selected canonical provider once before consumers,
checks package identity/required public outputs, and links all declared selected
edges to that checkout. The shared root/grouping directories cannot be Git repos;
repository destinations/overrides remain independent and non-overlapping.

Doctor: offline read-only probes, tool versions, missing/dirty/diverged/source-pin
state, links and artifact hashes. Git optional locks, fsmonitor and untracked
cache writes/helpers are disabled. No mkdir, fetch or journal/log write.
An offline remote tracking ref is not proof of current upstream state.

Sync: requires a clean checkout from the declared source. Fetch exact target,
prove current commit is its ancestor, and detach at the target; otherwise stop
with manual repair instructions. Existing branch refs/local commits remain.
Checkout explicitly refuses overwriting ignored files; newly tracked paths
cannot destroy retained build/evidence bytes during an otherwise clean upgrade.
Ordinary init does not silently upgrade. Linked worktrees/external Git directories
are rejected as mutation destinations; use a standalone manifest checkout.

Check: source/artifacts must already exist at exact pins; run selected declared
checks, always, with retained command output. It never clones or installs missing
dependencies and never starts a server. Component owners keep domain validation.
Check verifies existing development links and prepared trees; link establishment
and extraction occur only during explicit init/sync operations. Exact mode
refuses mutable neighboring-source package symlinks.

Exact and legacy resumable fingerprints include the verified manifest digest,
closure, mode and dependency evidence. Source/package/hybrid fingerprints instead bind
the owner's exact source and package contract, step kind/argv/outputs/opt-ins,
effective dependencies, prerequisite versions, actual own/provider paths and
transitive public-file inputs. Unrelated manifest or selection changes therefore
do not rebuild a compatible provider or an unaffected sibling. Completed outputs
are rehashed before skipping. Source links are
suspended into retained evidence around owner installs and restored before
success output hashing. Transitive provider source integrity is checked before
any successful owner step can be reused.
Changed inputs or outputs invalidate success. Failed steps never get success
receipts; truncated/interrupted journal tails are retained and separated before
new records. Staged partial bytes and failed checkouts/logs are not deleted.
Resume the same operation after fixing the exact prerequisite/source/build cause.

Commands run only declared trusted manifest argv, with workspace-local npm cache
and TMPDIR. No shell expansion or secrets in manifest fields. Component build
scripts remain application-owned code and must obey the manifest's category;
review manifests before --apply. Source/ref strings never become shell code.
