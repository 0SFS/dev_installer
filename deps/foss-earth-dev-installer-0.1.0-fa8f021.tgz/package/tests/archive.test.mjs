import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdirSync, mkdtempSync, writeFileSync, readFileSync, existsSync, statSync, symlinkSync } from 'node:fs';
import { resolve } from 'node:path';
import { gzipSync } from 'node:zlib';
import { pathToFileURL } from 'node:url';
import { sha256, validateManifest } from '../src/manifest.mjs';
import { acquire } from '../src/bootstrap.mjs';
import { treeDigest, installArchive, verifyTree, validateArchive } from '../src/archive.mjs';
import { workspace } from '../src/workspace.mjs';
import { git } from '../src/process.mjs';
const parent = resolve('build/fixtures/archive'); mkdirSync(parent, { recursive: true });
const root = mkdtempSync(resolve(parent, 'run-')); let serial = 0;
function tar(entries, tail = Buffer.alloc(1024)) {
  const chunks = [];
  for (const entry of entries) {
    const bytes = Buffer.from(entry.bytes ?? ''), header = Buffer.alloc(512);
    header.write(entry.name, 0, 100); header.write('0000644\0', 100, 8); header.write('0000000\0', 108, 8); header.write('0000000\0', 116, 8);
    header.write(bytes.length.toString(8).padStart(11, '0') + '\0', 124, 12); header.write('00000000000\0', 136, 12); header.fill(32, 148, 156);
    header[156] = (entry.type ?? '0').charCodeAt(0); if (entry.link) header.write(entry.link, 157, 100);
    header.write('ustar\0', 257, 6); header.write('00', 263, 2);
    const checksum = header.reduce((sum, value) => sum + value, 0); header.write(checksum.toString(8).padStart(6, '0') + '\0 ', 148, 8);
    chunks.push(header, bytes, Buffer.alloc((512 - bytes.length % 512) % 512));
  }
  return Buffer.concat([...chunks, tail]);
}
function fixture(entries = [{ name: 'package/data/item.json', bytes: '{"prepared":true}' }], changes = {}) {
  const space = resolve(root, `workspace ${serial++}`), artifactPath = resolve(root, `archive-${serial}.tgz`), bytes = gzipSync(tar(entries)); writeFileSync(artifactPath, bytes);
  const files = { 'data/item.json': sha256('{"prepared":true}') };
  const archive = { format: 'tar.gz', destination: 'content/release', stripComponents: 1, files, treeSha256: treeDigest(files), maxEntries: 20, maxExpandedBytes: 4096, maxTarBytes: 8192, ...changes };
  return { space, artifactPath, bytes, archive, install: extra => installArchive({ root: space, artifactPath, archive, ...extra }) };
}
test('prepared tree first install, exact repeat reuse and nested extra-file conflict', async () => {
  const f = fixture(); assert.equal((await f.install()).valid, true); const path = resolve(f.space, 'content/release/data/item.json'), mtime = statSync(path).mtimeMs;
  assert.equal((await f.install()).reused, true); assert.equal(statSync(path).mtimeMs, mtime);
  writeFileSync(resolve(f.space, 'content/release/data/zz-extra.txt'), 'unlisted preserved bytes');
  assert.equal((await verifyTree({ root: f.space, archive: f.archive })).valid, false); await assert.rejects(f.install(), /Existing content tree/); assert.equal(readFileSync(path, 'utf8'), '{"prepared":true}');
});
test('unreviewed empty directories make the prepared tree conflict', async () => {
  const f = fixture(); await f.install(); mkdirSync(resolve(f.space, 'content/release/unreviewed'));
  assert.equal((await verifyTree({ root: f.space, archive: f.archive })).valid, false); await assert.rejects(f.install(), /Existing content tree/);
});
test('ordinary tar and Git archive global comment metadata preserve pinned content', async () => {
  const f = fixture(undefined, { format: 'tar' });
  const value = 'comment=' + '1'.repeat(40) + '\n'; let length = value.length + 3; while (String(length).length + 1 + value.length !== length) length = String(length).length + 1 + value.length;
  writeFileSync(f.artifactPath, tar([{ name: 'pax_global_header', type: 'g', bytes: `${length} ${value}` }, { name: 'package/', type: '5' }, { name: 'package/data/', type: '5' }, { name: 'package/data/item.json', bytes: '{"prepared":true}' }]));
  assert.equal((await f.install()).valid, true);
});
for (const [label, entries] of Object.entries({
  escape: [{ name: 'package/../escape', bytes: 'outside' }],
  absolute: [{ name: '/outside', bytes: 'outside' }],
  symlink: [{ name: 'package/data/item.json', type: '2', link: '../../outside' }],
  hardlink: [{ name: 'package/data/item.json', type: '1', link: 'outside' }],
  special: [{ name: 'package/data/item.json', type: '3' }],
  sparse: [{ name: 'package/data/item.json', type: 'S' }],
  duplicate: [{ name: 'package/data/item.json', bytes: '{"prepared":true}' }, { name: 'package/data/item.json', bytes: '{"prepared":true}' }],
  'portable-alias': [{ name: 'package/data/item.json', bytes: '{"prepared":true}' }, { name: 'package/DATA/ITEM.JSON', bytes: '{"prepared":true}' }],
  unknown: [{ name: 'package/unknown.txt', bytes: 'unknown' }],
  'unknown-directory': [{ name: 'package/unknown/', type: '5' }, { name: 'package/data/item.json', bytes: '{"prepared":true}' }],
  corrupt: [{ name: 'package/data/item.json', bytes: 'wrong bytes' }],
  'pax-path': [{ name: 'pax', type: 'g', bytes: '20 path=../escape\n' }]
})) test(`unsafe archive ${label} refuses adoption and retains staging`, async () => {
  const f = fixture(entries); await assert.rejects(f.install()); assert.equal(existsSync(resolve(f.space, 'content/release')), false); assert.equal(existsSync(resolve(f.space, 'build/dev-installer/extraction')), true);
});
test('truncation, payload/count/decompressed-padding bounds and unreadable archive are repairable', async () => {
  const f = fixture(); writeFileSync(f.artifactPath, gzipSync(tar([{ name: 'package/data/item.json', bytes: '{"prepared":true}' }]).subarray(0, 600))); await assert.rejects(f.install());
  for (const changes of [{ maxExpandedBytes: 1 }, { maxEntries: 1 }, { maxTarBytes: 1024 }]) { const limited = fixture(undefined, changes); await assert.rejects(limited.install()); }
  const padded = fixture(); writeFileSync(padded.artifactPath, gzipSync(tar([{ name: 'package/data/item.json', bytes: '{"prepared":true}' }], Buffer.alloc(1024 * 1024)))); await assert.rejects(padded.install(), /stream/);
  const missing = fixture(); await assert.rejects(installArchive({ root: missing.space, artifactPath: resolve(root, 'missing.tgz'), archive: missing.archive }));
});
test('dangling symlink destination and overlapping prepared-tree manifest are refused', async () => {
  const f = fixture(); mkdirSync(f.space, { recursive: true }); symlinkSync(resolve(root, 'missing-source'), resolve(f.space, 'dangling'));
  await assert.rejects(acquire({ root: f.space, destination: 'dangling', location: pathToFileURL(f.artifactPath).href, sha256: sha256(f.bytes), sizeBytes: f.bytes.length }), /symbolic link/);
  assert.equal(existsSync(resolve(f.space, 'build/dev-installer/downloads')), false);
  const manifest = { schemaVersion: 1, id: 'collision', version: '1', owner: 'fixture', repositories: [{ id: 'app', repository: 'fixture/app', source: 'https://example.invalid/app.git', revision: '1'.repeat(40), destination: 'app', dependsOn: ['content'] }], artifacts: [{ id: 'content', location: pathToFileURL(f.artifactPath).href, sha256: sha256(f.bytes), sizeBytes: f.bytes.length, destination: 'archives/content.tgz', archive: { ...f.archive, destination: 'app/content' } }], defaultComponents: ['app'] };
  assert.throws(() => validateManifest(manifest, f.space), /overlap/);
  const files = { 'A/x.json': sha256('x'), 'a/y.json': sha256('y') }; assert.throws(() => validateArchive({ ...f.archive, files, treeSha256: treeDigest(files) }, f.space), /Parent-directory/);
  await assert.rejects(acquire({ root: resolve(root, 'ssh-artifact'), destination: 'artifact.bin', location: 'ssh://git@example.invalid/artifact', sha256: sha256(f.bytes), sizeBytes: f.bytes.length }), /transport/); assert.equal(existsSync(resolve(root, 'ssh-artifact')), false);
});
test('bounded HTTPS release redirect verifies exact bytes without forwarding credentials', async () => {
  const bytes = Buffer.from('redirected exact artifact'), space = resolve(root, `redirect ${serial++}`), requests = [];
  const fetchImpl = async (url, options) => { requests.push([url, options]); return requests.length === 1 ? new Response(null, { status: 302, headers: { location: 'https://release-assets.example.invalid/content?signature=synthetic' } }) : new Response(bytes, { headers: { 'content-length': String(bytes.length) } }); };
  const result = await acquire({ location: 'https://example.invalid/releases/asset', root: space, destination: 'artifact.bin', sha256: sha256(bytes), sizeBytes: bytes.length, fetchImpl });
  assert.equal(result.reused, false); assert.equal(requests.length, 2); assert.equal(requests[1][1].headers.authorization, undefined);
  for (const location of ['http://example.invalid/asset', 'https://user:secret@example.invalid/asset']) await assert.rejects(acquire({ location: 'https://example.invalid/release', root: resolve(root, `unsafe-redirect-${serial++}`), destination: 'artifact.bin', sha256: sha256(bytes), sizeBytes: bytes.length, fetchImpl: async () => new Response(null, { status: 302, headers: { location } }) }));
  await assert.rejects(acquire({ location: 'https://example.invalid/release', root: resolve(root, `redirect-limit-${serial++}`), destination: 'artifact.bin', sha256: sha256(bytes), sizeBytes: bytes.length, maxRedirects: 1, fetchImpl: async () => new Response(null, { status: 302, headers: { location: '/again' } }) }), /maximum/);
});
test('prepared content workspace plan/build/doctor/check consume shared tree without flight', async () => {
  const f = fixture(), source = resolve(root, `campus-source-${serial++}`); mkdirSync(source); git(source, ['init', '--quiet', '--initial-branch=main']); writeFileSync(resolve(source, '.gitignore'), '/build/\n/dist/\n');
  writeFileSync(resolve(source, 'consume.mjs'), 'import{readFileSync,mkdirSync,writeFileSync}from"node:fs"; import{resolve}from"node:path"; const data=JSON.parse(readFileSync(resolve(process.argv[2],"data/item.json"))); if(!data.prepared)process.exit(3); mkdirSync("dist",{recursive:true});writeFileSync("dist/receipt.json",JSON.stringify(data));');
  git(source, ['add', '.']); git(source, ['-c', 'user.name=Fixture Human', '-c', 'user.email=fixture@example.invalid', 'commit', '--quiet', '-m', 'Synthetic campus content consumer']);
  const manifest = { schemaVersion: 1, id: 'campus-prepared', owner: 'UMN-VR', version: '1', repositories: [{ id: 'tour', repository: 'UMN-VR/tour', source: pathToFileURL(source).href, revision: git(source, ['rev-parse', 'HEAD']).stdout.trim(), destination: 'tour', dependsOn: ['content'], steps: [{ id: 'prepare', kind: 'build', argv: ['node', 'consume.mjs', '{artifactTree:content}'], outputs: ['dist/receipt.json'] }] }], artifacts: [{ id: 'content', location: pathToFileURL(f.artifactPath).href, sha256: sha256(f.bytes), sizeBytes: f.bytes.length, destination: 'archives/content.tgz', archive: f.archive }], defaultComponents: ['tour'] };
  const options = { root: f.space, manifest, digest: sha256(JSON.stringify(manifest)), apply: true };
  const first = await workspace({ ...options, action: 'init' }); assert.equal(first.exitCode, 0); assert.ok(first.plan.some(p => p.kind === 'prepared-tree')); assert.equal(first.artifacts[0].preparedTree.valid, true);
  const repeat = await workspace({ ...options, action: 'init' }); assert.equal(repeat.exitCode, 0); assert.equal(repeat.artifacts[0].preparedTree.reused, true);
  assert.equal((await workspace({ ...options, action: 'doctor' })).exitCode, 0); assert.equal((await workspace({ ...options, action: 'check' })).exitCode, 0);
});
