import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdirSync, mkdtempSync, writeFileSync, readFileSync, existsSync, readdirSync, lstatSync, readlinkSync, realpathSync, renameSync, symlinkSync } from 'node:fs';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { git } from '../src/process.mjs';
import { sha256 } from '../src/manifest.mjs';
import { workspace } from '../src/workspace.mjs';
import { runCli } from '../src/cli.mjs';

const parent = resolve('build/fixtures/source-workspace'); mkdirSync(parent, { recursive: true });
const scratch = mkdtempSync(resolve(parent, 'run-')); let serial = 0;
const packageName = '@fixture/shared', version = '1.0.0';
const metadata = { name: packageName, version, type: 'module', exports: { '.': { types: './dist/index.d.ts', default: './dist/index.mjs' }, './types': './dist/index.d.ts', './asset': './dist/asset.json' } };
const publicFiles = ['dist/index.mjs', 'dist/index.d.ts', 'dist/asset.json'];
function commit(source, message) { git(source, ['add', '.']); git(source, ['-c', 'user.name=Fixture Human', '-c', 'user.email=fixture@example.invalid', 'commit', '--quiet', '-m', message]); return git(source, ['rev-parse', 'HEAD']).stdout.trim(); }
function source(name, files) {
  const path = resolve(scratch, `${name}-${serial++}`); mkdirSync(path); git(path, ['init', '--quiet', '--initial-branch=main']);
  writeFileSync(resolve(path, '.gitignore'), '/build/\n/dist/\n/node_modules/\n');
  for (const [file, bytes] of Object.entries(files)) writeFileSync(resolve(path, file), bytes);
  return { path, revision: commit(path, 'Synthetic source-linked workspace fixture') };
}
function fixture() {
  const provider = source('provider', {
    'package.json': JSON.stringify(metadata),
    'build.mjs': 'import{mkdirSync,writeFileSync,readFileSync,existsSync}from"node:fs";mkdirSync("build",{recursive:true});if(existsSync("build/fail"))process.exit(5);mkdirSync("dist",{recursive:true});const count=existsSync("build/count")?Number(readFileSync("build/count")):0;writeFileSync("build/count",String(count+1));writeFileSync("dist/index.mjs",`export const identity = "source-provider";\\n`);writeFileSync("dist/index.d.ts",`export declare const identity: string;\\n`);writeFileSync("dist/asset.json",JSON.stringify({source:true}));'
  });
  const consumerFiles = {
    'install.mjs': 'import{readFileSync,writeFileSync,mkdirSync,existsSync,lstatSync}from"node:fs";import{resolve,dirname}from"node:path";const root="node_modules/@fixture/shared";if(existsSync(root)&&lstatSync(root).isSymbolicLink())throw Error("Owner install reached provider link");mkdirSync("build",{recursive:true});const count=existsSync("build/install-count")?Number(readFileSync("build/install-count")):0;writeFileSync("build/install-count",String(count+1));for(const[file,bytes]of Object.entries(JSON.parse(readFileSync(process.argv[2])))){mkdirSync(dirname(resolve(root,file)),{recursive:true});writeFileSync(resolve(root,file),bytes);}',
    'build.mjs': 'import{identity}from"@fixture/shared";import{readFileSync,writeFileSync,mkdirSync,realpathSync}from"node:fs";import{fileURLToPath}from"node:url";const types=readFileSync(fileURLToPath(import.meta.resolve("@fixture/shared/types")),"utf8"),asset=JSON.parse(readFileSync(fileURLToPath(import.meta.resolve("@fixture/shared/asset"))));mkdirSync("dist",{recursive:true});writeFileSync("dist/receipt.json",JSON.stringify({identity,types,asset,providerRealpath:realpathSync("node_modules/@fixture/shared")}));'
  };
  const earth = source('earth', consumerFiles), campus = source('campus', consumerFiles);
  const artifactFiles = { 'package.json': JSON.stringify(metadata), 'dist/index.mjs': 'export const identity = "immutable-artifact";\n', 'dist/index.d.ts': 'export declare const identity: string;\n', 'dist/asset.json': JSON.stringify({immutable:true}) };
  const bytes = Buffer.from(JSON.stringify(artifactFiles)), artifact = resolve(scratch, `package-${serial++}.json`); writeFileSync(artifact, bytes);
  const installedIdentity = { name: packageName, version, artifact: 'shared-package', files: Object.fromEntries(Object.entries(artifactFiles).map(([path, bytes]) => [path, sha256(bytes)])) };
  const repo = (id, input, destination) => ({ id, repository: `fixture/${id}`, source: pathToFileURL(input.path).href, revision: input.revision, destination, dependsOn: ['provider', 'shared-package'], installedPackages: [installedIdentity], steps: [{ id: 'install', kind: 'install', argv: ['node', 'install.mjs', '{artifact:shared-package}'], outputs: ['node_modules/@fixture/shared/package.json', ...publicFiles.map(path => `node_modules/@fixture/shared/${path}`)] }, { id: 'build', kind: 'build', argv: ['node', 'build.mjs'], outputs: ['dist/receipt.json'] }] });
  const manifest = { schemaVersion: 1, id: 'source-workspace', version: '1', owner: 'synthetic-shared', repositories: [repo('earth', earth, 'applications/earth'), repo('campus', campus, 'applications/campus'), { id: 'provider', repository: 'fixture/shared', source: pathToFileURL(provider.path).href, revision: provider.revision, destination: 'providers/shared', dependsOn: [], steps: [{ id: 'build', kind: 'build', argv: ['node', 'build.mjs'], outputs: publicFiles }] }], artifacts: [{ id: 'shared-package', location: pathToFileURL(artifact).href, destination: 'artifacts/shared-package.json', sha256: sha256(bytes), sizeBytes: bytes.length }], links: ['earth', 'campus'].map(consumer => ({ consumer, provider: 'provider', package: packageName, version, outputs: publicFiles })), defaultComponents: ['earth', 'campus'], selections: { earth: ['earth'], provider: ['provider'] } };
  const root = resolve(scratch, `shared workspace ${serial++}`);
  const run = (action = 'init', extra = {}) => workspace({ action, root, manifest, digest: sha256(JSON.stringify(manifest)), mode: 'source', apply: true, ...extra });
  return { root, manifest, provider, earth, campus, run, artifactFiles };
}
function snapshot(root) {
  if (!existsSync(root)) return [];
  return readdirSync(root, { withFileTypes: true }).flatMap(entry => {
    const path = resolve(root, entry.name), stat = lstatSync(path);
    if (stat.isSymbolicLink()) return [[path, 'link', readlinkSync(path), stat.mtimeMs]];
    if (stat.isDirectory()) return snapshot(path);
    return [[path, 'file', sha256(readFileSync(path)), stat.mtimeMs]];
  });
}
const row = (f, consumer) => JSON.parse(readFileSync(resolve(f.root, `applications/${consumer}/dist/receipt.json`)));
test('fresh full source workspace builds one provider and links both public-export consumers; repeat reuses final linked outputs', async () => {
  const f = fixture(), first = await f.run(); assert.equal(first.exitCode, 0); assert.equal(first.mode, 'source');
  assert.ok(first.selection.indexOf('provider') < first.selection.indexOf('earth')); assert.ok(first.selection.indexOf('provider') < first.selection.indexOf('campus'));
  const provider = realpathSync(resolve(f.root, 'providers/shared'));
  for (const consumer of ['earth', 'campus']) { assert.equal(row(f, consumer).identity, 'source-provider'); assert.equal(row(f, consumer).providerRealpath, provider); assert.equal(row(f, consumer).asset.source, true); assert.ok(row(f, consumer).types.includes('identity')); assert.equal(readFileSync(resolve(f.root, `applications/${consumer}/build/install-count`), 'utf8'), '1'); }
  assert.equal(first.sourceLinks.length, 2); assert.ok(first.sourceLinks.every(link => link.resolved && link.ready && link.identityValid && link.providerRealpath === provider));
  assert.equal(readFileSync(resolve(provider, 'build/count'), 'utf8'), '1'); assert.equal(existsSync(resolve(f.root, '.git')), false); assert.equal(existsSync(resolve(f.root, 'providers/.git')), false);
  const repeat = await f.run(); assert.equal(repeat.exitCode, 0); assert.ok(repeat.steps.filter(step => step.fingerprint).every(step => step.reused));
  assert.equal(readFileSync(resolve(provider, 'build/count'), 'utf8'), '1'); assert.equal(readFileSync(resolve(f.root, 'applications/earth/build/install-count'), 'utf8'), '1');
  const before = snapshot(f.root); assert.equal((await f.run('doctor')).exitCode, 0); assert.deepEqual(snapshot(f.root), before);
});
test('selected closure links only selected consumers and reuses a compatible mapped provider without a second checkout', async () => {
  const f = fixture(), selected = await f.run('init', { selections: ['earth'] }); assert.equal(selected.exitCode, 0); assert.equal(selected.sourceLinks.length, 1); assert.equal(existsSync(resolve(f.root, 'applications/campus')), false);
  const g = fixture(), mapped = resolve(g.root, 'local/shared provider'); mkdirSync(resolve(g.root, 'local'), { recursive: true }); git(g.root, ['clone', '--no-hardlinks', '--', g.manifest.repositories[2].source, mapped]);
  const linked = await g.run('init', { links: { provider: 'local/shared provider' } }); assert.equal(linked.exitCode, 0); assert.equal(existsSync(resolve(g.root, 'providers/shared')), false);
  assert.ok(linked.sourceLinks.every(link => link.providerRealpath === realpathSync(mapped))); assert.equal(row(g, 'earth').providerRealpath, row(g, 'campus').providerRealpath);
  const repeated = await g.run(); assert.equal(repeated.exitCode, 0); assert.equal(repeated.choices.links.provider, 'local/shared provider'); assert.ok(repeated.sourceLinks.every(link => link.providerRealpath === realpathSync(mapped))); assert.ok(repeated.steps.filter(step => step.fingerprint).every(step => step.reused));
  const missing = fixture(); assert.equal((await missing.run('init', { links: { provider: 'local/not-present' } })).exitCode, 1); assert.equal(existsSync(missing.root), false);
});
test('source-default wrapper uses public mode and explicit CLI exact override installs independent immutable packages', async () => {
  const f = fixture(), manifestPath = resolve(scratch, `manifest-${serial++}.json`); writeFileSync(manifestPath, JSON.stringify(f.manifest));
  const linked = await runCli({ args: ['init', '--manifest', manifestPath, '--root', f.root, '--apply'], mode: 'source', write: () => {} }); assert.equal(linked.exitCode, 0); assert.equal(linked.mode, 'source');
  const exactRoot = `${f.root} exact`, exact = await runCli({ args: ['init', '--manifest', manifestPath, '--root', exactRoot, '--mode', 'exact', '--apply'], mode: 'source', write: () => {} }); assert.equal(exact.exitCode, 0); assert.equal(exact.mode, 'exact'); assert.equal(exact.sourceLinks.length, 0);
  for (const consumer of ['earth', 'campus']) { const installed = resolve(exactRoot, `applications/${consumer}/node_modules/${packageName}`); assert.equal(lstatSync(installed).isSymbolicLink(), false); assert.equal(JSON.parse(readFileSync(resolve(exactRoot, `applications/${consumer}/dist/receipt.json`))).identity, 'immutable-artifact'); for (const [path, bytes] of Object.entries(f.artifactFiles)) assert.equal(readFileSync(resolve(installed, path), 'utf8'), bytes); }
  writeFileSync(resolve(f.root, 'providers/shared/dist/index.mjs'), 'export const identity = "changed developer output";\n');
  const before = snapshot(f.root), rejected = await f.run('init', { mode: 'exact' }); assert.equal(rejected.exitCode, 1); assert.deepEqual(snapshot(f.root), before);
  const doctor = await workspace({ action: 'doctor', root: exactRoot, manifest: f.manifest, digest: sha256(JSON.stringify(f.manifest)), mode: 'exact' }); assert.equal(doctor.exitCode, 0); assert.ok(doctor.installedPackages.every(identity => identity.valid));
  const unknownRoot = `${f.root} unknown`; assert.equal((await runCli({ args: ['init', '--manifest', manifestPath, '--root', unknownRoot, '--mode', 'automatic', '--apply'], write: () => {} })).exitCode, 2); assert.equal(existsSync(unknownRoot), false);
  await assert.rejects(f.run('init', { mode: 'exact', links: { provider: 'providers/shared' } }), /Exact mode/);
});
test('owner reinstall suspends source links and restores them before receipt hashing; retained artifact bytes and provider source survive', async () => {
  const f = fixture(); assert.equal((await f.run()).exitCode, 0); const provider = resolve(f.root, 'providers/shared'), before = readFileSync(resolve(provider, 'package.json'));
  writeFileSync(resolve(f.root, 'applications/earth/dist/receipt.json'), 'invalidate consumer build'); f.manifest.repositories[0].steps[0].argv.push('explicit-reinstall');
  const reinstall = await f.run(); assert.equal(reinstall.exitCode, 0); assert.equal(readFileSync(resolve(f.root, 'applications/earth/build/install-count'), 'utf8'), '2');
  assert.ok(readFileSync(resolve(provider, 'package.json')).equals(before)); assert.equal(git(provider, ['status', '--porcelain']).stdout.trim(), ''); assert.equal(row(f, 'earth').identity, 'source-provider');
  const backups = resolve(f.root, 'build/dev-installer/link-backups'); assert.ok(readdirSync(backups).some(name => lstatSync(resolve(backups, name)).isSymbolicLink()));
  assert.ok(readdirSync(backups).some(name => { const path = resolve(backups, name, 'dist/index.mjs'); return existsSync(path) && readFileSync(path, 'utf8').includes('immutable-artifact'); }));
  const repeat = await f.run(); assert.equal(repeat.exitCode, 0); assert.equal(readFileSync(resolve(f.root, 'applications/earth/build/install-count'), 'utf8'), '2');
});
test('failed provider build blocks consumers and resumes after explicit repair with no duplicate source checkout', async () => {
  const f = fixture(), prepared = structuredClone(f.manifest); prepared.repositories[2].steps = []; prepared.links = [];
  assert.equal((await f.run('init', { manifest: prepared, digest: sha256(JSON.stringify(prepared)), selections: ['provider'], mode: 'exact' })).exitCode, 0);
  const provider = resolve(f.root, 'providers/shared'); mkdirSync(resolve(provider, 'build'), { recursive: true }); writeFileSync(resolve(provider, 'build/fail'), 'synthetic failure');
  const failed = await f.run(); assert.equal(failed.exitCode, 2); assert.equal(existsSync(resolve(f.root, 'applications/earth')), false); assert.equal(existsSync(resolve(f.root, 'applications/campus')), false);
  renameSync(resolve(provider, 'build/fail'), resolve(provider, 'build/retained-failure')); assert.equal((await f.run()).exitCode, 0); assert.equal(row(f, 'earth').providerRealpath, realpathSync(provider));
});
test('missing source-link contracts/selections, link cycles, duplicate repositories and repository-nested layouts fail before mutation', async () => {
  for (const kind of ['selection', 'contract', 'version', 'cycle', 'mixed-cycle', 'self', 'duplicate']) {
    const f = fixture();
    if (kind === 'selection') { for (const repo of f.manifest.repositories.slice(0, 2)) repo.dependsOn = ['shared-package']; f.manifest.repositories[2].optional = true; }
    if (kind === 'contract') { delete f.manifest.links[0].version; delete f.manifest.links[0].outputs; f.manifest.repositories[0].installedPackages = []; }
    if (kind === 'version') f.manifest.links[0].version = '^1.0.0';
    if (kind === 'cycle') { for (const repo of f.manifest.repositories.slice(0, 2)) repo.dependsOn = ['shared-package']; f.manifest.defaultComponents.push('provider'); }
    if (kind === 'cycle' || kind === 'mixed-cycle') f.manifest.links.push({ consumer: 'provider', provider: 'earth', package: '@fixture/earth', version, outputs: ['package.json'] });
    if (kind === 'self') f.manifest.links[0].provider = 'earth';
    if (kind === 'duplicate') f.manifest.repositories[1].repository = f.manifest.repositories[2].repository;
    await assert.rejects(f.run()); assert.equal(existsSync(f.root), false);
  }
  const nested = fixture(); mkdirSync(nested.root); git(nested.root, ['init', '--quiet', '--initial-branch=main']); const before = snapshot(nested.root); await assert.rejects(nested.run(), /shared non-repository/); assert.deepEqual(snapshot(nested.root), before);
  const overlap = fixture(); overlap.manifest.repositories[2].destination = 'applications/earth/provider'; await assert.rejects(overlap.run(), /overlap/); assert.equal(existsSync(overlap.root), false);
  const escape = fixture(); mkdirSync(escape.root); symlinkSync(scratch, resolve(escape.root, 'outside'), 'dir'); const state = snapshot(escape.root); await assert.rejects(escape.run('init', { links: { provider: 'outside/provider' } }), /symbolic link/); assert.deepEqual(snapshot(escape.root), state);
});
test('wrong provider package name/version/revision/origin and dirty work preserve all source, links and ignored evidence', async () => {
  for (const kind of ['name', 'version', 'revision', 'origin', 'dirty', 'untracked']) {
    const f = fixture(), mapped = resolve(f.root, 'providers/shared'); mkdirSync(resolve(f.root, 'providers'), { recursive: true });
    if (kind === 'name' || kind === 'version') { writeFileSync(resolve(f.provider.path, 'package.json'), JSON.stringify({ ...metadata, [kind]: kind === 'name' ? '@fixture/wrong' : '2.0.0' })); f.manifest.repositories[2].revision = commit(f.provider.path, 'Synthetic incompatible provider identity'); }
    git(f.root, ['clone', '--no-hardlinks', '--', f.manifest.repositories[2].source, mapped]);
    mkdirSync(resolve(mapped, 'build'), { recursive: true }); writeFileSync(resolve(mapped, 'build/evidence.bin'), 'irreplaceable synthetic evidence');
    if (kind === 'revision') { writeFileSync(resolve(mapped, 'local.txt'), 'local preserved commit'); commit(mapped, 'Synthetic local source divergence'); }
    if (kind === 'origin') git(mapped, ['remote', 'set-url', 'origin', pathToFileURL(resolve(scratch, 'wrong-origin')).href]);
    if (kind === 'dirty') writeFileSync(resolve(mapped, 'package.json'), 'dirty preserved source');
    if (kind === 'untracked') writeFileSync(resolve(mapped, 'user.txt'), 'untracked preserved work');
    const before = snapshot(f.root), head = git(mapped, ['rev-parse', 'HEAD']).stdout;
    const stopped = await f.run(); assert.equal(stopped.exitCode, 1); assert.deepEqual(snapshot(f.root), before); assert.equal(git(mapped, ['rev-parse', 'HEAD']).stdout, head); assert.equal(existsSync(resolve(f.root, 'applications/earth')), false);
  }
});
test('conflicting or dangling consumer links stop in preflight and preserve their targets', async () => {
  for (const dangling of [false, true]) {
    const f = fixture(); assert.equal((await f.run()).exitCode, 0); const target = resolve(f.root, 'applications/earth/node_modules/@fixture/shared'); renameSync(target, resolve(f.root, 'applications/earth/build/retained-link'));
    const wrong = resolve(f.root, dangling ? 'not-present' : 'applications/campus'); symlinkSync(wrong, target, 'dir'); const before = snapshot(f.root);
    const stopped = await f.run(); assert.equal(stopped.exitCode, 1); assert.ok(stopped.issues.some(issue => issue.rule === 'links.identity')); assert.deepEqual(snapshot(f.root), before);
  }
});
for (const [providerFile, expectedRule] of [['package.json', 'repository.modified'], ['dist/index.mjs', 'links.outputs-modified']]) test(`transitive provider ${providerFile} mutation cannot leave a reusable success receipt`, async () => {
  const f = fixture(), campusMetadata = { name: '@fixture/campus', version, type: 'module', exports: { '.': './dist/index.mjs' } };
  writeFileSync(resolve(f.campus.path, 'package.json'), JSON.stringify(campusMetadata));
  writeFileSync(resolve(f.campus.path, 'build.mjs'), readFileSync(resolve(f.campus.path, 'build.mjs'), 'utf8') + '\nwriteFileSync("dist/index.mjs",`export const campus = true;\\n`);\n');
  f.manifest.repositories[1].revision = commit(f.campus.path, 'Synthetic intermediate source provider'); f.manifest.repositories[1].steps[1].outputs.push('dist/index.mjs');
  writeFileSync(resolve(f.earth.path, 'build.mjs'), readFileSync(resolve(f.earth.path, 'build.mjs'), 'utf8') + `\nimport{existsSync as hasTrigger}from"node:fs";mkdirSync("build",{recursive:true});const count=hasTrigger("build/count")?Number(readFileSync("build/count")):0;writeFileSync("build/count",String(count+1));if(hasTrigger("build/taint-transitive"))writeFileSync(${JSON.stringify(`node_modules/@fixture/campus/node_modules/@fixture/shared/${providerFile}`)},"modified transitive provider");\n`);
  f.manifest.repositories[0].revision = commit(f.earth.path, 'Synthetic transitive source-mutation trigger'); f.manifest.repositories[0].dependsOn = ['campus', 'shared-package'];
  f.manifest.links = [{ consumer: 'earth', provider: 'campus', package: '@fixture/campus', version, outputs: ['dist/index.mjs'] }, f.manifest.links[1]];
  assert.equal((await f.run()).exitCode, 0);
  const providerMetadata = resolve(f.root, 'providers/shared', providerFile), original = readFileSync(providerMetadata), earth = resolve(f.root, 'applications/earth');
  writeFileSync(resolve(earth, 'build/taint-transitive'), 'synthetic trigger'); writeFileSync(resolve(earth, 'dist/receipt.json'), 'invalidate build output');
  const failed = await f.run(); assert.equal(failed.exitCode, 2); assert.ok(failed.issues.some(issue => issue.rule === expectedRule)); const failedBuild = failed.steps.find(step => step.id === 'earth:build'); assert.equal(failedBuild.status, 'failed'); assert.equal(failed.steps.some(step => step.fingerprint === failedBuild.fingerprint && step.status === 'passed'), false); const journal = readFileSync(resolve(f.root, 'build/dev-installer/steps.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line)); assert.equal(journal.filter(step => step.fingerprint === failedBuild.fingerprint).at(-1).status, 'failed'); assert.equal(readFileSync(resolve(earth, 'build/count'), 'utf8'), '2');
  writeFileSync(providerMetadata, original); renameSync(resolve(earth, 'build/taint-transitive'), resolve(earth, 'build/retained-transitive-trigger'));
  const repaired = await f.run(); assert.equal(repaired.exitCode, 0); assert.equal(repaired.steps.find(step => step.id === 'earth:build').reused, false); assert.equal(readFileSync(resolve(earth, 'build/count'), 'utf8'), '3');
});
test('clean source sync may upgrade package version after reaching the new exact provider pin', async () => {
  const f = fixture(); assert.equal((await f.run()).exitCode, 0);
  const nextMetadata = { ...metadata, version: '2.0.0' }; writeFileSync(resolve(f.provider.path, 'package.json'), JSON.stringify(nextMetadata)); f.manifest.repositories[2].revision = commit(f.provider.path, 'Synthetic compatible provider version upgrade');
  const nextFiles = { ...f.artifactFiles, 'package.json': JSON.stringify(nextMetadata) }, bytes = Buffer.from(JSON.stringify(nextFiles)), artifact = resolve(scratch, `next-package-${serial++}.json`); writeFileSync(artifact, bytes);
  Object.assign(f.manifest.artifacts[0], { location: pathToFileURL(artifact).href, destination: 'artifacts/shared-package-v2.json', sha256: sha256(bytes), sizeBytes: bytes.length });
  f.manifest.version = '2'; for (const link of f.manifest.links) link.version = '2.0.0';
  for (const repo of f.manifest.repositories.slice(0, 2)) Object.assign(repo.installedPackages[0], { version: '2.0.0', files: Object.fromEntries(Object.entries(nextFiles).map(([path, bytes]) => [path, sha256(bytes)])) });
  const before = snapshot(f.root); assert.equal((await f.run('init')).exitCode, 1); assert.deepEqual(snapshot(f.root), before);
  const sync = await f.run('sync'); assert.equal(sync.exitCode, 0); assert.ok(sync.sourceLinks.every(link => link.resolved && link.ready && link.expectedVersion === '2.0.0')); assert.equal(git(resolve(f.root, 'providers/shared'), ['rev-parse', 'HEAD']).stdout.trim(), f.manifest.repositories[2].revision);
  assert.equal(existsSync(resolve(f.root, 'artifacts/shared-package.json')), true); assert.equal(row(f, 'earth').providerRealpath, row(f, 'campus').providerRealpath);
});
test('unsafe required provider exports stop before receipt-only builds can follow a symlink', async () => {
  const f = fixture(); writeFileSync(resolve(f.provider.path, 'build.mjs'), readFileSync(resolve(f.provider.path, 'build.mjs'), 'utf8') + '\nwriteFileSync("dist/build-receipt.json",JSON.stringify({built:true}));\n');
  f.manifest.repositories[2].revision = commit(f.provider.path, 'Synthetic receipt-only provider build'); f.manifest.repositories[2].steps[0].outputs = ['dist/build-receipt.json'];
  assert.equal((await f.run()).exitCode, 0);
  const provider = resolve(f.root, 'providers/shared'), exported = resolve(provider, 'dist/index.mjs'), target = resolve(f.root, 'evidence/irreplaceable.mjs'); mkdirSync(resolve(f.root, 'evidence')); writeFileSync(target, 'preserved user bytes'); renameSync(exported, resolve(provider, 'build/retained-index.mjs')); symlinkSync(target, exported);
  const before = snapshot(f.root), stopped = await f.run(); assert.equal(stopped.exitCode, 1); assert.ok(stopped.issues.some(issue => issue.rule === 'path.symlink')); assert.deepEqual(snapshot(f.root), before); assert.equal(readFileSync(target, 'utf8'), 'preserved user bytes');
});

test('independent owner manifests share the mapped provider and reuse its own build contract', async () => {
  const f = fixture(), provider = resolve(f.root, 'providers/shared');
  const ownerManifest = id => ({ ...structuredClone(f.manifest), id: `owner-${id}`, repositories: f.manifest.repositories.filter(repo => repo.id === id || repo.id === 'provider'), defaultComponents: [id], selections: {}, links: f.manifest.links.filter(link => link.consumer === id) });
  const earth = ownerManifest('earth'), campus = ownerManifest('campus');
  assert.equal((await f.run('init', { manifest: earth, digest: sha256(JSON.stringify(earth)) })).exitCode, 0);
  const earthBefore = snapshot(resolve(f.root, 'applications/earth'));
  const second = await f.run('init', { manifest: campus, digest: sha256(JSON.stringify(campus)), links: { provider: 'providers/shared' } });
  assert.equal(second.exitCode, 0); assert.equal(second.steps.find(step => step.id === 'provider:build').reused, true); assert.deepEqual(snapshot(resolve(f.root, 'applications/earth')), earthBefore);
  assert.equal(row(f, 'earth').providerRealpath, row(f, 'campus').providerRealpath); assert.equal(readFileSync(resolve(provider, 'build/count'), 'utf8'), '1');
});
test('a successful receipt-only provider build still blocks consumers when a required type export is absent', async () => {
  const f = fixture(); let build = readFileSync(resolve(f.provider.path, 'build.mjs'), 'utf8');
  build = build.replace('mkdirSync,writeFileSync', 'renameSync,mkdirSync,writeFileSync') + '\nrenameSync("dist/index.d.ts","build/retained-type.d.ts");writeFileSync("dist/build-receipt.json",JSON.stringify({built:true}));';
  writeFileSync(resolve(f.provider.path, 'build.mjs'), build); f.manifest.repositories[2].revision = commit(f.provider.path, 'Synthetic successful incomplete public export build'); f.manifest.repositories[2].steps[0].outputs = ['dist/build-receipt.json'];
  const failed = await f.run(); assert.equal(failed.exitCode, 2); assert.ok(failed.issues.some(issue => issue.rule === 'links.package')); assert.equal(failed.steps.find(step => step.id === 'provider:build').status, 'passed');
  assert.equal(existsSync(resolve(f.root, 'applications/earth')), false); assert.equal(existsSync(resolve(f.root, 'applications/campus')), false); assert.equal(existsSync(resolve(f.root, 'providers/shared/build/retained-type.d.ts')), true);
});
test('failed installation preserves suspended links and partial bytes; explicit repair resumes and restores the same provider', async () => {
  const f = fixture(); writeFileSync(resolve(f.earth.path, 'install.mjs'), readFileSync(resolve(f.earth.path, 'install.mjs'), 'utf8') + '\nif(existsSync("build/fail-install")){writeFileSync("node_modules/@fixture/shared/dist/index.mjs","partial synthetic install evidence");process.exit(9);}'); f.manifest.repositories[0].revision = commit(f.earth.path, 'Synthetic resumable failed owner install');
  assert.equal((await f.run()).exitCode, 0); const provider = resolve(f.root, 'providers/shared'), providerBefore = snapshot(provider), earth = resolve(f.root, 'applications/earth');
  writeFileSync(resolve(earth, 'build/fail-install'), 'synthetic failure'); f.manifest.repositories[0].steps[0].argv.push('explicit-reinstall');
  const failed = await f.run(); assert.equal(failed.exitCode, 2); assert.equal(failed.steps.find(step => step.id === 'earth:install').status, 'failed'); assert.deepEqual(snapshot(provider), providerBefore); assert.equal(readFileSync(resolve(earth, `node_modules/${packageName}/dist/index.mjs`), 'utf8'), 'partial synthetic install evidence');
  const state = JSON.parse(readFileSync(resolve(f.root, 'build/dev-installer/workspaces/source-workspace.json'))); assert.equal(state.status, 'pending'); assert.ok(state.applied);
  renameSync(resolve(earth, 'build/fail-install'), resolve(earth, 'build/retained-install-trigger')); assert.equal((await f.run()).exitCode, 0); assert.equal(row(f, 'earth').providerRealpath, realpathSync(provider)); assert.deepEqual(snapshot(provider), providerBefore);
  const backups = resolve(f.root, 'build/dev-installer/link-backups'); assert.ok(readdirSync(backups).some(name => { const path = resolve(backups, name, 'dist/index.mjs'); return existsSync(path) && readFileSync(path, 'utf8') === 'partial synthetic install evidence'; }));
});
test('changed regular provider public output invalidates consumer receipts even when the provider build receipt is reusable', async () => {
  const f = fixture(); writeFileSync(resolve(f.provider.path, 'build.mjs'), readFileSync(resolve(f.provider.path, 'build.mjs'), 'utf8') + '\nwriteFileSync("dist/build-receipt.json",JSON.stringify({built:true}));'); f.manifest.repositories[2].revision = commit(f.provider.path, 'Synthetic independent public input fingerprint'); f.manifest.repositories[2].steps[0].outputs = ['dist/build-receipt.json'];
  assert.equal((await f.run()).exitCode, 0); const provider = resolve(f.root, 'providers/shared'); writeFileSync(resolve(provider, 'dist/index.mjs'), 'export const identity = "updated local public input";\n');
  const next = await f.run(); assert.equal(next.exitCode, 0); assert.equal(next.steps.find(step => step.id === 'provider:build').reused, true); assert.equal(next.steps.find(step => step.id === 'earth:build').reused, false); assert.equal(row(f, 'earth').identity, 'updated local public input'); assert.equal(row(f, 'campus').identity, 'updated local public input'); assert.equal(readFileSync(resolve(provider, 'build/count'), 'utf8'), '1');
});
test('source and hybrid setup preserve exact generated inputs and never select native/WASM/media opt-ins implicitly', async () => {
  for (const mode of ['source', 'hybrid']) {
    const f = fixture(); for (const repo of f.manifest.repositories) for (const name of ['native', 'wasm', 'media']) repo.steps.push({ id: name, kind: 'build', optIn: name, argv: ['node', '-e', `require("node:fs").writeFileSync("build/unexpected-${name}","unexpected")`], outputs: [] });
    const initialized = await f.run('init', { mode }); assert.equal(initialized.exitCode, 0); assert.equal(initialized.steps.some(step => /:(native|wasm|media)$/.test(step.id)), false); assert.equal(initialized.artifacts.every(artifact => artifact.valid), true);
    for (const repo of initialized.repositories) for (const name of ['native', 'wasm', 'media']) assert.equal(existsSync(resolve(f.root, f.manifest.repositories.find(item => item.id === repo.id).destination, `build/unexpected-${name}`)), false);
  }
});

test('hybrid defaults use packages without provider clones, persist choices, switch one shared provider and preserve dirty inactive work', async () => {
  const f = fixture();
  for (const [id, input] of [['earth', f.earth], ['campus', f.campus]]) { writeFileSync(resolve(input.path, 'build.mjs'), readFileSync(resolve(input.path, 'build.mjs'), 'utf8').replace('readFileSync,writeFileSync,mkdirSync', 'existsSync,readFileSync,writeFileSync,mkdirSync') + '\nmkdirSync("build",{recursive:true});const count=existsSync("build/count")?Number(readFileSync("build/count")):0;writeFileSync("build/count",String(count+1));'); f.manifest.repositories.find(repo => repo.id === id).revision = commit(input.path, 'Synthetic hybrid consumer build counter'); }
  const independent = source('independent', { 'build.mjs': 'import{mkdirSync,writeFileSync,readFileSync,existsSync}from"node:fs";mkdirSync("build",{recursive:true});mkdirSync("dist",{recursive:true});const count=existsSync("build/count")?Number(readFileSync("build/count")):0;writeFileSync("build/count",String(count+1));writeFileSync("dist/receipt.json","independent");' });
  f.manifest.repositories.push({ id: 'independent', repository: 'fixture/independent', source: pathToFileURL(independent.path).href, revision: independent.revision, destination: 'applications/independent', dependsOn: [], steps: [{ id: 'build', kind: 'build', argv: ['node', 'build.mjs'], outputs: ['dist/receipt.json'] }] }); f.manifest.defaultComponents.push('independent');
  const hybridRun = extra => workspace({ action: 'init', root: f.root, manifest: f.manifest, digest: sha256(JSON.stringify(f.manifest)), apply: true, defaultMode: 'source', ...extra });
  const first = await hybridRun({ mode: 'hybrid' }); assert.equal(first.exitCode, 0); assert.equal(first.mode, 'hybrid'); assert.equal(first.repositories.some(repo => repo.id === 'provider'), false); assert.equal(existsSync(resolve(f.root, 'providers/shared')), false); assert.equal(first.sourceLinks.length, 0); assert.equal(row(f, 'earth').identity, 'immutable-artifact');
  const repeat = await hybridRun(); assert.equal(repeat.exitCode, 0); assert.equal(repeat.mode, 'hybrid'); assert.ok(repeat.steps.filter(step => step.fingerprint).every(step => step.reused));
  const providerRoot = resolve(f.root, 'providers/shared'), activated = await hybridRun({ components: { provider: 'source' } }); assert.equal(activated.exitCode, 0); assert.equal(activated.sourceLinks.length, 2); assert.equal(row(f, 'earth').providerRealpath, row(f, 'campus').providerRealpath); assert.equal(readFileSync(resolve(providerRoot, 'build/count'), 'utf8'), '1');
  const original = readFileSync(resolve(providerRoot, 'package.json')); writeFileSync(resolve(providerRoot, 'package.json'), 'preserved dirty developer metadata'); writeFileSync(resolve(providerRoot, 'editing.mjs'), 'preserved untracked edit'); writeFileSync(resolve(providerRoot, 'build/evidence.bin'), 'preserved ignored evidence'); const dirty = snapshot(providerRoot);
  const packaged = await hybridRun({ components: { provider: 'package' } }); assert.equal(packaged.exitCode, 0); assert.deepEqual(snapshot(providerRoot), dirty); assert.equal(row(f, 'earth').identity, 'immutable-artifact'); assert.equal(lstatSync(resolve(f.root, 'applications/earth/node_modules/@fixture/shared')).isSymbolicLink(), false);
  const before = snapshot(f.root), rejected = await hybridRun({ components: { provider: 'source' } }); assert.equal(rejected.exitCode, 1); assert.ok(rejected.issues.some(issue => issue.rule === 'repository.dirty')); assert.deepEqual(snapshot(f.root), before);
  writeFileSync(resolve(providerRoot, 'package.json'), original); renameSync(resolve(providerRoot, 'editing.mjs'), resolve(providerRoot, 'build/retained-editing.mjs'));
  const restored = await hybridRun({ components: { provider: 'source' } }); assert.equal(restored.exitCode, 0); assert.equal(restored.repositories.find(repo => repo.id === 'provider').exists, true); assert.equal(readFileSync(resolve(providerRoot, 'build/count'), 'utf8'), '1'); assert.equal(row(f, 'earth').providerRealpath, realpathSync(providerRoot));
  assert.equal(readFileSync(resolve(f.root, 'applications/independent/build/count'), 'utf8'), '1'); assert.equal(readFileSync(resolve(f.root, 'applications/earth/build/count'), 'utf8'), '4');
  const doctorBefore = snapshot(f.root), doctor = await hybridRun({ action: 'doctor', apply: false }); assert.equal(doctor.exitCode, 0); assert.deepEqual(snapshot(f.root), doctorBefore);
  const plan = await hybridRun({ apply: false, components: { provider: 'package' } }); assert.equal(plan.exitCode, 0); assert.deepEqual(snapshot(f.root), doctorBefore); assert.ok(plan.plan.some(item => item.kind === 'workspace-choices' && item.changed && !item.writes));
});

function packagedConsumerFixture() {
  const f = fixture(), simulatorName = '@fixture/campus', simulatorFiles = { 'package.json': JSON.stringify({ name: simulatorName, version, type: 'module', exports: { '.': './dist/index.mjs' } }), 'dist/index.mjs': 'export {identity} from "@fixture/shared";\n' };
  const bytes = Buffer.from(JSON.stringify(simulatorFiles)), artifact = resolve(scratch, `sim-package-${serial++}.json`); writeFileSync(artifact, bytes);
  f.manifest.artifacts.push({ id: 'sim-package', location: pathToFileURL(artifact).href, destination: 'artifacts/sim-package.json', sha256: sha256(bytes), sizeBytes: bytes.length });
  const content = Buffer.from('exact packaged runtime content'), contentPath = resolve(scratch, `runtime-content-${serial++}.bin`); writeFileSync(contentPath, content); f.manifest.artifacts.push({ id: 'runtime-content', location: pathToFileURL(contentPath).href, destination: 'artifacts/runtime-content.bin', sha256: sha256(content), sizeBytes: content.length }); f.manifest.repositories[1].dependsOn.push('runtime-content'); f.manifest.repositories[1].source = pathToFileURL(resolve(scratch, 'unavailable-packaged-consumer')).href;
  const earth = f.manifest.repositories[0]; earth.dependsOn = ['campus', 'shared-package', 'sim-package']; earth.installedPackages = [{ name: simulatorName, version, artifact: 'sim-package', files: Object.fromEntries(Object.entries(simulatorFiles).map(([path, bytes]) => [path, sha256(bytes)])) }];
  writeFileSync(resolve(f.earth.path, 'install.mjs'), 'import{mkdirSync,writeFileSync,readFileSync,existsSync,lstatSync}from"node:fs";import{resolve,dirname}from"node:path";const sim="node_modules/@fixture/campus";if(existsSync(sim)&&lstatSync(sim).isSymbolicLink())throw Error("source consumer reached install");for(const[root,input]of[[sim,process.argv[2]],[sim+"/node_modules/@fixture/shared",process.argv[3]]])for(const[file,bytes]of Object.entries(JSON.parse(readFileSync(input)))){mkdirSync(dirname(resolve(root,file)),{recursive:true});writeFileSync(resolve(root,file),bytes);}');
  writeFileSync(resolve(f.earth.path, 'build.mjs'), 'import{identity}from"@fixture/campus";import{mkdirSync,writeFileSync,realpathSync}from"node:fs";mkdirSync("dist",{recursive:true});writeFileSync("dist/receipt.json",JSON.stringify({identity,providerRealpath:realpathSync("node_modules/@fixture/campus/node_modules/@fixture/shared")}));'); earth.revision = commit(f.earth.path, 'Synthetic packaged consumer of edited source provider');
  earth.steps[0].argv = ['node', 'install.mjs', '{artifact:sim-package}', '{artifact:shared-package}']; earth.steps[0].outputs = Object.keys(simulatorFiles).map(path => `node_modules/${simulatorName}/${path}`); earth.steps[0].outputs.push(...Object.keys(f.artifactFiles).map(path => `node_modules/${simulatorName}/node_modules/${packageName}/${path}`));
  f.manifest.defaultComponents = ['earth']; f.manifest.links = [{ consumer: 'earth', provider: 'campus', package: simulatorName, version, outputs: ['dist/index.mjs'] }, f.manifest.links[1]];
  f.runtimeContent = content; return f;
}
test('a packaged consumer imports an edited source provider through its declared installed package mount', async () => {
  const f = packagedConsumerFixture();
  const first = await f.run('init', { mode: 'hybrid', components: { provider: 'source', campus: 'package' } }); assert.equal(first.exitCode, 0); assert.deepEqual(first.repositories.map(repo => repo.id).sort(), ['earth', 'provider']); assert.equal(existsSync(resolve(f.root, 'applications/campus')), false); assert.equal(row(f, 'earth').identity, 'source-provider'); assert.equal(row(f, 'earth').providerRealpath, realpathSync(resolve(f.root, 'providers/shared'))); assert.equal(first.sourceLinks[0].consumer, 'campus'); assert.equal(first.sourceLinks[0].owner, 'earth'); assert.equal(first.installedPackages.every(row => row.valid), true); assert.equal(first.artifacts.find(artifact => artifact.id === 'runtime-content').valid, true); assert.ok(readFileSync(resolve(f.root, 'artifacts/runtime-content.bin')).equals(f.runtimeContent));
  const second = await f.run('init', { mode: 'hybrid', components: { provider: 'package' } }); assert.equal(second.exitCode, 0); assert.equal(row(f, 'earth').identity, 'immutable-artifact'); assert.equal(second.sourceLinks.length, 0); assert.equal(lstatSync(resolve(f.root, 'applications/earth/node_modules/@fixture/campus/node_modules/@fixture/shared')).isSymbolicLink(), false);
});

test('wrong packaged consumer identity or public bytes fail before source activation or consumer code', async () => {
  for (const target of ['package.json', 'dist/index.mjs']) {
    const f = packagedConsumerFixture(); writeFileSync(resolve(f.earth.path, 'install.mjs'), readFileSync(resolve(f.earth.path, 'install.mjs'), 'utf8') + `\nwriteFileSync("node_modules/@fixture/campus/${target}",${JSON.stringify(target === 'package.json' ? JSON.stringify({ name: '@fixture/wrong', version }) : 'preserved stale public package bytes')});`); f.manifest.repositories[0].revision = commit(f.earth.path, 'Synthetic invalid packaged parent installation');
    const failed = await f.run('init', { mode: 'hybrid', components: { provider: 'source', campus: 'package' } }); assert.equal(failed.exitCode, 2); assert.ok(failed.issues.some(issue => issue.rule === 'package.identity')); assert.equal(failed.steps.find(step => step.id === 'earth:install').status, 'failed'); assert.equal(failed.steps.some(step => step.id === 'earth:build'), false); assert.equal(existsSync(resolve(f.root, 'applications/earth/dist/receipt.json')), false); assert.equal(lstatSync(resolve(f.root, 'applications/earth/node_modules/@fixture/campus/node_modules/@fixture/shared')).isSymbolicLink(), false);
  }
});

test('retained nested witnesses survive switching a packaged parent to source and repeating read-only diagnosis', async () => {
  const f = packagedConsumerFixture(), campus = f.manifest.repositories[1];
  writeFileSync(resolve(f.campus.path, 'package.json'), JSON.stringify({ name: '@fixture/campus', version, type: 'module', exports: { '.': './dist/index.mjs' } }));
  writeFileSync(resolve(f.campus.path, 'build.mjs'), readFileSync(resolve(f.campus.path, 'build.mjs'), 'utf8') + '\nwriteFileSync("dist/index.mjs",\'export {identity} from "@fixture/shared";\\n\');');
  campus.source = pathToFileURL(f.campus.path).href; campus.revision = commit(f.campus.path, 'Synthetic source parent with public package export'); campus.steps[1].outputs.push('dist/index.mjs');
  const first = await f.run('init', { mode: 'hybrid', components: { provider: 'source', campus: 'package' } }); assert.equal(first.exitCode, 0);
  const source = await f.run('sync', { mode: 'hybrid', components: { campus: 'source' } }); assert.equal(source.exitCode, 0);
  assert.equal(lstatSync(resolve(f.root, 'applications/earth/node_modules/@fixture/campus')).isSymbolicLink(), true);
  const stored = JSON.parse(readFileSync(resolve(f.root, 'build/dev-installer/workspaces/source-workspace.json'))); assert.ok(stored.managedLinks.some(witness => witness.consumerRoot.includes('node_modules/@fixture/campus')));
  const repeat = await f.run('init', { mode: undefined }); assert.equal(repeat.exitCode, 0);
  const before = snapshot(f.root); assert.equal((await f.run('doctor', { mode: undefined })).exitCode, 0); assert.deepEqual(snapshot(f.root), before);
});

test('hybrid invalid choices and missing immutable backing stop before provisioning', async () => {
  for (const components of [{ unknown: 'source' }, { provider: 'floating' }, { earth: 'package' }]) { const f = fixture(); await assert.rejects(f.run('init', { mode: 'hybrid', components })); assert.equal(existsSync(f.root), false); }
  const f = fixture(); f.manifest.repositories[0].installedPackages = []; await assert.rejects(f.run('init', { mode: 'hybrid' }), /installedPackages/); assert.equal(existsSync(f.root), false);
});

test('hybrid package projections require an explicit exclusion for source-only build prerequisites', async () => {
  const f = fixture(), native = source('native-prerequisite', { 'input.txt': 'synthetic native source never built' });
  f.manifest.repositories.push({ id: 'native', repository: 'fixture/native', source: pathToFileURL(native.path).href, revision: native.revision, destination: 'native/sdk', dependsOn: [], steps: [] }); f.manifest.repositories[2].dependsOn.push('native');
  await assert.rejects(f.run('init', { mode: 'hybrid' }), /packageDependsOn/); assert.equal(existsSync(f.root), false);
  f.manifest.repositories[2].packageDependsOn = [];
  const packaged = await f.run('init', { mode: 'hybrid' }); assert.equal(packaged.exitCode, 0); assert.equal(existsSync(resolve(f.root, 'providers/shared')), false); assert.equal(existsSync(resolve(f.root, 'native/sdk')), false);
});

test('a hybrid package switch resumes from last applied source choices after acquisition fails before suspension', async () => {
  const f = fixture(); assert.equal((await f.run()).exitCode, 0); const providerBefore = snapshot(resolve(f.root, 'providers/shared')), originalLocation = f.manifest.artifacts[0].location;
  f.manifest.artifacts[0].destination = 'artifacts/shared-package-retry.json'; f.manifest.artifacts[0].location = pathToFileURL(resolve(scratch, 'missing-switch-artifact.json')).href;
  const failed = await f.run('init', { mode: 'hybrid', components: { provider: 'package' } }); assert.equal(failed.exitCode, 2); assert.equal(lstatSync(resolve(f.root, 'applications/earth/node_modules/@fixture/shared')).isSymbolicLink(), true); assert.deepEqual(snapshot(resolve(f.root, 'providers/shared')), providerBefore);
  const pending = JSON.parse(readFileSync(resolve(f.root, 'build/dev-installer/workspaces/source-workspace.json'))); assert.equal(pending.status, 'pending'); assert.equal(pending.components.provider, 'package'); assert.equal(pending.applied.mode, 'source');
  f.manifest.artifacts[0].location = originalLocation;
  const resumed = await f.run('init', { mode: undefined, defaultMode: 'source' }); assert.equal(resumed.exitCode, 0); assert.equal(resumed.mode, 'hybrid'); assert.equal(resumed.choices.status, 'applied'); assert.equal(lstatSync(resolve(f.root, 'applications/earth/node_modules/@fixture/shared')).isSymbolicLink(), false); assert.equal(row(f, 'earth').identity, 'immutable-artifact'); assert.deepEqual(snapshot(resolve(f.root, 'providers/shared')), providerBefore);
});

test('a partially activated pending source choice can be cancelled to packages without losing its provider', async () => {
  const f = fixture(); writeFileSync(resolve(f.earth.path, 'build.mjs'), 'import{existsSync}from"node:fs";if(existsSync("build/fail-build"))process.exit(8);\n' + readFileSync(resolve(f.earth.path, 'build.mjs'), 'utf8')); f.manifest.repositories[0].revision = commit(f.earth.path, 'Synthetic failed source activation build');
  assert.equal((await f.run('init', { mode: 'hybrid' })).exitCode, 0); const earth = resolve(f.root, 'applications/earth'); mkdirSync(resolve(earth, 'build'), { recursive: true }); writeFileSync(resolve(earth, 'build/fail-build'), 'synthetic failure');
  const failed = await f.run('init', { mode: 'hybrid', components: { provider: 'source' } }); assert.equal(failed.exitCode, 2); assert.equal(lstatSync(resolve(earth, 'node_modules/@fixture/shared')).isSymbolicLink(), true); assert.equal(failed.choices.status, 'pending'); assert.equal(failed.choices.applied.components.provider, undefined);
  const providerBefore = snapshot(resolve(f.root, 'providers/shared')); renameSync(resolve(earth, 'build/fail-build'), resolve(earth, 'build/retained-fail-build'));
  const cancelled = await f.run('init', { mode: 'hybrid', components: { provider: 'package' } }); assert.equal(cancelled.exitCode, 0); assert.equal(cancelled.choices.status, 'applied'); assert.equal(row(f, 'earth').identity, 'immutable-artifact'); assert.deepEqual(snapshot(resolve(f.root, 'providers/shared')), providerBefore);
});

test('a new exact package release can replace links while preserving an older admitted source pin', async () => {
  const f = fixture(); assert.equal((await f.run()).exitCode, 0); const provider = resolve(f.root, 'providers/shared'), before = snapshot(provider), oldPin = git(provider, ['rev-parse', 'HEAD']).stdout.trim();
  const nextMetadata = { ...metadata, version: '2.0.0' }; writeFileSync(resolve(f.provider.path, 'package.json'), JSON.stringify(nextMetadata)); f.manifest.repositories[2].revision = commit(f.provider.path, 'Synthetic new packaged provider release');
  const files = { ...f.artifactFiles, 'package.json': JSON.stringify(nextMetadata) }, bytes = Buffer.from(JSON.stringify(files)), artifact = resolve(scratch, `switch-new-release-${serial++}.json`); writeFileSync(artifact, bytes); Object.assign(f.manifest.artifacts[0], { location: pathToFileURL(artifact).href, destination: 'artifacts/shared-package-new.json', sha256: sha256(bytes), sizeBytes: bytes.length });
  for (const link of f.manifest.links) link.version = '2.0.0'; for (const repo of f.manifest.repositories.slice(0, 2)) Object.assign(repo.installedPackages[0], { version: '2.0.0', files: Object.fromEntries(Object.entries(files).map(([path, bytes]) => [path, sha256(bytes)])) });
  const packaged = await f.run('init', { mode: 'hybrid', components: { provider: 'package' } }); assert.equal(packaged.exitCode, 0); assert.ok(packaged.installedPackages.every(identity => identity.valid)); assert.equal(git(provider, ['rev-parse', 'HEAD']).stdout.trim(), oldPin); assert.deepEqual(snapshot(provider), before); assert.equal(JSON.parse(readFileSync(resolve(f.root, 'applications/earth/node_modules/@fixture/shared/package.json'))).version, '2.0.0');
});

test('valid prototype-like component IDs retain own-map source/package and selection semantics', async () => {
  const f = fixture(); f.manifest.repositories[2].id = 'constructor'; for (const repo of f.manifest.repositories.slice(0, 2)) repo.dependsOn = repo.dependsOn.map(id => id === 'provider' ? 'constructor' : id); for (const link of f.manifest.links) link.provider = 'constructor'; f.manifest.selections = { earth: ['earth'] };
  const packaged = await f.run('init', { mode: 'hybrid' }); assert.equal(packaged.exitCode, 0); assert.equal(packaged.repositories.some(repo => repo.id === 'constructor'), false); assert.equal(existsSync(resolve(f.root, 'providers/shared')), false);
  const selected = await f.run('init', { mode: 'hybrid', selections: ['constructor'] }); assert.equal(selected.exitCode, 0); assert.deepEqual(selected.repositories.map(repo => repo.id), ['constructor']); assert.equal(existsSync(resolve(f.root, 'providers/shared')), true);
});

test('saved hybrid selected roots prevent extra source downloads and explicit --all restores full defaults', async () => {
  const f = fixture(), path = resolve(scratch, `selected-hybrid-${serial++}.json`); writeFileSync(path, JSON.stringify(f.manifest));
  const run = args => runCli({ args: [...args, '--manifest', path, '--root', f.root], mode: 'source', write: () => {} });
  const selected = await run(['init', '--mode', 'hybrid', '--select', 'earth', '--apply']); assert.equal(selected.exitCode, 0); assert.equal(existsSync(resolve(f.root, 'applications/campus')), false); assert.equal(existsSync(resolve(f.root, 'providers/shared')), false);
  const repeat = await run(['init', '--apply']); assert.equal(repeat.exitCode, 0); assert.deepEqual(repeat.selection, selected.selection); assert.deepEqual(repeat.choices.selections, ['earth']); assert.equal(existsSync(resolve(f.root, 'applications/campus')), false);
  const full = await run(['init', '--all', '--apply']); assert.equal(full.exitCode, 0); assert.equal(existsSync(resolve(f.root, 'applications/campus')), true); assert.deepEqual(full.choices.selections, []); assert.equal(existsSync(resolve(f.root, 'providers/shared')), false);
});

test('narrowing a selection retains a saved inactive checkout mapping without mutating that consumer', async () => {
  const f = fixture(), custom = resolve(f.root, 'local/campus'); mkdirSync(resolve(f.root, 'local'), { recursive: true }); git(f.root, ['clone', '--no-hardlinks', '--', f.manifest.repositories[1].source, custom]);
  assert.equal((await f.run('init', { links: { campus: 'local/campus' } })).exitCode, 0); const before = snapshot(custom);
  const selected = await f.run('init', { selections: ['earth'] }); assert.equal(selected.exitCode, 0); assert.equal(selected.choices.links.campus, 'local/campus'); assert.equal(selected.repositories.some(repo => repo.id === 'campus'), false); assert.deepEqual(snapshot(custom), before);
  const repeat = await f.run(); assert.equal(repeat.exitCode, 0); assert.deepEqual(repeat.selection, selected.selection); assert.deepEqual(snapshot(custom), before);
});

test('narrow source-to-package switches retain untouched consumer witnesses for later full expansion', async () => {
  const f = fixture(); assert.equal((await f.run()).exitCode, 0);
  const provider = resolve(f.root, 'providers/shared'), campus = resolve(f.root, 'applications/campus');
  writeFileSync(resolve(provider, 'editing.mjs'), 'retained inactive edit'); writeFileSync(resolve(provider, 'build/evidence.bin'), 'retained evidence');
  const providerBefore = snapshot(provider), campusBefore = snapshot(campus);
  const narrow = await f.run('sync', { mode: 'hybrid', components: { provider: 'package' }, selections: ['earth'] });
  assert.equal(narrow.exitCode, 0); assert.deepEqual(snapshot(provider), providerBefore); assert.deepEqual(snapshot(campus), campusBefore);
  const stored = JSON.parse(readFileSync(resolve(f.root, 'build/dev-installer/workspaces/source-workspace.json')));
  assert.equal(stored.managedLinks.length, 2); assert.equal(lstatSync(resolve(campus, 'node_modules/@fixture/shared')).isSymbolicLink(), true);
  const repeat = await f.run('sync', { mode: undefined }); assert.equal(repeat.exitCode, 0); assert.deepEqual(snapshot(campus), campusBefore);
  const expanded = await f.run('sync', { mode: undefined, selections: [] }); assert.equal(expanded.exitCode, 0);
  for (const id of ['earth', 'campus']) { assert.equal(row(f, id).identity, 'immutable-artifact'); assert.equal(lstatSync(resolve(f.root, `applications/${id}/node_modules/@fixture/shared`)).isSymbolicLink(), false); }
  assert.deepEqual(snapshot(provider), providerBefore);
});

test('package mode skips unavailable provider source, persists choices and safely switches to the single source provider', async () => {
  const f = fixture(), location = f.manifest.repositories[2].source;
  f.manifest.repositories[2].source = pathToFileURL(resolve(scratch, 'unavailable-package-provider')).href;
  const first = await f.run('init', { mode: 'package' }); assert.equal(first.exitCode, 0); assert.equal(first.mode, 'package'); assert.equal(first.sourceLinks.length, 0); assert.equal(existsSync(resolve(f.root, 'providers/shared')), false);
  for (const id of ['earth', 'campus']) assert.equal(row(f, id).identity, 'immutable-artifact');
  const repeat = await f.run('init', { mode: undefined, defaultMode: 'source' }); assert.equal(repeat.exitCode, 0); assert.equal(repeat.mode, 'package'); assert.ok(repeat.steps.filter(step => step.fingerprint).every(step => step.reused));
  const before = snapshot(f.root), doctor = await f.run('doctor', { mode: undefined }); assert.equal(doctor.exitCode, 0); assert.equal(doctor.mode, 'package'); assert.deepEqual(snapshot(f.root), before);
  f.manifest.repositories[2].source = location;
  const source = await f.run('sync', { mode: 'source' }); assert.equal(source.exitCode, 0); assert.equal(row(f, 'earth').providerRealpath, row(f, 'campus').providerRealpath);
  const retained = snapshot(resolve(f.root, 'providers/shared'));
  const packaged = await f.run('sync', { mode: 'package' }); assert.equal(packaged.exitCode, 0); assert.deepEqual(snapshot(resolve(f.root, 'providers/shared')), retained);
  await assert.rejects(f.run('init', { mode: 'package', components: { provider: 'source' } }), /hybrid mode/);
});

test('portable destination and override aliases fail before any repository or workspace is provisioned', async () => {
  for (const kind of ['case', 'unicode', 'parent', 'override', 'trailing-dot']) {
    const f = fixture();
    if (kind === 'case') f.manifest.repositories[2].destination = 'APPLICATIONS/EARTH';
    if (kind === 'unicode') { f.manifest.repositories[0].destination = 'applications/earth'; f.manifest.repositories[2].destination = 'applications/ｅａｒｔｈ'; }
    if (kind === 'parent') f.manifest.repositories[2].destination = 'Applications/earth/provider';
    if (kind === 'trailing-dot') f.manifest.repositories[2].destination = 'providers/shared.';
    const extra = kind === 'override' ? { links: { provider: 'APPLICATIONS/EARTH' } } : {};
    await assert.rejects(f.run('init', extra), /portable|alias|overlap/); assert.equal(existsSync(f.root), false);
  }
});

test('standalone Earth application guard accepts the real app boundary and rejects site-only or foreign manifests before source actions', async () => {
  const f = fixture(); f.manifest.owner = 'foss-earth'; f.manifest.repositories[0].repository = 'foss-earth/app';
  const application = { owner: 'foss-earth', repository: 'foss-earth/app' }, path = resolve(scratch, `earth-app-${serial++}.json`);
  writeFileSync(path, JSON.stringify(f.manifest));
  const accepted = await runCli({ args: ['init', '--manifest', path, '--root', f.root], application, mode: 'source', write: () => {} }); assert.equal(accepted.exitCode, 0); assert.equal(existsSync(f.root), false);
  for (const kind of ['site-only', 'foreign', 'unused-app', 'landing-prerequisite', 'artifact-landing-prerequisite']) {
    const manifest = structuredClone(f.manifest);
    if (kind === 'site-only') manifest.repositories[0].repository = 'foss-earth/foss-earth.github.io';
    else if (kind === 'foreign') manifest.owner = 'UMN-VR';
    else if (kind === 'unused-app') { manifest.repositories[1].repository = 'foss-earth/foss-earth.github.io'; manifest.defaultComponents = ['campus']; }
    else if (kind === 'landing-prerequisite') { manifest.repositories[1].repository = 'foss-earth/foss-earth.github.io'; manifest.repositories[0].dependsOn.push('campus'); }
    else { manifest.repositories[1].repository = 'FOSS-EARTH/foss-earth.github.io'; manifest.artifacts[0].dependsOn = ['campus']; }
    const invalid = resolve(scratch, `${kind}-${serial++}.json`); writeFileSync(invalid, JSON.stringify(manifest));
    const stopped = await runCli({ args: ['init', '--manifest', invalid, '--root', f.root, '--apply'], application, mode: 'source', write: () => {} }); assert.equal(stopped.exitCode, 2); assert.equal(stopped.issues[0].rule, 'bootstrap.application'); assert.equal(existsSync(f.root), false);
  }
  const bytes = Buffer.from(JSON.stringify(f.manifest)), descriptor = { schemaVersion: 1, manifest: { owner: 'UMN-VR', location: pathToFileURL(path).href, revision: f.earth.revision, sha256: sha256(bytes), sizeBytes: bytes.length } };
  const rejected = await runCli({ args: ['init', '--root', f.root, '--apply'], application, bootstrap: descriptor, mode: 'source', write: () => {} }); assert.equal(rejected.exitCode, 2); assert.equal(rejected.issues[0].rule, 'bootstrap.application'); assert.equal(existsSync(f.root), false);
});

test('attribution source links retain independently pinned executable byte integrity', async () => {
  const f = fixture(), name = '@foss-earth/ci', commonMetadata = { ...metadata, name }; writeFileSync(resolve(f.provider.path, 'package.json'), JSON.stringify(commonMetadata)); f.manifest.repositories[2].revision = commit(f.provider.path, 'Synthetic attribution artifact identity fixture');
  const files = { ...f.artifactFiles, 'package.json': JSON.stringify(commonMetadata) }, bytes = Buffer.from(JSON.stringify(files)), artifact = resolve(scratch, `ci-identity-${serial++}.json`); writeFileSync(artifact, bytes); Object.assign(f.manifest.artifacts[0], { location: pathToFileURL(artifact).href, sha256: sha256(bytes), sizeBytes: bytes.length });
  for (const link of f.manifest.links) link.package = name; for (const repo of f.manifest.repositories.slice(0, 2)) Object.assign(repo.installedPackages[0], { name, files: Object.fromEntries(Object.entries(files).map(([path, bytes]) => [path, sha256(bytes)])) });
  const stopped = await f.run(); assert.equal(stopped.exitCode, 2); assert.ok(stopped.issues.some(issue => issue.rule === 'package.attribution-integrity')); assert.equal(existsSync(resolve(f.root, 'applications/earth')), false); assert.equal(existsSync(resolve(f.root, 'applications/campus')), false);
});
