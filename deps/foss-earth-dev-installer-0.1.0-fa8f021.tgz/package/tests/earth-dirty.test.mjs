import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdirSync, mkdtempSync, writeFileSync, readFileSync, readdirSync, statSync, existsSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { pathToFileURL } from 'node:url';
import { workspace } from '../src/workspace.mjs';
import { sha256 } from '../src/manifest.mjs';
import { git } from '../src/process.mjs';
const metadataBytes = readFileSync(new URL('./fixtures/earth-dirty-requirements.json', import.meta.url)), requirements = JSON.parse(metadataBytes);
const parent = resolve('build/fixtures/earth-dirty'); mkdirSync(parent, { recursive: true });
const root = mkdtempSync(resolve(parent, 'run-'));
function snapshot(path) {
  if (!existsSync(path)) return [];
  return readdirSync(path, { withFileTypes: true }).flatMap(entry => { const target = resolve(path, entry.name); return entry.isDirectory() ? snapshot(target) : [[target, statSync(target).mtimeMs, sha256(readFileSync(target))]]; });
}
test('Earth owner dirty path/hash requirements preserve synthetic bytes and branch before any operation', async () => {
  assert.equal(requirements.baselineSource, '90e23b3ee96f53ec5900afc5991a21fffa58649d');
  assert.ok(requirements.paths.every(entry => /^[a-f0-9]{64}$/.test(entry.sha256)));
  const source = resolve(root, 'synthetic-source'); mkdirSync(source); git(source, ['init', '--quiet', '--initial-branch=main']); writeFileSync(resolve(source, '.gitignore'), '/build/\n/node_modules/\n');
  for (const entry of requirements.paths.filter(entry => entry.status === 'modified tracked')) { const path = resolve(source, entry.path); mkdirSync(dirname(path), { recursive: true }); writeFileSync(path, entry.path === 'package.json' ? '{"name":"synthetic-earth-source","private":true}\n' : `Synthetic baseline for ${entry.path}\n`); }
  git(source, ['add', '.']); git(source, ['-c', 'user.name=Fixture Human', '-c', 'user.email=fixture@example.invalid', 'commit', '--quiet', '-m', 'Synthetic Earth fixture baseline']);
  const revision = git(source, ['rev-parse', 'HEAD']).stdout.trim(), manifest = { schemaVersion: 1, id: 'synthetic-earth', owner: 'foss-earth', version: '1', repositories: [{ id: 'engine', repository: 'foss-earth/engine', source: pathToFileURL(source).href, revision, destination: 'engine', dependsOn: [], steps: [] }, { id: 'viewer', repository: 'foss-earth/viewer', source: pathToFileURL(source).href, revision, destination: 'viewer', dependsOn: ['engine'], steps: [] }], defaultComponents: ['viewer'], selections: { engine: ['engine'] } };
  const destination = resolve(root, 'new Earth workspace'), options = { root: destination, manifest, digest: sha256(JSON.stringify(manifest)), apply: true };
  const missing = await workspace({ ...options, action: 'doctor' }); assert.equal(missing.exitCode, 1); assert.equal(existsSync(destination), false);
  const initialized = await workspace({ ...options, action: 'init' }); assert.equal(initialized.exitCode, 0); assert.deepEqual(initialized.selection, ['engine', 'viewer']);
  const selectedRoot = resolve(root, 'selected Earth workspace'), selected = await workspace({ ...options, root: selectedRoot, action: 'init', selections: ['engine'] }); assert.equal(selected.exitCode, 0); assert.deepEqual(selected.selection, ['engine']); assert.equal(existsSync(resolve(selectedRoot, 'viewer')), false);
  assert.ok(!JSON.stringify(manifest).match(/0sfs|search|\/vr|aircraft|native/i));
  const viewer = resolve(destination, 'viewer'); git(viewer, ['checkout', '--quiet', '-b', requirements.branch]);
  for (const entry of requirements.paths) { const path = resolve(viewer, entry.path); mkdirSync(dirname(path), { recursive: true }); const payload = { synthetic: true, ownerPath: entry.path, requirementHash: entry.sha256 }; writeFileSync(path, JSON.stringify(payload) + '\n'); }
  for (const entry of requirements.ignoredEvidence) { const path = resolve(viewer, entry.path); mkdirSync(dirname(path), { recursive: true }); writeFileSync(path, Buffer.from(entry.bytesHex, 'hex')); }
  const before = snapshot(destination), branch = git(viewer, ['symbolic-ref', 'HEAD']).stdout.trim();
  for (const action of ['doctor', 'init', 'sync']) { const result = await workspace({ ...options, action }); assert.equal(result.exitCode, 1); assert.ok(result.issues.some(issue => issue.rule === 'repository.dirty')); assert.deepEqual(snapshot(destination), before); assert.equal(git(viewer, ['symbolic-ref', 'HEAD']).stdout.trim(), branch); }
  writeFileSync(resolve(root, 'receipt.json'), JSON.stringify({ schemaVersion: 1, ownerMetadataSha256: sha256(metadataBytes), synthetic: true, preservedDirtyPaths: requirements.paths.length, preservedEvidencePaths: requirements.ignoredEvidence.length, fullDefault: initialized.selection, selected: selected.selection, branchPreserved: branch, doctorReadonly: true, initSyncNoMutation: true, realApplicationQualification: false }, null, 2) + '\n', { flag: 'wx' });
});
