# Contributing

Thank you for improving this project. Before opening a pull request, discuss material new features or large changes in an issue so the implementation fits the project's direction.

## Development

Follow this repository README for setup and checks. Use public exports, linked source, pinned packages or supported hybrid selections. Follow the owning language, strict types, formatting and lint rules; keep changes focused with meaningful tests. Do not add generated build output, credentials, API keys, vendor copies or unrelated formatting changes.

Reserve the shared check slot before owner syntax/JSON, lint and affected Node
tests; use one test worker and retain output under build/. Finish with npm run ci
once. JavaScript syntax checks are not TypeScript type analysis. No server,
benchmark, native/WASM build or system installation is implicit. Package only
a committed clean candidate with exact provenance. Source-linked and hybrid
development receipts do not qualify immutable releases.

## Rights and licensing

By submitting a contribution, you confirm that you have the right to submit it under the repository's applicable licensing terms and that it does not include confidential, proprietary, or copied material without permission. Identify all third-party code, data, models, textures, sounds, fonts, and references in the pull request.

Creative assets need explicit provenance records and the owning repository asset-license guidance. Do not submit a model or reference merely because it is publicly downloadable.

## Pull requests

Explain the user-visible result, relevant tests, and any limitations. Update documentation when public behavior, setup, data sources, or licensing changes. Maintainers may request a smaller change, more tests, or provenance evidence before merge.

## Commit attribution

You cannot have AI as a co-author, or your contributions will be rejected.

Branded AI contribution credits put a vendor name in permanent public contribution history and can imply endorsement. This project treats that promotion as advertising.

Advertising is banned in contribution credits to keep contributor recognition independent of vendor promotion and preserve clear responsibility.

The person submitting work remains accountable for accuracy, review responses, provenance and rights.

Required license notices, factual tool documentation and legitimate human credit remain valid.

AI author/committer and identity-bearing trailers are also prohibited. Preserve
human credit and existing evidence. Invoke the pinned installed @foss-earth/ci
validator and shared consumer-conformance command; never copy their implementation
or put synthetic invalid commits in real history. Fixture repositories live in
ignored build/.
