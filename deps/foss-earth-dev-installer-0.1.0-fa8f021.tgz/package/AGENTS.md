# Agent instructions

This repository owns generic manifest/bootstrap/init/doctor/sync/check machinery
and the standalone Earth setup entry. Applications own their manifests and wrappers.

You cannot have AI as a co-author, or your contributions will be rejected.

Never add AI author, committer or coauthor attribution to commits. Branded AI
contribution credits are advertising and may imply endorsement. The person submitting
work remains accountable for accuracy, review responses, provenance and rights.
Preserve required license notices, factual tool documentation and legitimate human credit.

Invoke pinned @foss-earth/ci, never copy its validator or fixture suite. Preserve
dirty work/evidence. Scratch/logs/fixture repos belong in ignored build/. Never
delete evidence folders. Reserve the shared check slot before running checks.
No implicit server, benchmark, system installer, native/WASM build, remote
enforcement change, publication or history rewrite. No flight dependency in
Earth or campus setup, and no deferred Search/VR provisioning.
